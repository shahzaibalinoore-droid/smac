import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // Clean existing data
  await prisma.invoiceItem.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.inventoryItem.deleteMany();
  await prisma.user.deleteMany();
  await prisma.dealer.deleteMany();
  await prisma.productType.deleteMany();
  await prisma.category.deleteMany();

  // Create Categories
  const categories = await Promise.all([
    prisma.category.create({
      data: {
        name: "Cat1",
        codePrefix: "1",
        codeStart: 1,
        codeEnd: 100,
        description: "Category 1 - Codes 1 to 100",
      },
    }),
    prisma.category.create({
      data: {
        name: "Cat2",
        codePrefix: "2",
        codeStart: 1,
        codeEnd: 200,
        description: "Category 2 - Codes 1 to 200",
      },
    }),
    prisma.category.create({
      data: {
        name: "Cat3",
        codePrefix: "3",
        codeStart: 1,
        codeEnd: 300,
        description: "Category 3 - Codes 1 to 300",
      },
    }),
  ]);
  console.log(`✅ Created ${categories.length} categories`);

  // Create Product Types
  const productTypes = await Promise.all([
    prisma.productType.create({
      data: { code: "P1", name: "Product Type 1", description: "Standard product type 1" },
    }),
    prisma.productType.create({
      data: { code: "P2", name: "Product Type 2", description: "Standard product type 2" },
    }),
    prisma.productType.create({
      data: { code: "P3", name: "Product Type 3", description: "Standard product type 3" },
    }),
    prisma.productType.create({
      data: { code: "P4", name: "Product Type 4", description: "Standard product type 4" },
    }),
    prisma.productType.create({
      data: { code: "P5", name: "Product Type 5", description: "Standard product type 5" },
    }),
  ]);
  console.log(`✅ Created ${productTypes.length} product types`);

  // Create Dealers
  const dealers = await Promise.all([
    prisma.dealer.create({
      data: {
        name: "Rajesh Kumar",
        company: "RK Distributors",
        email: "rajesh@rkdist.com",
        phone: "+91 98765 43210",
        address: "123 MG Road",
        city: "Mumbai",
        state: "Maharashtra",
        zipCode: "400001",
      },
    }),
    prisma.dealer.create({
      data: {
        name: "Priya Sharma",
        company: "PS Enterprises",
        email: "priya@psent.com",
        phone: "+91 87654 32109",
        address: "456 Brigade Road",
        city: "Bangalore",
        state: "Karnataka",
        zipCode: "560001",
      },
    }),
    prisma.dealer.create({
      data: {
        name: "Amit Patel",
        company: "AP Trading Co.",
        email: "amit@aptrading.com",
        phone: "+91 76543 21098",
        address: "789 CG Road",
        city: "Ahmedabad",
        state: "Gujarat",
        zipCode: "380001",
      },
    }),
    prisma.dealer.create({
      data: {
        name: "Sneha Reddy",
        company: "SR Suppliers",
        email: "sneha@srsuppliers.com",
        phone: "+91 65432 10987",
        address: "321 Banjara Hills",
        city: "Hyderabad",
        state: "Telangana",
        zipCode: "500034",
      },
    }),
    prisma.dealer.create({
      data: {
        name: "Vikram Singh",
        company: "VS Industries",
        email: "vikram@vsind.com",
        phone: "+91 54321 09876",
        address: "654 Anna Nagar",
        city: "Chennai",
        state: "Tamil Nadu",
        zipCode: "600040",
      },
    }),
  ]);
  console.log(`✅ Created ${dealers.length} dealers`);

  // Create Admin User
  const adminPassword = await bcrypt.hash("admin123", 10);
  await prisma.user.create({
    data: {
      email: "admin@inventory.com",
      password: adminPassword,
      name: "Admin User",
      role: "admin",
    },
  });
  console.log("✅ Created admin user (admin@inventory.com / admin123)");

  // Create Dealer Users
  for (const dealer of dealers) {
    const dealerPassword = await bcrypt.hash("dealer123", 10);
    await prisma.user.create({
      data: {
        email: dealer.email,
        password: dealerPassword,
        name: dealer.name,
        role: "dealer",
        dealerId: dealer.id,
      },
    });
  }
  console.log(`✅ Created ${dealers.length} dealer users (password: dealer123)`);

  // Create Inventory Items (15+ records)
  const inventoryData = [
    { catIdx: 0, code: 10, ptIdx: 0, qty: 50, cost: 100, discount: 90, sell: 120 },
    { catIdx: 0, code: 14, ptIdx: 0, qty: 30, cost: 150, discount: 135, sell: 180 },
    { catIdx: 0, code: 14, ptIdx: 1, qty: 40, cost: 200, discount: 180, sell: 250 },
    { catIdx: 0, code: 25, ptIdx: 2, qty: 60, cost: 80, discount: 72, sell: 100 },
    { catIdx: 0, code: 33, ptIdx: 3, qty: 25, cost: 300, discount: 270, sell: 380 },
    { catIdx: 1, code: 15, ptIdx: 0, qty: 45, cost: 120, discount: 108, sell: 150 },
    { catIdx: 1, code: 22, ptIdx: 1, qty: 35, cost: 180, discount: 162, sell: 220 },
    { catIdx: 1, code: 50, ptIdx: 2, qty: 55, cost: 90, discount: 81, sell: 110 },
    { catIdx: 1, code: 75, ptIdx: 4, qty: 20, cost: 500, discount: 450, sell: 650 },
    { catIdx: 1, code: 100, ptIdx: 3, qty: 40, cost: 250, discount: 225, sell: 320 },
    { catIdx: 2, code: 10, ptIdx: 0, qty: 70, cost: 60, discount: 54, sell: 80 },
    { catIdx: 2, code: 30, ptIdx: 1, qty: 50, cost: 110, discount: 99, sell: 140 },
    { catIdx: 2, code: 80, ptIdx: 2, qty: 35, cost: 160, discount: 144, sell: 200 },
    { catIdx: 2, code: 150, ptIdx: 4, qty: 15, cost: 400, discount: 360, sell: 500 },
    { catIdx: 2, code: 200, ptIdx: 3, qty: 28, cost: 220, discount: 198, sell: 280 },
  ];

  const inventoryItems = [];
  for (const item of inventoryData) {
    const inv = await prisma.inventoryItem.create({
      data: {
        categoryId: categories[item.catIdx].id,
        categoryCode: item.code,
        productTypeId: productTypes[item.ptIdx].id,
        quantity: item.qty,
        costPrice: item.cost,
        discountPrice: item.discount,
        sellingPrice: item.sell,
      },
      include: { category: true, productType: true },
    });
    inventoryItems.push(inv);
  }
  console.log(`✅ Created ${inventoryItems.length} inventory items`);

  // Create Sample Invoices
  const invoiceData = [
    {
      dealerIdx: 0, // Rajesh Kumar
      items: [
        { invIdx: 0, qty: 10 }, // Cat1 Code 10, P1
        { invIdx: 1, qty: 5 },  // Cat1 Code 14, P1
        { invIdx: 2, qty: 8 },  // Cat1 Code 14, P2
      ],
      advance: 1500,
      status: "Partial",
    },
    {
      dealerIdx: 1, // Priya Sharma
      items: [
        { invIdx: 5, qty: 15 }, // Cat2 Code 15, P1
        { invIdx: 6, qty: 10 }, // Cat2 Code 22, P2
      ],
      advance: 2000,
      status: "Paid",
    },
    {
      dealerIdx: 2, // Amit Patel
      items: [
        { invIdx: 3, qty: 20 }, // Cat1 Code 25, P3
        { invIdx: 7, qty: 12 }, // Cat2 Code 50, P3
        { invIdx: 10, qty: 25 },// Cat3 Code 10, P1
      ],
      advance: 0,
      status: "Unpaid",
    },
    {
      dealerIdx: 3, // Sneha Reddy
      items: [
        { invIdx: 4, qty: 8 },  // Cat1 Code 33, P4
        { invIdx: 9, qty: 6 },  // Cat2 Code 100, P4
      ],
      advance: 3000,
      status: "Partial",
    },
    {
      dealerIdx: 4, // Vikram Singh
      items: [
        { invIdx: 11, qty: 30 }, // Cat3 Code 30, P2
        { invIdx: 13, qty: 5 },  // Cat3 Code 150, P4
        { invIdx: 14, qty: 10 }, // Cat3 Code 200, P4
      ],
      advance: 5000,
      status: "Paid",
    },
    {
      dealerIdx: 0, // Rajesh Kumar again
      items: [
        { invIdx: 8, qty: 3 },  // Cat2 Code 75, P5
      ],
      advance: 500,
      status: "Unpaid",
    },
  ];

  for (let i = 0; i < invoiceData.length; i++) {
    const invData = invoiceData[i];
    const dealer = dealers[invData.dealerIdx];

    let totalQty = 0;
    let totalAmount = 0;
    const invoiceItemsData = [];

    for (const item of invData.items) {
      const invItem = inventoryItems[item.invIdx];
      const totalPrice = invItem.sellingPrice * item.qty;
      totalQty += item.qty;
      totalAmount += totalPrice;

      invoiceItemsData.push({
        inventoryItemId: invItem.id,
        quantity: item.qty,
        unitPrice: invItem.sellingPrice,
        totalPrice: totalPrice,
      });
    }

    const remaining = totalAmount - invData.advance;

    const invoice = await prisma.invoice.create({
      data: {
        invoiceNumber: `INV-${String(i + 1).padStart(4, "0")}`,
        dealerId: dealer.id,
        totalQuantity: totalQty,
        totalAmount,
        advancePaid: invData.advance,
        remainingAmount: remaining,
        paymentStatus: invData.status,
        items: {
          create: invoiceItemsData,
        },
      },
    });
    console.log(`  📄 Invoice ${invoice.invoiceNumber}: ${dealer.name} - ₹${totalAmount} (${invData.status})`);
  }

  console.log("\n🎉 Seeding completed successfully!");
  console.log("\n🔑 Login Credentials:");
  console.log("  Admin: admin@inventory.com / admin123");
  console.log("  Dealer: rajesh@rkdist.com / dealer123");
  console.log("  Dealer: priya@psent.com / dealer123");
  console.log("  Dealer: amit@aptrading.com / dealer123");
  console.log("  Dealer: sneha@srsuppliers.com / dealer123");
  console.log("  Dealer: vikram@vsind.com / dealer123");
}

main()
  .catch((e) => {
    console.error("❌ Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
