export interface User {
  id: string;
  email: string;
  name: string;
  role: "admin" | "dealer";
  dealerId?: string | null;
  dealerName?: string | null;
}

export interface Dealer {
  id: string;
  name: string;
  company?: string | null;
  email: string;
  phone: string;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  zipCode?: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  codePrefix: string;
  codeStart: number;
  codeEnd: number;
  description?: string | null;
  createdAt: string;
  _count?: { inventory: number };
}

export interface ProductType {
  id: string;
  code: string;
  name: string;
  description?: string | null;
  createdAt: string;
  _count?: { inventory: number };
}

export interface InventoryItem {
  id: string;
  categoryId: string;
  categoryCode: number;
  productTypeId: string;
  quantity: number;
  costPrice: number;
  discountPrice: number;
  sellingPrice: number;
  createdAt: string;
  updatedAt: string;
  category: Category;
  productType: ProductType;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  dealerId: string;
  totalQuantity: number;
  totalAmount: number;
  advancePaid: number;
  remainingAmount: number;
  paymentStatus: "Paid" | "Partial" | "Unpaid";
  status: "Active" | "Cancelled";
  notes?: string | null;
  createdAt: string;
  updatedAt: string;
  dealer: Dealer;
  items: InvoiceItem[];
}

export interface InvoiceItem {
  id: string;
  invoiceId: string;
  inventoryItemId: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  createdAt: string;
  inventoryItem: InventoryItem;
}

export interface DashboardStats {
  totalDealers: number;
  totalInventory: number;
  totalInventoryValue: number;
  totalSales: number;
  totalRevenue: number;
  pendingPayments: number;
  recentInvoices: Invoice[];
  categoryDistribution: { name: string; codePrefix: string; itemCount: number; totalQuantity: number; totalValue: number }[];
  monthlySales: { month: string; sales: number; revenue: number }[];
}

export interface PurchaseItem {
  inventoryItemId: string;
  inventoryItem: InventoryItem;
  quantity: number;
}

export type PaymentStatus = "Paid" | "Partial" | "Unpaid";

export type AdminView =
  | "dashboard"
  | "dealers"
  | "categories"
  | "product-types"
  | "inventory"
  | "purchases"
  | "invoices";

export type DealerView = "dashboard" | "invoices" | "purchases" | "order";
