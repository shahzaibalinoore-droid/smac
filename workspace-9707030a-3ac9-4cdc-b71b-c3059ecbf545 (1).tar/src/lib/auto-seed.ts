import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

export async function autoSeed() {
  // Clean existing data
  await db.invoiceItem.deleteMany();
  await db.invoice.deleteMany();
  await db.inventoryItem.deleteMany();
  await db.user.deleteMany();
  await db.dealer.deleteMany();
  await db.productType.deleteMany();
  await db.category.deleteMany();

  // 1. Categories
  const categories = await Promise.all([
    db.category.create({ data: { name: "Cat1", codePrefix: "1", codeStart: 1, codeEnd: 100, description: "Category 1 - Codes 1 to 100" } }),
    db.category.create({ data: { name: "Cat2", codePrefix: "2", codeStart: 1, codeEnd: 200, description: "Category 2 - Codes 1 to 200" } }),
    db.category.create({ data: { name: "Cat3", codePrefix: "3", codeStart: 1, codeEnd: 300, description: "Category 3 - Codes 1 to 300" } }),
  ]);

  // 2. Product Types
  const productTypes = await Promise.all([
    db.productType.create({ data: { code: "P1", name: "Product Type 1", description: "Standard product type 1" } }),
    db.productType.create({ data: { code: "P2", name: "Product Type 2", description: "Standard product type 2" } }),
    db.productType.create({ data: { code: "P3", name: "Product Type 3", description: "Standard product type 3" } }),
    db.productType.create({ data: { code: "P4", name: "Product Type 4", description: "Standard product type 4" } }),
    db.productType.create({ data: { code: "P5", name: "Product Type 5", description: "Standard product type 5" } }),
  ]);

  // 3. Dealers
  const dealers = await Promise.all([
    db.dealer.create({ data: { name: "Rajesh Kumar", company: "RK Distributors", email: "rajesh@rkdist.com", phone: "+91 98765 43210", address: "123 MG Road", city: "Mumbai", state: "Maharashtra", zipCode: "400001" } }),
    db.dealer.create({ data: { name: "Priya Sharma", company: "PS Enterprises", email: "priya@psent.com", phone: "+91 87654 32109", address: "456 Brigade Road", city: "Bangalore", state: "Karnataka", zipCode: "560001" } }),
    db.dealer.create({ data: { name: "Amit Patel", company: "AP Trading Co.", email: "amit@aptrading.com", phone: "+91 76543 21098", address: "789 CG Road", city: "Ahmedabad", state: "Gujarat", zipCode: "380001" } }),
    db.dealer.create({ data: { name: "Sneha Reddy", company: "SR Suppliers", email: "sneha@srsuppliers.com", phone: "+91 65432 10987", address: "321 Banjara Hills", city: "Hyderabad", state: "Telangana", zipCode: "500034" } }),
    db.dealer.create({ data: { name: "Vikram Singh", company: "VS Industries", email: "vikram@vsind.com", phone: "+91 54321 09876", address: "654 Anna Nagar", city: "Chennai", state: "Tamil Nadu", zipCode: "600040" } }),
  ]);

  // 4. Admin User
  const adminPw = await bcrypt.hash("admin123", 10);
  await db.user.create({ data: { email: "admin@inventory.com", password: adminPw, name: "Admin User", role: "admin" } });

  // 5. Dealer Users
  const dealerPw = await bcrypt.hash("dealer123", 10);
  for (const d of dealers) {
    await db.user.create({ data: { email: d.email, password: dealerPw, name: d.name, role: "dealer", dealerId: d.id } });
  }

  // 6. Inventory Items (15 records)
  const invDefs = [
    { c: 0, code: 10, p: 0, qty: 50, cost: 100, disc: 90, sell: 120 },
    { c: 0, code: 14, p: 0, qty: 30, cost: 150, disc: 135, sell: 180 },
    { c: 0, code: 14, p: 1, qty: 40, cost: 200, disc: 180, sell: 250 },
    { c: 0, code: 25, p: 2, qty: 60, cost: 80, disc: 72, sell: 100 },
    { c: 0, code: 33, p: 3, qty: 25, cost: 300, disc: 270, sell: 380 },
    { c: 1, code: 15, p: 0, qty: 45, cost: 120, disc: 108, sell: 150 },
    { c: 1, code: 22, p: 1, qty: 35, cost: 180, disc: 162, sell: 220 },
    { c: 1, code: 50, p: 2, qty: 55, cost: 90, disc: 81, sell: 110 },
    { c: 1, code: 75, p: 4, qty: 20, cost: 500, disc: 450, sell: 650 },
    { c: 1, code: 100, p: 3, qty: 40, cost: 250, disc: 225, sell: 320 },
    { c: 2, code: 10, p: 0, qty: 70, cost: 60, disc: 54, sell: 80 },
    { c: 2, code: 30, p: 1, qty: 50, cost: 110, disc: 99, sell: 140 },
    { c: 2, code: 80, p: 2, qty: 35, cost: 160, disc: 144, sell: 200 },
    { c: 2, code: 150, p: 4, qty: 15, cost: 400, disc: 360, sell: 500 },
    { c: 2, code: 200, p: 3, qty: 28, cost: 220, disc: 198, sell: 280 },
  ];
  const inventory: { id: string; sellingPrice: number }[] = [];
  for (const i of invDefs) {
    const item = await db.inventoryItem.create({
      data: {
        categoryId: categories[i.c].id,
        categoryCode: i.code,
        productTypeId: productTypes[i.p].id,
        quantity: i.qty,
        costPrice: i.cost,
        discountPrice: i.disc,
        sellingPrice: i.sell,
      },
    });
    inventory.push(item);
  }

  // 7. Sample Invoices
  const invoiceDefs = [
    { di: 0, items: [{ ii: 0, q: 10 }, { ii: 1, q: 5 }, { ii: 2, q: 8 }], advance: 1500, status: "Partial" },
    { di: 1, items: [{ ii: 5, q: 15 }, { ii: 6, q: 10 }], advance: 2000, status: "Paid" },
    { di: 2, items: [{ ii: 3, q: 20 }, { ii: 7, q: 12 }, { ii: 10, q: 25 }], advance: 0, status: "Unpaid" },
    { di: 3, items: [{ ii: 4, q: 8 }, { ii: 9, q: 6 }], advance: 3000, status: "Partial" },
    { di: 4, items: [{ ii: 11, q: 30 }, { ii: 13, q: 5 }, { ii: 14, q: 10 }], advance: 5000, status: "Paid" },
    { di: 0, items: [{ ii: 8, q: 3 }], advance: 500, status: "Unpaid" },
  ];

  for (let idx = 0; idx < invoiceDefs.length; idx++) {
    const def = invoiceDefs[idx];
    let totalQty = 0;
    let totalAmount = 0;
    const lineItems = def.items.map((it) => {
      const total = inventory[it.ii].sellingPrice * it.q;
      totalQty += it.q;
      totalAmount += total;
      return { inventoryItemId: inventory[it.ii].id, quantity: it.q, unitPrice: inventory[it.ii].sellingPrice, totalPrice: total };
    });

    await db.invoice.create({
      data: {
        invoiceNumber: `INV-${String(idx + 1).padStart(4, "0")}`,
        dealerId: dealers[def.di].id,
        totalQuantity: totalQty,
        totalAmount,
        advancePaid: def.advance,
        remainingAmount: totalAmount - def.advance,
        paymentStatus: def.status,
        items: { create: lineItems },
      },
    });
  }

  console.log("[seed] Database seeded with admin + 5 dealers + 15 inventory items + 6 invoices.");
}
