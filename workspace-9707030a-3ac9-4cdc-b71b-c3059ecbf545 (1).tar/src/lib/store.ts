import { create } from "zustand";
import type { User, AdminView, DealerView } from "./types";

interface AppState {
  user: User | null;
  isLoading: boolean;
  adminView: AdminView;
  dealerView: DealerView;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setAdminView: (view: AdminView) => void;
  setDealerView: (view: DealerView) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  isLoading: true,
  adminView: "dashboard",
  dealerView: "dashboard",
  setUser: (user) => set({ user }),
  setLoading: (isLoading) => set({ isLoading }),
  setAdminView: (adminView) => set({ adminView }),
  setDealerView: (dealerView) => set({ dealerView }),
  logout: () => set({ user: null, adminView: "dashboard", dealerView: "dashboard" }),
}));
