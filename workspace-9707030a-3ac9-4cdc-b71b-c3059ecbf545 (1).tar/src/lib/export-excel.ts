import * as XLSX from "xlsx";
import type { Invoice, InventoryItem, Dealer } from "@/lib/types";

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

const currencyFmt = (v: number) =>
  new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 2,
  }).format(v);

const dateFmt = (d: string) =>
  new Date(d).toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

/** Styled header row */
function headerStyle(ws: XLSX.WorkSheet, row: number = 0) {
  const range = XLSX.utils.decode_range(ws["!ref"] || "A1");
  for (let c = range.s.c; c <= range.e.c; c++) {
    const addr = XLSX.utils.encode_cell({ r: row, c });
    if (!ws[addr]) continue;
    ws[addr].s = {
      font: { bold: true, color: { rgb: "FFFFFF" } },
      fill: { fgColor: { rgb: "285A48" } },
      alignment: { horizontal: "center", vertical: "center" },
    };
  }
  // Set column widths
  ws["!cols"] = Array.from({ length: range.e.c + 1 }, () => ({ wch: 18 }));
}

function download(wb: XLSX.WorkBook, filename: string) {
  XLSX.writeFile(wb, filename, { bookType: "xlsx" });
}

/* ------------------------------------------------------------------ */
/*  Export Invoices                                                    */
/* ------------------------------------------------------------------ */

export function exportInvoices(invoices: Invoice[], filterLabel?: string) {
  const wb = XLSX.utils.book_new();

  // Summary sheet
  const summaryData = [
    ["Beraj Digital Inventory - Invoices Report"],
    filterLabel ? [`Filters Applied: ${filterLabel}`] : [],
    [`Exported On: ${dateFmt(new Date().toISOString())}`],
    [],
    ["Invoice #", "Dealer Name", "Company", "Items", "Total Qty", "Total Amount (Rs)", "Advance Paid (Rs)", "Remaining (Rs)", "Status", "Date"],
  ];

  for (const inv of invoices) {
    summaryData.push([
      inv.invoiceNumber,
      inv.dealer.name,
      inv.dealer.company || "—",
      inv.items.length,
      inv.totalQuantity,
      inv.totalAmount,
      inv.advancePaid,
      inv.remainingAmount,
      inv.paymentStatus,
      dateFmt(inv.createdAt),
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(summaryData);
  // Merge title row
  ws["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 9 } }];
  headerStyle(ws, 4);
  ws["!cols"] = [
    { wch: 16 }, // Invoice #
    { wch: 20 }, // Dealer
    { wch: 20 }, // Company
    { wch: 8 },  // Items
    { wch: 10 }, // Qty
    { wch: 16 }, // Total
    { wch: 16 }, // Advance
    { wch: 16 }, // Remaining
    { wch: 10 }, // Status
    { wch: 14 }, // Date
  ];
  XLSX.utils.book_append_sheet(wb, ws, "Invoices");

  // Items detail sheet
  const itemRows: (string | number)[][] = [
    ["Invoice #", "Dealer", "Category", "Code", "Product Type", "Qty", "Unit Price (Rs)", "Total Price (Rs)"],
  ];
  for (const inv of invoices) {
    for (const item of inv.items) {
      itemRows.push([
        inv.invoiceNumber,
        inv.dealer.name,
        item.inventoryItem.category?.name ?? "—",
        `${item.inventoryItem.category?.codePrefix ?? ""}${item.inventoryItem.categoryCode}`,
        item.inventoryItem.productType?.name ?? "—",
        item.quantity,
        item.unitPrice,
        item.totalPrice,
      ]);
    }
  }
  const wsItems = XLSX.utils.aoa_to_sheet(itemRows);
  headerStyle(wsItems);
  wsItems["!cols"] = [
    { wch: 16 }, { wch: 20 }, { wch: 18 }, { wch: 12 }, { wch: 18 }, { wch: 8 }, { wch: 14 }, { wch: 14 },
  ];
  XLSX.utils.book_append_sheet(wb, wsItems, "Invoice Items");

  const ts = new Date().toISOString().slice(0, 10);
  download(wb, `invoices-${ts}.xlsx`);
}

/* ------------------------------------------------------------------ */
/*  Export Inventory                                                   */
/* ------------------------------------------------------------------ */

export function exportInventory(items: InventoryItem[], filterLabel?: string) {
  const wb = XLSX.utils.book_new();

  const data: (string | number)[][] = [
    ["Beraj Digital Inventory - Inventory Report"],
    filterLabel ? [`Filters Applied: ${filterLabel}`] : [],
    [`Exported On: ${dateFmt(new Date().toISOString())}`],
    [],
    ["Category", "Code", "Product Type", "Quantity", "Cost Price (Rs)", "Discount Price (Rs)", "Selling Price (Rs)", "Margin (Rs)", "Margin %"],
  ];

  for (const item of items) {
    const margin = item.sellingPrice - item.costPrice;
    const marginPct = item.costPrice > 0 ? ((margin / item.costPrice) * 100).toFixed(1) : "0";
    data.push([
      item.category.name,
      `${item.category.codePrefix}${item.categoryCode}`,
      item.productType.name,
      item.quantity,
      item.costPrice,
      item.discountPrice,
      item.sellingPrice,
      margin,
      Number(marginPct),
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(data);
  ws["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 8 } }];
  headerStyle(ws, 4);
  ws["!cols"] = [
    { wch: 18 }, // Category
    { wch: 12 }, // Code
    { wch: 20 }, // Product Type
    { wch: 10 }, // Qty
    { wch: 14 }, // Cost
    { wch: 16 }, // Discount
    { wch: 16 }, // Selling
    { wch: 12 }, // Margin
    { wch: 10 }, // Margin %
  ];
  XLSX.utils.book_append_sheet(wb, ws, "Inventory");

  const ts = new Date().toISOString().slice(0, 10);
  download(wb, `inventory-${ts}.xlsx`);
}

/* ------------------------------------------------------------------ */
/*  Export Dealers                                                     */
/* ------------------------------------------------------------------ */

export function exportDealers(dealers: Dealer[], filterLabel?: string) {
  const wb = XLSX.utils.book_new();

  const data: (string | number)[][] = [
    ["Beraj Digital Inventory - Dealers Report"],
    filterLabel ? [`Filters Applied: ${filterLabel}`] : [],
    [`Exported On: ${dateFmt(new Date().toISOString())}`],
    [],
    ["Name", "Company", "Email", "Phone", "City", "State", "Zip Code", "Status", "Created On"],
  ];

  for (const d of dealers) {
    data.push([
      d.name,
      d.company || "—",
      d.email,
      d.phone,
      d.city || "—",
      d.state || "—",
      d.zipCode || "—",
      d.isActive ? "Active" : "Inactive",
      dateFmt(d.createdAt),
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(data);
  ws["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 8 } }];
  headerStyle(ws, 4);
  ws["!cols"] = [
    { wch: 22 }, // Name
    { wch: 22 }, // Company
    { wch: 28 }, // Email
    { wch: 18 }, // Phone
    { wch: 16 }, // City
    { wch: 14 }, // State
    { wch: 12 }, // Zip
    { wch: 10 }, // Status
    { wch: 14 }, // Date
  ];
  XLSX.utils.book_append_sheet(wb, ws, "Dealers");

  const ts = new Date().toISOString().slice(0, 10);
  download(wb, `dealers-${ts}.xlsx`);
}
