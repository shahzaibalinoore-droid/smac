import type { Invoice } from "@/lib/types";

const currencyFormatter = new Intl.NumberFormat("en-PK", {
  style: "currency",
  currency: "PKR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const fmt = (v: number) => currencyFormatter.format(v);

export function buildPrintHTML(invoice: Invoice): string {
  const d = invoice.dealer;
  const itemsRows = invoice.items
    .map(
      (item, i) => `
      <tr>
        <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;text-align:center;font-size:13px">${i + 1}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;font-size:13px">${item.inventoryItem.category?.name ?? "—"} ${item.inventoryItem.category?.codePrefix ?? ""}${item.inventoryItem.categoryCode ?? ""}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;font-size:13px">${item.inventoryItem.productType?.name ?? "—"}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;text-align:right;font-size:13px">${item.quantity}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;text-align:right;font-size:13px">${fmt(item.unitPrice)}</td>
        <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;text-align:right;font-size:13px;font-weight:600">${fmt(item.totalPrice)}</td>
      </tr>`
    )
    .join("");

  const statusColor =
    invoice.paymentStatus === "Paid"
      ? "#059669"
      : invoice.paymentStatus === "Partial"
        ? "#d97706"
        : "#dc2626";

  return `<!DOCTYPE html>
<html><head><title>Invoice ${invoice.invoiceNumber}</title>
<style>
  @media print { body { margin: 0; } }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #111; padding: 40px; }
  table { width: 100%; border-collapse: collapse; }
</style></head><body>
<div style="max-width:720px;margin:0 auto">

  <!-- Header -->
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:36px">
    <div>
      <img src="/dashboard-bg.jpg" alt="Beraj Digital" style="height:64px;width:64px;border-radius:12px;object-fit:cover" />
      <h1 style="font-size:22px;font-weight:700;margin:8px 0 2px;color:#285A48">Beraj Digital Inventory</h1>
      <p style="font-size:12px;color:#666">Inventory & Dealer Management System</p>
    </div>
    <div style="text-align:right">
      <h2 style="font-size:20px;font-weight:700;margin:0">INVOICE</h2>
      <p style="font-size:14px;font-weight:600;margin:4px 0 0;color:#333">${invoice.invoiceNumber}</p>
      <p style="font-size:12px;color:#666;margin-top:4px">${new Date(invoice.createdAt).toLocaleDateString("en-PK", { day: "2-digit", month: "long", year: "numeric" })}</p>
    </div>
  </div>

  <!-- Dealer Info -->
  <div style="background:#f8faf9;border-radius:10px;padding:16px 20px;margin-bottom:28px">
    <p style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 8px">Bill To</p>
    <p style="font-size:15px;font-weight:600;margin:0 0 2px">${d.name}${d.company ? ` — ${d.company}` : ""}</p>
    <p style="font-size:13px;color:#555;margin:0">${d.email} &nbsp;|&nbsp; ${d.phone}</p>
    ${(d.address || d.city || d.state) ? `<p style="font-size:13px;color:#555;margin:2px 0 0">${[d.address, d.city, d.state, d.zipCode].filter(Boolean).join(", ")}</p>` : ""}
  </div>

  <!-- Items Table -->
  <table style="margin-bottom:24px">
    <thead>
      <tr style="background:#285A48;color:#fff">
        <th style="padding:10px 12px;text-align:center;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">#</th>
        <th style="padding:10px 12px;text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">Item</th>
        <th style="padding:10px 12px;text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">Type</th>
        <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">Qty</th>
        <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">Unit Price</th>
        <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">Total</th>
      </tr>
    </thead>
    <tbody>${itemsRows}</tbody>
  </table>

  <!-- Summary -->
  <div style="display:flex;justify-content:flex-end">
    <div style="width:280px">
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #e5e7eb;font-size:14px">
        <span style="color:#666">Total Amount</span>
        <span style="font-weight:600">${fmt(invoice.totalAmount)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #e5e7eb;font-size:14px">
        <span style="color:#666">Advance Paid</span>
        <span style="color:#059669;font-weight:500">${fmt(invoice.advancePaid)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:14px">
        <span style="color:#666">Remaining Balance</span>
        <span style="font-weight:700;color:${invoice.remainingAmount > 0 ? "#dc2626" : "#059669"}">${fmt(invoice.remainingAmount)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;padding:10px 0 0;font-size:14px">
        <span style="font-weight:600">Status</span>
        <span style="font-weight:700;color:${statusColor};text-transform:uppercase">${invoice.paymentStatus}</span>
      </div>
    </div>
  </div>

  ${invoice.notes ? `<div style="margin-top:24px;padding:12px 16px;background:#f8faf9;border-radius:8px"><p style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#888;margin:0 0 4px">Notes</p><p style="font-size:13px;color:#555;margin:0">${invoice.notes}</p></div>` : ""}

  <div style="text-align:center;margin-top:40px;padding-top:16px;border-top:1px solid #e5e7eb">
    <p style="font-size:11px;color:#999">Thank you for your business!</p>
    <p style="font-size:11px;color:#bbb;margin-top:2px">Beraj Digital Inventory &copy; ${new Date().getFullYear()}</p>
  </div>

</div>
</body></html>`;
}

export function printInvoice(invoice: Invoice) {
  const html = buildPrintHTML(invoice);
  const win = window.open("", "_blank", "width=800,height=900");
  if (!win) return;
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 300);
}

export function getWhatsAppLink(invoice: Invoice): string {
  const phone = invoice.dealer.phone.replace(/[\s\-()]/g, "").replace(/^\+/, "");
  const itemSummary = invoice.items
    .map(
      (item) =>
        `${item.inventoryItem.category?.name ?? ""} ${item.inventoryItem.category?.codePrefix ?? ""}${item.inventoryItem.categoryCode ?? ""} (${item.inventoryItem.productType?.name ?? ""}) x${item.quantity}`
    )
    .join("\n");

  const message = `📋 *INVOICE ${invoice.invoiceNumber}*
🧾 *Beraj Digital Inventory*
📅 ${new Date(invoice.createdAt).toLocaleDateString("en-PK", { day: "2-digit", month: "long", year: "numeric" })}

👤 *${invoice.dealer.name}*${invoice.dealer.company ? ` — ${invoice.dealer.company}` : ""}

📦 *Items:*
${itemSummary}

💰 *Total:* ${new Intl.NumberFormat("en-PK", { style: "currency", currency: "PKR" }).format(invoice.totalAmount)}
💵 *Advance:* ${new Intl.NumberFormat("en-PK", { style: "currency", currency: "PKR" }).format(invoice.advancePaid)}
🔴 *Remaining:* ${new Intl.NumberFormat("en-PK", { style: "currency", currency: "PKR" }).format(invoice.remainingAmount)}
📌 *Status:* ${invoice.paymentStatus}

_Thank you for your business!_`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
