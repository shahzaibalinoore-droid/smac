import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/purchases - Create a new purchase/invoice
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { dealerId, items, advancePaid = 0, notes } = body;

    if (!dealerId) {
      return NextResponse.json(
        { error: 'Dealer ID is required' },
        { status: 400 }
      );
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: 'At least one item is required' },
        { status: 400 }
      );
    }

    // Validate dealer exists
    const dealer = await db.dealer.findUnique({
      where: { id: dealerId },
    });

    if (!dealer) {
      return NextResponse.json(
        { error: 'Dealer not found' },
        { status: 404 }
      );
    }

    // Validate inventory items and calculate totals
    let totalQuantity = 0;
    let totalAmount = 0;
    const invoiceItemsData: Array<{
      inventoryItemId: string;
      quantity: number;
      unitPrice: number;
      totalPrice: number;
    }> = [];

    for (const item of items) {
      if (!item.inventoryItemId || !item.quantity) {
        return NextResponse.json(
          { error: 'Each item must have inventoryItemId and quantity' },
          { status: 400 }
        );
      }

      const inventoryItem = await db.inventoryItem.findUnique({
        where: { id: item.inventoryItemId },
        include: { category: true, productType: true },
      });

      if (!inventoryItem) {
        return NextResponse.json(
          { error: `Inventory item not found: ${item.inventoryItemId}` },
          { status: 404 }
        );
      }

      const qty = Number(item.quantity);
      const unitPrice = Number(inventoryItem.sellingPrice);

      totalQuantity += qty;
      totalAmount += qty * unitPrice;

      invoiceItemsData.push({
        inventoryItemId: item.inventoryItemId,
        quantity: qty,
        unitPrice,
        totalPrice: qty * unitPrice,
      });
    }

    // Generate invoice number
    const lastInvoice = await db.invoice.findFirst({
      orderBy: { invoiceNumber: 'desc' },
      select: { invoiceNumber: true },
    });

    let nextNumber = 1;
    if (lastInvoice && lastInvoice.invoiceNumber) {
      const numStr = lastInvoice.invoiceNumber.replace('INV-', '');
      const lastNum = parseInt(numStr);
      if (!isNaN(lastNum)) {
        nextNumber = lastNum + 1;
      }
    }

    const invoiceNumber = `INV-${String(nextNumber).padStart(4, '0')}`;

    // Calculate payment info
    const advance = Number(advancePaid) || 0;
    const remainingAmount = totalAmount - advance;
    let paymentStatus = 'Unpaid';
    if (advance >= totalAmount) {
      paymentStatus = 'Paid';
    } else if (advance > 0) {
      paymentStatus = 'Partial';
    }

    // Create invoice with items in a transaction
    const invoice = await db.invoice.create({
      data: {
        invoiceNumber,
        dealerId,
        totalQuantity,
        totalAmount,
        advancePaid: advance,
        remainingAmount,
        paymentStatus,
        notes: notes || null,
        items: {
          create: invoiceItemsData,
        },
      },
      include: {
        dealer: true,
        items: {
          include: {
            inventoryItem: {
              include: {
                category: true,
                productType: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json(invoice, { status: 201 });
  } catch (error: any) {
    console.error('Error creating purchase:', error);

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'Invoice number collision, please try again' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to create purchase' },
      { status: 500 }
    );
  }
}
