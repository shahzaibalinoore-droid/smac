import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/dashboard
export async function GET() {
  try {
    // Run all queries in parallel for performance
    const [
      totalDealers,
      allInventory,
      allInvoices,
      recentInvoices,
      categoryDistribution,
    ] = await Promise.all([
      // Total dealers count
      db.dealer.count(),

      // Total inventory items and value
      db.inventoryItem.findMany({
        select: {
          quantity: true,
          costPrice: true,
          sellingPrice: true,
          categoryId: true,
        },
      }),

      // All invoices for revenue calculations
      db.invoice.findMany({
        where: { status: 'Active' },
        select: {
          totalAmount: true,
          advancePaid: true,
          remainingAmount: true,
          paymentStatus: true,
          createdAt: true,
        },
      }),

      // Recent invoices with dealer info
      db.invoice.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          dealer: {
            select: {
              name: true,
              company: true,
            },
          },
          items: {
            include: {
              inventoryItem: {
                include: {
                  category: true,
                  productType: true,
                },
              },
            },
          },
        },
      }),

      // Category distribution
      db.category.findMany({
        include: {
          inventory: {
            select: {
              quantity: true,
              sellingPrice: true,
            },
          },
        },
      }),
    ]);

    // Calculate inventory metrics
    const totalInventory = allInventory.reduce((sum, item) => sum + item.quantity, 0);
    const totalInventoryValue = allInventory.reduce(
      (sum, item) => sum + item.quantity * item.costPrice,
      0
    );

    // Calculate sales metrics
    const totalSales = allInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const totalRevenue = allInvoices.reduce((sum, inv) => sum + inv.advancePaid, 0);
    const pendingPayments = allInvoices
      .filter((inv) => inv.paymentStatus !== 'Paid')
      .reduce((sum, inv) => sum + inv.remainingAmount, 0);

    // Category distribution data
    const categoryData = categoryDistribution.map((cat) => {
      const totalQty = cat.inventory.reduce((sum, item) => sum + item.quantity, 0);
      const totalValue = cat.inventory.reduce(
        (sum, item) => sum + item.quantity * item.sellingPrice,
        0
      );
      return {
        name: cat.name,
        codePrefix: cat.codePrefix,
        itemCount: cat.inventory.length,
        totalQuantity: totalQty,
        totalValue,
      };
    });

    // Monthly sales data (last 12 months)
    const now = new Date();
    const twelveMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 11, 1);

    const monthlyInvoices = await db.invoice.findMany({
      where: {
        status: 'Active',
        createdAt: { gte: twelveMonthsAgo },
      },
      select: {
        totalAmount: true,
        advancePaid: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
    });

    const monthlySales: Array<{
      month: string;
      sales: number;
      revenue: number;
    }> = [];

    for (let i = 11; i >= 0; i--) {
      const monthStart = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0, 23, 59, 59, 999);
      const monthLabel = monthStart.toLocaleString('default', {
        month: 'short',
        year: '2-digit',
      });

      const monthData = monthlyInvoices.filter(
        (inv) => inv.createdAt >= monthStart && inv.createdAt <= monthEnd
      );

      const sales = monthData.reduce((sum, inv) => sum + inv.totalAmount, 0);
      const revenue = monthData.reduce((sum, inv) => sum + inv.advancePaid, 0);

      monthlySales.push({
        month: monthLabel,
        sales,
        revenue,
      });
    }

    return NextResponse.json({
      totalDealers,
      totalInventory,
      totalInventoryValue,
      totalSales,
      totalRevenue,
      pendingPayments,
      recentInvoices,
      categoryDistribution: categoryData,
      monthlySales,
    });
  } catch (error: any) {
    console.error('Error fetching dashboard data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch dashboard data' },
      { status: 500 }
    );
  }
}
