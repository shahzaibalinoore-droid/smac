import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/invoices?dealerId=...&status=...
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const dealerId = searchParams.get('dealerId');
    const status = searchParams.get('status');

    const where: any = {};

    if (dealerId) {
      where.dealerId = dealerId;
    }

    if (status) {
      where.paymentStatus = status;
    }

    const invoices = await db.invoice.findMany({
      where: Object.keys(where).length > 0 ? where : undefined,
      include: {
        dealer: true,
        items: {
          include: {
            inventoryItem: {
              include: {
                category: true,
                productType: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ invoices });
  } catch (error: any) {
    console.error('Error fetching invoices:', error);
    return NextResponse.json(
      { error: 'Failed to fetch invoices' },
      { status: 500 }
    );
  }
}

// PUT /api/invoices
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, paymentStatus, advancePaid, notes } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Invoice ID is required' },
        { status: 400 }
      );
    }

    // Fetch the existing invoice
    const existingInvoice = await db.invoice.findUnique({
      where: { id },
    });

    if (!existingInvoice) {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      );
    }

    // Build update data
    const updateData: any = {};

    if (notes !== undefined) {
      updateData.notes = notes || null;
    }

    if (advancePaid !== undefined) {
      updateData.advancePaid = Number(advancePaid) || 0;
      updateData.remainingAmount = existingInvoice.totalAmount - updateData.advancePaid;

      // Recalculate payment status
      const newAdvance = updateData.advancePaid;
      const total = existingInvoice.totalAmount;

      if (newAdvance >= total) {
        updateData.paymentStatus = 'Paid';
      } else if (newAdvance > 0) {
        updateData.paymentStatus = 'Partial';
      } else {
        updateData.paymentStatus = 'Unpaid';
      }
    }

    if (paymentStatus !== undefined && advancePaid === undefined) {
      updateData.paymentStatus = paymentStatus;

      // If status is set to Paid, update remaining amount to 0
      if (paymentStatus === 'Paid') {
        updateData.advancePaid = existingInvoice.totalAmount;
        updateData.remainingAmount = 0;
      }
    }

    const invoice = await db.invoice.update({
      where: { id },
      data: updateData,
      include: {
        dealer: true,
        items: {
          include: {
            inventoryItem: {
              include: {
                category: true,
                productType: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json(invoice);
  } catch (error: any) {
    console.error('Error updating invoice:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to update invoice' },
      { status: 500 }
    );
  }
}
