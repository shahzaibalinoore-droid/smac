import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/invoices/stats
export async function GET() {
  try {
    const invoices = await db.invoice.findMany({
      where: { status: 'Active' },
      select: {
        totalAmount: true,
        advancePaid: true,
        remainingAmount: true,
        paymentStatus: true,
        createdAt: true,
        invoiceNumber: true,
        dealer: {
          select: {
            name: true,
            company: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const totalSales = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const totalPending = invoices
      .filter((inv) => inv.paymentStatus !== 'Paid')
      .reduce((sum, inv) => sum + inv.remainingAmount, 0);
    const totalPaid = invoices.reduce((sum, inv) => sum + inv.advancePaid, 0);
    const totalInvoices = invoices.length;

    const recentInvoices = invoices.slice(0, 10).map((inv) => ({
      invoiceNumber: inv.invoiceNumber,
      dealerName: inv.dealer.name,
      dealerCompany: inv.dealer.company,
      totalAmount: inv.totalAmount,
      advancePaid: inv.advancePaid,
      remainingAmount: inv.remainingAmount,
      paymentStatus: inv.paymentStatus,
      createdAt: inv.createdAt,
    }));

    return NextResponse.json({
      totalSales,
      totalPending,
      totalPaid,
      totalInvoices,
      recentInvoices,
    });
  } catch (error: any) {
    console.error('Error fetching invoice stats:', error);
    return NextResponse.json(
      { error: 'Failed to fetch invoice stats' },
      { status: 500 }
    );
  }
}
