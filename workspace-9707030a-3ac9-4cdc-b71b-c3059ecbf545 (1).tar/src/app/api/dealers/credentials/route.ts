import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

// Generate a readable random password
function generatePassword(length = 10): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghjkmnpqrstuvwxyz';
  const digits = '23456789';
  const chars = upper + lower + digits;
  let pwd = '';
  pwd += upper[Math.floor(Math.random() * upper.length)];
  pwd += lower[Math.floor(Math.random() * lower.length)];
  pwd += digits[Math.floor(Math.random() * digits.length)];
  for (let i = pwd.length; i < length; i++) {
    pwd += chars[Math.floor(Math.random() * chars.length)];
  }
  return pwd.split('').sort(() => Math.random() - 0.5).join('');
}

// POST /api/dealers/credentials
// Body: { dealerId, password? }
// Resets the dealer's password. If no password provided, generates a random one.
// Returns the new credentials so the admin can share them.
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { dealerId, password } = body;

    if (!dealerId) {
      return NextResponse.json(
        { error: 'Dealer ID is required' },
        { status: 400 }
      );
    }

    // Find the dealer
    const dealer = await db.dealer.findUnique({
      where: { id: dealerId },
    });

    if (!dealer) {
      return NextResponse.json(
        { error: 'Dealer not found' },
        { status: 404 }
      );
    }

    // Find the user account linked to this dealer
    const user = await db.user.findUnique({
      where: { dealerId },
    });

    if (!user) {
      // No user account exists — create one
      const plainPassword = password || generatePassword();
      const hashedPassword = await bcrypt.hash(plainPassword, 10);

      await db.user.create({
        data: {
          email: dealer.email,
          password: hashedPassword,
          name: dealer.name,
          role: 'dealer',
          dealerId: dealer.id,
        },
      });

      return NextResponse.json({
        message: 'Login account created for this dealer',
        credentials: {
          email: dealer.email,
          password: plainPassword,
        },
      });
    }

    // User exists — reset password
    const plainPassword = password || generatePassword();
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    await db.user.update({
      where: { id: user.id },
      data: { password: hashedPassword },
    });

    return NextResponse.json({
      message: 'Password reset successfully',
      credentials: {
        email: user.email,
        password: plainPassword,
      },
    });
  } catch (error: any) {
    console.error('Error resetting dealer credentials:', error);
    return NextResponse.json(
      { error: 'Failed to reset credentials' },
      { status: 500 }
    );
  }
}
