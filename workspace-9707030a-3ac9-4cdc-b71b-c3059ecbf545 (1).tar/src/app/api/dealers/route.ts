import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

// --- Helpers ---
function generatePassword(length = 10): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // no I,O to avoid confusion
  const lower = 'abcdefghjkmnpqrstuvwxyz'; // no i,l,o
  const digits = '23456789'; // no 0,1
  const chars = upper + lower + digits;
  let pwd = '';
  // guarantee at least one of each
  pwd += upper[Math.floor(Math.random() * upper.length)];
  pwd += lower[Math.floor(Math.random() * lower.length)];
  pwd += digits[Math.floor(Math.random() * digits.length)];
  for (let i = pwd.length; i < length; i++) {
    pwd += chars[Math.floor(Math.random() * chars.length)];
  }
  // shuffle
  return pwd.split('').sort(() => Math.random() - 0.5).join('');
}

// GET /api/dealers?search=...
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';

    const dealers = await db.dealer.findMany({
      where: search
        ? {
            OR: [
              { name: { contains: search } },
              { company: { contains: search } },
              { email: { contains: search } },
              { phone: { contains: search } },
              { city: { contains: search } },
            ],
          }
        : undefined,
      include: {
        user: {
          select: { id: true, email: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ dealers });
  } catch (error: any) {
    console.error('Error fetching dealers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch dealers' },
      { status: 500 }
    );
  }
}

// POST /api/dealers — creates dealer AND a login user account
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, company, email, phone, address, city, state, zipCode, password } = body;

    if (!name || !email || !phone) {
      return NextResponse.json(
        { error: 'Name, email, and phone are required' },
        { status: 400 }
      );
    }

    // Check if a user with this email already exists
    const existingUser = await db.user.findUnique({ where: { email } });
    if (existingUser) {
      return NextResponse.json(
        { error: 'A user with this email already exists' },
        { status: 409 }
      );
    }

    // Use provided password or generate a random one
    const plainPassword = password || generatePassword();
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    // Create dealer + user in a transaction
    const dealer = await db.$transaction(async (tx) => {
      const newDealer = await tx.dealer.create({
        data: {
          name,
          company: company || null,
          email,
          phone,
          address: address || null,
          city: city || null,
          state: state || null,
          zipCode: zipCode || null,
        },
      });

      await tx.user.create({
        data: {
          email,
          password: hashedPassword,
          name,
          role: 'dealer',
          dealerId: newDealer.id,
        },
      });

      return newDealer;
    });

    // Return dealer data + the plain password so admin can share it
    return NextResponse.json({
      dealer,
      credentials: {
        email,
        password: plainPassword,
      },
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating dealer:', error);

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'A dealer with this email already exists' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to create dealer' },
      { status: 500 }
    );
  }
}

// PUT /api/dealers
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...fields } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Dealer ID is required' },
        { status: 400 }
      );
    }

    const dealer = await db.dealer.update({
      where: { id },
      data: fields,
    });

    return NextResponse.json(dealer);
  } catch (error: any) {
    console.error('Error updating dealer:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Dealer not found' },
        { status: 404 }
      );
    }

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'A dealer with this email already exists' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to update dealer' },
      { status: 500 }
    );
  }
}

// DELETE /api/dealers?id=...
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Dealer ID is required' },
        { status: 400 }
      );
    }

    // Delete the dealer's user account first, then the dealer
    await db.$transaction(async (tx) => {
      await tx.user.deleteMany({ where: { dealerId: id } });
      await tx.dealer.delete({ where: { id } });
    });

    return NextResponse.json({ message: 'Dealer deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting dealer:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Dealer not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to delete dealer' },
      { status: 500 }
    );
  }
}
