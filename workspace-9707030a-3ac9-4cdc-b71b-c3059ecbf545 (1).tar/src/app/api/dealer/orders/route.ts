import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

// POST /api/dealer/orders
// JSON body fields:
//   - items: [{ inventoryItemId, quantity }]
//   - advancePaid: number
//   - paymentType: "none" | "partial" | "full"
//   - notes (optional)
export async function POST(request: NextRequest) {
  try {
    // 1. Verify dealer is logged in
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to place an order' },
        { status: 401 }
      );
    }

    const tokenUser = session.user as Record<string, unknown>;
    const role = tokenUser.role;
    const dealerId = tokenUser.dealerId as string | null;

    if (role !== 'dealer' || !dealerId) {
      return NextResponse.json(
        { error: 'Only dealers can place orders' },
        { status: 403 }
      );
    }

    // 2. Parse JSON body
    const body = await request.json();
    const items: Array<{ inventoryItemId: string; quantity: number }> = body.items || [];
    const advancePaidStr = body.advancePaid;
    const paymentType: string = body.paymentType || 'none';
    const notes: string | undefined = body.notes;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: 'Please add at least one item to your order' },
        { status: 400 }
      );
    }

    // 3. Validate dealer exists
    const dealer = await db.dealer.findUnique({
      where: { id: dealerId },
    });

    if (!dealer) {
      return NextResponse.json(
        { error: 'Dealer account not found' },
        { status: 404 }
      );
    }

    // 4. Validate inventory items and calculate totals
    let totalQuantity = 0;
    let totalAmount = 0;
    const invoiceItemsData: Array<{
      inventoryItemId: string;
      quantity: number;
      unitPrice: number;
      totalPrice: number;
    }> = [];

    for (const item of items) {
      if (!item.inventoryItemId || !item.quantity) {
        return NextResponse.json(
          { error: 'Each item must have inventoryItemId and quantity' },
          { status: 400 }
        );
      }

      const qty = Number(item.quantity);
      if (qty < 1) {
        return NextResponse.json(
          { error: 'Quantity must be at least 1' },
          { status: 400 }
        );
      }

      const inventoryItem = await db.inventoryItem.findUnique({
        where: { id: item.inventoryItemId },
      });

      if (!inventoryItem) {
        return NextResponse.json(
          { error: `Item not found` },
          { status: 404 }
        );
      }

      if (inventoryItem.quantity < qty) {
        return NextResponse.json(
          { error: `Insufficient stock. Available: ${inventoryItem.quantity}, Requested: ${qty}` },
          { status: 400 }
        );
      }

      const unitPrice = Number(inventoryItem.sellingPrice);
      totalQuantity += qty;
      totalAmount += qty * unitPrice;

      invoiceItemsData.push({
        inventoryItemId: item.inventoryItemId,
        quantity: qty,
        unitPrice,
        totalPrice: qty * unitPrice,
      });
    }

    // 5. Calculate payment info
    let advance = 0;
    let paymentStatus = 'Unpaid';

    if (paymentType === 'full') {
      advance = totalAmount;
      paymentStatus = 'Paid';
    } else if (paymentType === 'partial') {
      advance = parseFloat(String(advancePaidStr)) || 0;
      if (advance > 0 && advance < totalAmount) {
        paymentStatus = 'Partial';
      } else if (advance >= totalAmount) {
        // Treat as full if amount meets or exceeds total
        advance = totalAmount;
        paymentStatus = 'Paid';
      } else {
        advance = 0;
        paymentStatus = 'Unpaid';
      }
    }

    const remainingAmount = Math.max(0, totalAmount - advance);

    // 6. Generate invoice number
    const lastInvoice = await db.invoice.findFirst({
      orderBy: { invoiceNumber: 'desc' },
      select: { invoiceNumber: true },
    });

    let nextNumber = 1;
    if (lastInvoice && lastInvoice.invoiceNumber) {
      const numStr = lastInvoice.invoiceNumber.replace('INV-', '');
      const lastNum = parseInt(numStr);
      if (!isNaN(lastNum)) {
        nextNumber = lastNum + 1;
      }
    }

    const invoiceNumber = `INV-${String(nextNumber).padStart(4, '0')}`;

    // 7. Create invoice
    const invoice = await db.invoice.create({
      data: {
        invoiceNumber,
        dealerId,
        totalQuantity,
        totalAmount,
        advancePaid: advance,
        remainingAmount,
        paymentStatus,
        notes: notes || null,
        items: {
          create: invoiceItemsData,
        },
      },
      include: {
        dealer: true,
        items: {
          include: {
            inventoryItem: {
              include: {
                category: true,
                productType: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json({
      message: 'Order placed successfully',
      invoice,
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error placing dealer order:', error);

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'Invoice number collision, please try again' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to place order' },
      { status: 500 }
    );
  }
}
