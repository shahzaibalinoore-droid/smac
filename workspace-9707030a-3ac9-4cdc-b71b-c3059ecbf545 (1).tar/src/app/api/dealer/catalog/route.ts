import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/dealer/catalog?search=...&categoryId=...&productTypeId=...
// Returns inventory items with ONLY selling price (no cost/discount info exposed to dealers)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const categoryId = searchParams.get('categoryId');
    const productTypeId = searchParams.get('productTypeId');

    const where: any = {};

    // Only show items with quantity > 0
    where.quantity = { gt: 0 };

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (productTypeId) {
      where.productTypeId = productTypeId;
    }

    if (search) {
      where.OR = [
        { category: { name: { contains: search } } },
        { category: { codePrefix: { contains: search } } },
        { productType: { name: { contains: search } } },
        { productType: { code: { contains: search } } },
      ];
    }

    const catalog = await db.inventoryItem.findMany({
      where: Object.keys(where).length > 0 ? where : { quantity: { gt: 0 } },
      include: {
        category: {
          select: { id: true, name: true, codePrefix: true },
        },
        productType: {
          select: { id: true, name: true, code: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Return only dealer-safe fields (no costPrice, no discountPrice)
    const safeCatalog = catalog.map((item) => ({
      id: item.id,
      category: item.category,
      categoryCode: item.categoryCode,
      productType: item.productType,
      quantity: item.quantity,
      sellingPrice: item.sellingPrice,
    }));

    return NextResponse.json({ catalog: safeCatalog });
  } catch (error: any) {
    console.error('Error fetching dealer catalog:', error);
    return NextResponse.json(
      { error: 'Failed to fetch catalog' },
      { status: 500 }
    );
  }
}
