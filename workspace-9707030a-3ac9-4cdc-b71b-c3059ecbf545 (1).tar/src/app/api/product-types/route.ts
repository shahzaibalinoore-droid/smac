import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/product-types
export async function GET() {
  try {
    const productTypes = await db.productType.findMany({
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { inventory: true },
        },
      },
    });

    return NextResponse.json({ productTypes });
  } catch (error: any) {
    console.error('Error fetching product types:', error);
    return NextResponse.json(
      { error: 'Failed to fetch product types' },
      { status: 500 }
    );
  }
}

// POST /api/product-types
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code, name, description } = body;

    if (!code || !name) {
      return NextResponse.json(
        { error: 'Code and name are required' },
        { status: 400 }
      );
    }

    const productType = await db.productType.create({
      data: {
        code,
        name,
        description: description || null,
      },
    });

    return NextResponse.json(productType, { status: 201 });
  } catch (error: any) {
    console.error('Error creating product type:', error);

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'A product type with this code already exists' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to create product type' },
      { status: 500 }
    );
  }
}

// PUT /api/product-types
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...fields } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Product type ID is required' },
        { status: 400 }
      );
    }

    const productType = await db.productType.update({
      where: { id },
      data: fields,
    });

    return NextResponse.json(productType);
  } catch (error: any) {
    console.error('Error updating product type:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Product type not found' },
        { status: 404 }
      );
    }

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'A product type with this code already exists' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to update product type' },
      { status: 500 }
    );
  }
}

// DELETE /api/product-types?id=...
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Product type ID is required' },
        { status: 400 }
      );
    }

    await db.productType.delete({
      where: { id },
    });

    return NextResponse.json({ message: 'Product type deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting product type:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Product type not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to delete product type' },
      { status: 500 }
    );
  }
}
