import NextAuth from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

const handler = NextAuth(authOptions);

// Wrap POST to auto-seed on first authentication attempt
async function handlerWithSeed(req: Request, ctx: { params: Promise<{ nextauth: string[] }> }) {
  // Auto-seed if database is empty (first deploy)
  try {
    const userCount = await db.user.count();
    if (userCount === 0) {
      console.log("[seed] No users found. Running auto-seed...");
      const { autoSeed } = await import("@/lib/auto-seed");
      await autoSeed();
      console.log("[seed] Auto-seed complete.");
    }
  } catch (err) {
    console.error("[seed] Auto-seed check failed:", err);
  }

  return handler(req, ctx);
}

export { handlerWithSeed as GET, handlerWithSeed as POST };
