import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/inventory/csv
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json(
        { error: 'No file uploaded' },
        { status: 400 }
      );
    }

    const fileContent = await file.text();
    const lines = fileContent.trim().split('\n');

    if (lines.length < 2) {
      return NextResponse.json(
        { error: 'CSV file is empty or has no data rows' },
        { status: 400 }
      );
    }

    // Parse header
    const headers = lines[0].split(',').map((h: string) => h.trim().toLowerCase());

    const categoryCodeIdx = headers.indexOf('categorycode');
    const productTypeIdx = headers.indexOf('producttype');
    const quantityIdx = headers.indexOf('quantity');
    const costPriceIdx = headers.indexOf('costprice');
    const discountPriceIdx = headers.indexOf('discountprice');
    const sellingPriceIdx = headers.indexOf('sellingprice');

    if (categoryCodeIdx === -1 || productTypeIdx === -1 || quantityIdx === -1) {
      return NextResponse.json(
        { error: 'CSV must have columns: categoryCode, productType, quantity' },
        { status: 400 }
      );
    }

    const results: { success: number; failed: number; errors: string[] } = {
      success: 0,
      failed: 0,
      errors: [],
    };

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const values = parseCSVLine(line);

      const categoryCodeStr = values[categoryCodeIdx]?.trim();
      const productTypeName = values[productTypeIdx]?.trim();
      const quantityStr = values[quantityIdx]?.trim();
      const costPriceStr = values[costPriceIdx]?.trim() || '0';
      const discountPriceStr = values[discountPriceIdx]?.trim() || '0';
      const sellingPriceStr = values[sellingPriceIdx]?.trim() || '0';

      if (!categoryCodeStr || !productTypeName || !quantityStr) {
        results.failed++;
        results.errors.push(`Row ${i + 1}: Missing required fields`);
        continue;
      }

      try {
        // Parse category code - could be like "A-101" or just "101"
        let categoryPrefix = '';
        let codeNumber = parseInt(categoryCodeStr);

        if (isNaN(codeNumber)) {
          // Try to extract prefix and number from code like "A-101"
          const parts = categoryCodeStr.split('-');
          if (parts.length === 2) {
            categoryPrefix = parts[0].trim();
            codeNumber = parseInt(parts[1].trim());
          }
        }

        if (isNaN(codeNumber)) {
          results.failed++;
          results.errors.push(`Row ${i + 1}: Invalid category code "${categoryCodeStr}"`);
          continue;
        }

        const quantity = parseInt(quantityStr);
        if (isNaN(quantity)) {
          results.failed++;
          results.errors.push(`Row ${i + 1}: Invalid quantity "${quantityStr}"`);
          continue;
        }

        const costPrice = parseFloat(costPriceStr) || 0;
        const discountPrice = parseFloat(discountPriceStr) || 0;
        const sellingPrice = parseFloat(sellingPriceStr) || 0;

        // Find category by prefix (if provided) or find any matching range
        let category;
        if (categoryPrefix) {
          category = await db.category.findUnique({
            where: { codePrefix: categoryPrefix },
          });
        } else {
          // Find a category whose code range includes the code number
          category = await db.category.findFirst({
            where: {
              codeStart: { lte: codeNumber },
              codeEnd: { gte: codeNumber },
            },
          });
        }

        if (!category) {
          results.failed++;
          results.errors.push(`Row ${i + 1}: Category not found for code "${categoryCodeStr}"`);
          continue;
        }

        // Find or create product type
        let productType = await db.productType.findFirst({
          where: {
            name: { contains: productTypeName, mode: 'insensitive' },
          },
        });

        if (!productType) {
          // Create product type with a code based on the name
          const code = productTypeName.substring(0, 3).toUpperCase() + '-' + Date.now().toString().slice(-4);
          productType = await db.productType.create({
            data: { code, name: productTypeName },
          });
        }

        // Upsert inventory item
        const existingItem = await db.inventoryItem.findUnique({
          where: {
            categoryId_categoryCode_productTypeId: {
              categoryId: category.id,
              categoryCode: codeNumber,
              productTypeId: productType.id,
            },
          },
        });

        if (existingItem) {
          await db.inventoryItem.update({
            where: { id: existingItem.id },
            data: {
              quantity: existingItem.quantity + quantity,
              costPrice,
              discountPrice,
              sellingPrice,
            },
          });
        } else {
          await db.inventoryItem.create({
            data: {
              categoryId: category.id,
              categoryCode: codeNumber,
              productTypeId: productType.id,
              quantity,
              costPrice,
              discountPrice,
              sellingPrice,
            },
          });
        }

        results.success++;
      } catch (err: any) {
        results.failed++;
        results.errors.push(`Row ${i + 1}: ${err.message}`);
      }
    }

    return NextResponse.json({
      message: `CSV import complete: ${results.success} items imported, ${results.failed} failed`,
      ...results,
    });
  } catch (error: any) {
    console.error('Error processing CSV:', error);
    return NextResponse.json(
      { error: 'Failed to process CSV file' },
      { status: 500 }
    );
  }
}

// Simple CSV line parser that handles basic quoted values
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}
