import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/inventory?search=...&categoryId=...&productTypeId=...
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const categoryId = searchParams.get('categoryId');
    const productTypeId = searchParams.get('productTypeId');

    const where: any = {};

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (productTypeId) {
      where.productTypeId = productTypeId;
    }

    if (search) {
      where.OR = [
        { category: { name: { contains: search } } },
        { category: { codePrefix: { contains: search } } },
        { productType: { name: { contains: search } } },
        { productType: { code: { contains: search } } },
      ];
    }

    const inventory = await db.inventoryItem.findMany({
      where: Object.keys(where).length > 0 ? where : undefined,
      include: {
        category: true,
        productType: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ inventory });
  } catch (error: any) {
    console.error('Error fetching inventory:', error);
    return NextResponse.json(
      { error: 'Failed to fetch inventory' },
      { status: 500 }
    );
  }
}

// POST /api/inventory
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      categoryId,
      categoryCode,
      productTypeId,
      quantity,
      costPrice,
      discountPrice,
      sellingPrice,
    } = body;

    if (!categoryId || !productTypeId || categoryCode === undefined || quantity === undefined) {
      return NextResponse.json(
        { error: 'categoryId, categoryCode, productTypeId, and quantity are required' },
        { status: 400 }
      );
    }

    // Validate category exists and code is in range
    const category = await db.category.findUnique({
      where: { id: categoryId },
    });

    if (!category) {
      return NextResponse.json(
        { error: 'Category not found' },
        { status: 404 }
      );
    }

    if (categoryCode < category.codeStart || categoryCode > category.codeEnd) {
      return NextResponse.json(
        { error: `categoryCode must be between ${category.codeStart} and ${category.codeEnd}` },
        { status: 400 }
      );
    }

    // Validate product type exists
    const productType = await db.productType.findUnique({
      where: { id: productTypeId },
    });

    if (!productType) {
      return NextResponse.json(
        { error: 'Product type not found' },
        { status: 404 }
      );
    }

    const inventoryItem = await db.inventoryItem.create({
      data: {
        categoryId,
        categoryCode,
        productTypeId,
        quantity: quantity || 0,
        costPrice: costPrice || 0,
        discountPrice: discountPrice || 0,
        sellingPrice: sellingPrice || 0,
      },
      include: {
        category: true,
        productType: true,
      },
    });

    return NextResponse.json(inventoryItem, { status: 201 });
  } catch (error: any) {
    console.error('Error creating inventory item:', error);

    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'An inventory item with this combination already exists' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to create inventory item' },
      { status: 500 }
    );
  }
}

// PUT /api/inventory
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...fields } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Inventory item ID is required' },
        { status: 400 }
      );
    }

    const inventoryItem = await db.inventoryItem.update({
      where: { id },
      data: fields,
      include: {
        category: true,
        productType: true,
      },
    });

    return NextResponse.json(inventoryItem);
  } catch (error: any) {
    console.error('Error updating inventory item:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Inventory item not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to update inventory item' },
      { status: 500 }
    );
  }
}

// DELETE /api/inventory?id=...
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Inventory item ID is required' },
        { status: 400 }
      );
    }

    await db.inventoryItem.delete({
      where: { id },
    });

    return NextResponse.json({ message: 'Inventory item deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting inventory item:', error);

    if (error.code === 'P2025') {
      return NextResponse.json(
        { error: 'Inventory item not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to delete inventory item' },
      { status: 500 }
    );
  }
}
