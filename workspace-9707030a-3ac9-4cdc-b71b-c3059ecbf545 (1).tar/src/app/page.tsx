"use client";

import { useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { LoginForm } from "@/components/auth/login-form";
import { AdminLayout } from "@/components/admin/admin-layout";
import { DealerLayout } from "@/components/dealer/dealer-layout";
import { AdminDashboard } from "@/components/admin/dashboard";
import { DealerManagement } from "@/components/admin/dealers";
import { CategoryManagement } from "@/components/admin/categories";
import { ProductTypeManagement } from "@/components/admin/product-types";
import { InventoryManagement } from "@/components/admin/inventory";
import { PurchaseFlow } from "@/components/admin/purchases";
import { InvoiceManagement } from "@/components/admin/invoices";
import { DealerDashboard } from "@/components/dealer/dealer-dashboard";
import { DealerInvoices } from "@/components/dealer/dealer-invoices";
import { DealerOrderPage } from "@/components/dealer/dealer-order";
import { Loader2 } from "lucide-react";

function AdminContent() {
  const adminView = useAppStore((s) => s.adminView);
  switch (adminView) {
    case "dashboard":
      return <AdminDashboard />;
    case "dealers":
      return <DealerManagement />;
    case "categories":
      return <CategoryManagement />;
    case "product-types":
      return <ProductTypeManagement />;
    case "inventory":
      return <InventoryManagement />;
    case "purchases":
      return <PurchaseFlow />;
    case "invoices":
      return <InvoiceManagement />;
    default:
      return <AdminDashboard />;
  }
}

function DealerContent() {
  const dealerView = useAppStore((s) => s.dealerView);
  const dealerId = useAppStore((s) => s.user?.dealerId) || "";
  switch (dealerView) {
    case "dashboard":
      return <DealerDashboard dealerId={dealerId} />;
    case "invoices":
      return <DealerInvoices dealerId={dealerId} />;
    case "order":
      return <DealerOrderPage />;
    case "purchases":
      return <DealerInvoices dealerId={dealerId} />;
    default:
      return <DealerDashboard dealerId={dealerId} />;
  }
}

export default function Home() {
  const { user, isLoading, setUser, setLoading } = useAppStore();

  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await fetch("/api/auth/session");
        const session = await res.json();

        if (session?.user) {
          setUser({
            id: (session.user as Record<string, unknown>).id as string || "",
            email: session.user.email || "",
            name: session.user.name || "",
            role: (session.user as Record<string, unknown>).role as "admin" | "dealer",
            dealerId: (session.user as Record<string, unknown>).dealerId as string | null,
            dealerName: (session.user as Record<string, unknown>).dealerName as string | null,
          });
        }
      } catch {
        // Session check failed, show login
      } finally {
        setLoading(false);
      }
    };

    checkSession();
  }, [setUser, setLoading]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  if (user.role === "admin") {
    return (
      <AdminLayout>
        <AdminContent />
      </AdminLayout>
    );
  }

  if (user.role === "dealer" && user.dealerId) {
    return (
      <DealerLayout>
        <DealerContent />
      </DealerLayout>
    );
  }

  return <LoginForm />;
}

