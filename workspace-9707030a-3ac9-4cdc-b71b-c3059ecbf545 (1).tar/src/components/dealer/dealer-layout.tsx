"use client";

import { useAppStore } from "@/lib/store";
import type { DealerView } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  LayoutDashboard,
  FileText,
  LogOut,
  Menu,
  X,
  Package,
  KeyRound,
  ShoppingCart,
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const navItems: { id: DealerView; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "order", label: "Place Order", icon: ShoppingCart },
  { id: "invoices", label: "My Invoices", icon: FileText },
  { id: "purchases", label: "Purchase History", icon: Package },
];

export function DealerLayout({ children }: { children: React.ReactNode }) {
  const { user, dealerView, setDealerView, logout } = useAppStore();
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Change Password dialog
  const [pwdOpen, setPwdOpen] = useState(false);
  const [currentPwd, setCurrentPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [pwdErrors, setPwdErrors] = useState<Record<string, string>>({});
  const [pwdSubmitting, setPwdSubmitting] = useState(false);

  function openChangePassword() {
    setCurrentPwd("");
    setNewPwd("");
    setConfirmPwd("");
    setPwdErrors({});
    setSidebarOpen(false);
    setPwdOpen(true);
  }

  async function handleChangePassword() {
    const errors: Record<string, string> = {};
    if (!currentPwd) errors.currentPwd = "Current password is required";
    if (!newPwd) errors.newPwd = "New password is required";
    else if (newPwd.length < 6) errors.newPwd = "Minimum 6 characters";
    if (newPwd !== confirmPwd) errors.confirmPwd = "Passwords do not match";

    setPwdErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setPwdSubmitting(true);
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: currentPwd, newPassword: newPwd }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to change password");
      }

      toast({
        title: "Password Changed",
        description: "Your password has been updated successfully.",
      });
      setPwdOpen(false);
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to change password",
        variant: "destructive",
      });
    } finally {
      setPwdSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen flex bg-muted/30">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-background border-r flex flex-col transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 h-16 border-b">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-primary text-primary-foreground">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-none">Beraj Digital</h1>
            <p className="text-xs text-muted-foreground">Dealer Portal</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 py-4">
          <nav className="space-y-1 px-3">
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant={dealerView === item.id ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 h-10",
                  dealerView === item.id && "bg-secondary font-medium"
                )}
                onClick={() => {
                  setDealerView(item.id);
                  setSidebarOpen(false);
                }}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Button>
            ))}

            {/* Change Password link */}
            <div className="pt-4 mt-4 border-t">
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 h-10 text-muted-foreground hover:text-foreground"
                onClick={openChangePassword}
              >
                <KeyRound className="w-4 h-4" />
                Change Password
              </Button>
            </div>
          </nav>
        </ScrollArea>

        {/* User info + Logout */}
        <div className="border-t p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-full bg-primary/10 text-primary font-semibold text-sm">
              {user?.name?.charAt(0) || "D"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.name}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.dealerName || "Dealer"}</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full gap-2"
            onClick={logout}
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-16 border-b bg-background flex items-center gap-4 px-4 lg:px-6 sticky top-0 z-30">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h2 className="text-lg font-semibold">
              {navItems.find((n) => n.id === dealerView)?.label || "Dashboard"}
            </h2>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6">
          {children}
        </main>

        {/* Footer */}
        <footer className="border-t bg-background px-4 lg:px-6 py-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Beraj Digital Inventory &copy; {new Date().getFullYear()}</span>
            <span>Dealer Portal</span>
          </div>
        </footer>
      </div>

      {/* ============================================================ */}
      {/*  Change Password Dialog                                        */}
      {/* ============================================================ */}
      <Dialog open={pwdOpen} onOpenChange={(o) => { if (!o) setPwdOpen(false); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound className="h-5 w-5 text-primary" />
              Change Password
            </DialogTitle>
            <DialogDescription>
              Update your account password. You will need to use the new password on your next login.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label htmlFor="cp-current">Current Password</Label>
              <Input
                id="cp-current"
                type="password"
                placeholder="Enter current password"
                value={currentPwd}
                onChange={(e) => setCurrentPwd(e.target.value)}
              />
              {pwdErrors.currentPwd && (
                <p className="text-xs text-destructive">{pwdErrors.currentPwd}</p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="cp-new">New Password</Label>
              <Input
                id="cp-new"
                type="password"
                placeholder="Enter new password (min 6 chars)"
                value={newPwd}
                onChange={(e) => setNewPwd(e.target.value)}
              />
              {pwdErrors.newPwd && (
                <p className="text-xs text-destructive">{pwdErrors.newPwd}</p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="cp-confirm">Confirm New Password</Label>
              <Input
                id="cp-confirm"
                type="password"
                placeholder="Re-enter new password"
                value={confirmPwd}
                onChange={(e) => setConfirmPwd(e.target.value)}
              />
              {pwdErrors.confirmPwd && (
                <p className="text-xs text-destructive">{pwdErrors.confirmPwd}</p>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setPwdOpen(false)} disabled={pwdSubmitting}>
              Cancel
            </Button>
            <Button onClick={handleChangePassword} disabled={pwdSubmitting}>
              {pwdSubmitting ? "Changing..." : "Update Password"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
