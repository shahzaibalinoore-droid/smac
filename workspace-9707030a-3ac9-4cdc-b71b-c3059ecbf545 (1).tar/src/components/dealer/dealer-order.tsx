"use client";

import { useState, useEffect, useCallback } from "react";
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Search,
  CheckCircle,
  Package,
  Loader2,
  X,
  Send,
  Tag,
  CreditCard,
  Banknote,
  Clock,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Category, ProductType } from "@/lib/types";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// ── Helpers ──────────────────────────────────────────────────────────

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

interface CatalogItem {
  id: string;
  category: { id: string; name: string; codePrefix: string };
  categoryCode: number;
  productType: { id: string; name: string; code: string };
  quantity: number;
  sellingPrice: number;
}

interface CartItem {
  inventoryItemId: string;
  catalogItem: CatalogItem;
  quantity: number;
}

type PaymentOption = "none" | "partial" | "full";

// ── Component ────────────────────────────────────────────────────────

export function DealerOrderPage() {
  const { toast } = useToast();

  // ---- Data ----
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);

  // ---- Loading ----
  const [loadingCatalog, setLoadingCatalog] = useState(true);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [loadingProductTypes, setLoadingProductTypes] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // ---- Filters ----
  const [filterCategory, setFilterCategory] = useState("");
  const [filterProductType, setFilterProductType] = useState("");
  const [search, setSearch] = useState("");

  // ---- Cart ----
  const [cart, setCart] = useState<CartItem[]>([]);
  const [addingItemId, setAddingItemId] = useState<string | null>(null);
  const [addQty, setAddQty] = useState<Record<string, string>>({});

  // ---- Payment ----
  const [paymentType, setPaymentType] = useState<PaymentOption>("none");
  const [advancePaid, setAdvancePaid] = useState("");

  // ---- Order Notes ----
  const [notes, setNotes] = useState("");

  // ---- Order Confirmation ----
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderResult, setOrderResult] = useState<{
    invoiceNumber: string;
    paymentStatus: string;
    advancePaid: number;
    totalAmount: number;
    remainingAmount: number;
  } | null>(null);

  // ==================== Data Fetching ====================

  const fetchCategories = useCallback(async () => {
    try {
      setLoadingCategories(true);
      const res = await fetch("/api/categories");
      if (!res.ok) throw new Error();
      const data = await res.json();
      setCategories(data.categories ?? []);
    } catch {
      toast({ title: "Error", description: "Failed to load categories", variant: "destructive" });
    } finally {
      setLoadingCategories(false);
    }
  }, [toast]);

  const fetchProductTypes = useCallback(async () => {
    try {
      setLoadingProductTypes(true);
      const res = await fetch("/api/product-types");
      if (!res.ok) throw new Error();
      const data = await res.json();
      setProductTypes(data.productTypes ?? []);
    } catch {
      toast({ title: "Error", description: "Failed to load product types", variant: "destructive" });
    } finally {
      setLoadingProductTypes(false);
    }
  }, [toast]);

  const fetchCatalog = useCallback(async () => {
    try {
      setLoadingCatalog(true);
      const params = new URLSearchParams();
      if (filterCategory) params.set("categoryId", filterCategory);
      if (filterProductType) params.set("productTypeId", filterProductType);
      if (search) params.set("search", search);
      const res = await fetch(`/api/dealer/catalog?${params.toString()}`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      setCatalog(data.catalog ?? []);
    } catch {
      toast({ title: "Error", description: "Failed to load catalog", variant: "destructive" });
    } finally {
      setLoadingCatalog(false);
    }
  }, [filterCategory, filterProductType, search, toast]);

  useEffect(() => {
    fetchCategories();
    fetchProductTypes();
  }, [fetchCategories, fetchProductTypes]);

  useEffect(() => {
    fetchCatalog();
  }, [fetchCatalog]);

  // ==================== Cart Logic ====================

  const isInCart = (itemId: string) => cart.some((c) => c.inventoryItemId === itemId);
  const getCartQty = (itemId: string) => cart.find((c) => c.inventoryItemId === itemId)?.quantity ?? 0;
  const getAvailableQty = (item: CatalogItem) => item.quantity - getCartQty(item.id);

  const handleAddToCart = (item: CatalogItem) => {
    const qtyStr = addQty[item.id];
    const qty = qtyStr ? parseInt(qtyStr, 10) : 1;
    if (qty < 1) return;

    setCart((prev) => {
      const existing = prev.find((c) => c.inventoryItemId === item.id);
      if (existing) {
        return prev.map((c) =>
          c.inventoryItemId === item.id ? { ...c, quantity: c.quantity + qty } : c
        );
      }
      return [...prev, { inventoryItemId: item.id, catalogItem: item, quantity: qty }];
    });
    setAddQty((prev) => { const next = { ...prev }; delete next[item.id]; return next; });
    setAddingItemId(null);
  };

  const handleUpdateCartQty = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      setCart((prev) => prev.filter((c) => c.inventoryItemId !== itemId));
    } else {
      setCart((prev) =>
        prev.map((c) =>
          c.inventoryItemId === itemId ? { ...c, quantity: newQty } : c
        )
      );
    }
  };

  const handleRemoveFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((c) => c.inventoryItemId !== itemId));
  };

  // ==================== Computed Values ====================

  const cartTotal = cart.reduce((sum, c) => sum + c.catalogItem.sellingPrice * c.quantity, 0);
  const cartTotalQty = cart.reduce((sum, c) => sum + c.quantity, 0);
  const advanceNum = advancePaid ? parseFloat(advancePaid) : 0;
  const remainingNum = Math.max(0, cartTotal - advanceNum);

  const clearFilters = () => {
    setFilterCategory("");
    setFilterProductType("");
    setSearch("");
  };
  const hasFilters = filterCategory || filterProductType || search;

  // ==================== Submit Order ====================

  const handleSubmitOrder = async () => {
    if (cart.length === 0) return;

    // Validation
    if (paymentType === "partial" && (advanceNum <= 0 || advanceNum >= cartTotal)) {
      toast({
        title: "Invalid Amount",
        description: "Partial payment must be greater than Rs 0 and less than the total.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/dealer/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cart.map((c) => ({ inventoryItemId: c.inventoryItemId, quantity: c.quantity })),
          advancePaid: advanceNum,
          paymentType,
          notes: notes.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to place order");

      const inv = data.invoice;
      setOrderResult({
        invoiceNumber: inv.invoiceNumber ?? "",
        paymentStatus: inv.paymentStatus ?? "Unpaid",
        advancePaid: inv.advancePaid ?? 0,
        totalAmount: inv.totalAmount ?? 0,
        remainingAmount: inv.remainingAmount ?? 0,
      });
      setOrderComplete(true);
      toast({
        title: "Order Placed!",
        description: `Order ${inv.invoiceNumber ?? ""} submitted successfully.`,
      });
    } catch (err) {
      toast({
        title: "Order Failed",
        description: err instanceof Error ? err.message : "Failed to place order",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleNewOrder = () => {
    setCart([]);
    setNotes("");
    setPaymentType("none");
    setAdvancePaid("");
    setOrderComplete(false);
    setOrderResult(null);
    fetchCatalog();
  };

  // ==================== Order Success Dialog ====================

  const OrderSuccessDialog = () => {
    if (!orderResult) return null;
    const isPaid = orderResult.paymentStatus === "Paid";
    const isPartial = orderResult.paymentStatus === "Partial";

    return (
      <Dialog open={orderComplete} onOpenChange={(o) => { if (!o) handleNewOrder(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="h-6 w-6 text-[#408A71]" />
              Order Placed Successfully!
            </DialogTitle>
            <DialogDescription>
              Your order has been submitted to Beraj Digital and will be processed shortly.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="rounded-lg bg-[#EBF6F0] p-4 text-center">
              <p className="text-sm text-muted-foreground">Invoice Number</p>
              <p className="text-2xl font-bold text-[#285A48] font-mono">{orderResult.invoiceNumber}</p>
            </div>

            <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
              <h4 className="text-sm font-medium">Order Summary</h4>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Total Amount</span>
                <span className="font-bold">{formatCurrency(orderResult.totalAmount)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Amount Paid</span>
                <span className={`font-medium ${orderResult.advancePaid > 0 ? "text-[#408A71]" : ""}`}>
                  {formatCurrency(orderResult.advancePaid)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Remaining</span>
                <span className={`font-medium ${orderResult.remainingAmount > 0 ? "text-red-600" : ""}`}>
                  {formatCurrency(orderResult.remainingAmount)}
                </span>
              </div>
              <Separator className="my-1" />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Payment Status</span>
                {isPaid ? (
                  <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">Paid</Badge>
                ) : isPartial ? (
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200">Partial</Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-700 border-red-200">Unpaid</Badge>
                )}
              </div>
            </div>

            <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800 dark:border-blue-800 dark:bg-blue-950/50 dark:text-blue-200">
              <strong>Note:</strong>{" "}
              {isPaid
                ? "Your payment is confirmed. Your order will be processed shortly."
                : isPartial
                  ? `You paid ${formatCurrency(orderResult.advancePaid)}. Remaining ${formatCurrency(orderResult.remainingAmount)} is due. Contact Beraj Digital for payment details.`
                  : "No payment was made. Contact Beraj Digital to arrange payment. You can track this order in \"My Invoices\"."}
            </div>
          </div>

          <DialogFooter>
            <Button onClick={handleNewOrder}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Place Another Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  // ==================== Render ====================

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Place Order</h2>
          <p className="text-sm text-muted-foreground">
            Browse our catalog and add items to your order
          </p>
        </div>
        {cart.length > 0 && (
          <Button onClick={handleSubmitOrder} disabled={submitting} className="gap-2">
            {submitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            {submitting ? "Submitting..." : `Submit Order (${formatCurrency(cartTotal)})`}
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
            <div className="flex-1 space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Search</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by category, product type, code..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="w-full space-y-1.5 lg:w-48">
              <Label className="text-xs font-medium text-muted-foreground">Category</Label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-full space-y-1.5 lg:w-48">
              <Label className="text-xs font-medium text-muted-foreground">Product Type</Label>
              <Select value={filterProductType} onValueChange={setFilterProductType}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  {productTypes.map((pt) => (
                    <SelectItem key={pt.id} value={pt.id}>
                      {pt.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {hasFilters && (
              <Button variant="ghost" size="sm" className="shrink-0" onClick={clearFilters}>
                <X className="mr-1 h-4 w-4" />
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Catalog + Cart Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Catalog Items */}
        <div className="lg:col-span-2">
          {loadingCatalog ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Card key={i} className="p-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-4 w-40 flex-1" />
                    <Skeleton className="h-4 w-28" />
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-9 w-20" />
                  </div>
                </Card>
              ))}
            </div>
          ) : catalog.length === 0 ? (
            <Card className="p-8">
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Package className="h-10 w-10" />
                <p className="text-sm font-medium">No items available</p>
                <p className="text-xs">Try adjusting your filters</p>
              </div>
            </Card>
          ) : (
            <div className="max-h-[500px] overflow-y-auto space-y-2 pr-1">
              {catalog.map((item) => {
                const inCart = isInCart(item.id);
                const available = getAvailableQty(item);
                const isAdding = addingItemId === item.id;
                const code = `${item.category.codePrefix}${item.categoryCode}`;

                return (
                  <Card
                    key={item.id}
                    className={`p-4 transition-all ${
                      inCart ? "border-[#B0E4CC] bg-[#EBF6F0]/50 dark:bg-[#1A3D30]/20" : "hover:shadow-sm"
                    }`}
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      {/* Item Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{item.category.name}</span>
                          <Badge variant="outline" className="font-mono text-xs">
                            {code}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            <Tag className="mr-1 h-3 w-3" />
                            {item.productType.name}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 mt-1">
                          <p className="text-lg font-bold text-[#285A48]">{formatCurrency(item.sellingPrice)}</p>
                          <p className="text-xs text-muted-foreground">
                            {available > 0
                              ? `${available} in stock`
                              : <span className="text-destructive font-medium">Out of stock</span>}
                          </p>
                        </div>
                      </div>

                      {/* Add / Cart Controls */}
                      <div className="flex items-center gap-2">
                        {isAdding ? (
                          <div className="flex items-center gap-1.5">
                            <Input
                              type="number"
                              min={1}
                              max={available}
                              value={addQty[item.id] || "1"}
                              onChange={(e) =>
                                setAddQty((prev) => ({ ...prev, [item.id]: e.target.value }))
                              }
                              className="w-16 h-9 text-center text-sm"
                              autoFocus
                            />
                            <Button
                              size="sm"
                              className="h-9"
                              onClick={() => handleAddToCart(item)}
                              disabled={
                                !addQty[item.id] ||
                                parseInt(addQty[item.id] || "0") < 1 ||
                                parseInt(addQty[item.id] || "0") > available
                              }
                            >
                              <CheckCircle className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-9"
                              onClick={() => {
                                setAddingItemId(null);
                                setAddQty((prev) => { const n = { ...prev }; delete n[item.id]; return n; });
                              }}
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        ) : inCart ? (
                          <div className="flex items-center gap-1.5">
                            <Button
                              size="icon"
                              variant="outline"
                              className="h-8 w-8"
                              onClick={() => handleUpdateCartQty(item.id, getCartQty(item.id) - 1)}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center font-medium text-sm">
                              {getCartQty(item.id)}
                            </span>
                            <Button
                              size="icon"
                              variant="outline"
                              className="h-8 w-8"
                              onClick={() => handleUpdateCartQty(item.id, getCartQty(item.id) + 1)}
                              disabled={available <= 0}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              onClick={() => handleRemoveFromCart(item.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-9"
                            disabled={available <= 0}
                            onClick={() => {
                              setAddingItemId(item.id);
                              setAddQty((prev) => ({ ...prev, [item.id]: "1" }));
                            }}
                          >
                            <Plus className="mr-1 h-3.5 w-3.5" />
                            Add
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>

        {/* Cart Sidebar */}
        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <ShoppingCart className="h-4 w-4" />
                Your Cart
                {cart.length > 0 && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {cartTotalQty} item{cartTotalQty !== 1 ? "s" : ""}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {cart.length === 0 ? (
                <div className="py-8 text-center">
                  <ShoppingCart className="mx-auto h-8 w-8 text-muted-foreground/30" />
                  <p className="mt-2 text-sm text-muted-foreground">
                    No items in cart
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Click &quot;Add&quot; on any item to start ordering
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Cart Items */}
                  <div className="max-h-[200px] overflow-y-auto space-y-2 pr-1">
                    {cart.map((c) => {
                      const code = `${c.catalogItem.category.codePrefix}${c.catalogItem.categoryCode}`;
                      return (
                        <div
                          key={c.inventoryItemId}
                          className="flex items-center justify-between gap-2 rounded-lg bg-muted/50 p-2.5"
                        >
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium truncate">
                              {c.catalogItem.category.name}
                            </p>
                            <p className="text-xs text-muted-foreground truncate">
                              {code} &middot; {c.catalogItem.productType.name} &middot;{" "}
                              {formatCurrency(c.catalogItem.sellingPrice)} &times; {c.quantity}
                            </p>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-sm font-semibold">
                              {formatCurrency(c.catalogItem.sellingPrice * c.quantity)}
                            </span>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-7 w-7 text-destructive hover:text-destructive"
                              onClick={() => handleRemoveFromCart(c.inventoryItemId)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <Separator />

                  {/* Total */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total</span>
                    <span className="text-xl font-bold">{formatCurrency(cartTotal)}</span>
                  </div>

                  <Separator />

                  {/* ==================== Payment Section ==================== */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      Payment
                    </h4>

                    {/* Payment Option Selector */}
                    <div className="space-y-2">
                      <Select
                        value={paymentType}
                        onValueChange={(val) => {
                          setPaymentType(val as PaymentOption);
                          if (val === "none") {
                            setAdvancePaid("");
                          }
                        }}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select payment option" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">
                            <span className="flex items-center gap-2">
                              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                              Pay Later
                            </span>
                          </SelectItem>
                          <SelectItem value="partial">
                            <span className="flex items-center gap-2">
                              <Banknote className="h-3.5 w-3.5 text-amber-600" />
                              Partial Payment
                            </span>
                          </SelectItem>
                          <SelectItem value="full">
                            <span className="flex items-center gap-2">
                              <CheckCircle className="h-3.5 w-3.5 text-[#408A71]" />
                              Full Payment
                            </span>
                          </SelectItem>
                        </SelectContent>
                      </Select>

                      {/* Info box */}
                      <div className="rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
                        {paymentType === "none" && (
                          <p>
                            Select &quot;Partial Payment&quot; or &quot;Full Payment&quot; if paying now, or choose &quot;Pay Later&quot; to pay later.
                          </p>
                        )}
                        {paymentType === "partial" && (
                          <p>
                            Enter the amount you are paying now. The remaining balance will be due later.
                          </p>
                        )}
                        {paymentType === "full" && (
                          <p>
                            You will pay the full amount of{" "}
                            <span className="font-semibold text-foreground">{formatCurrency(cartTotal)}</span>.
                          </p>
                        )}
                      </div>

                      {/* Amount Input (for partial) */}
                      {paymentType === "partial" && (
                        <div className="space-y-1.5">
                          <Label htmlFor="advance-paid" className="text-xs font-medium">
                            Payment Amount (Rs)
                          </Label>
                          <Input
                            id="advance-paid"
                            type="number"
                            min={1}
                            max={cartTotal - 1}
                            step="0.01"
                            placeholder="Enter amount"
                            value={advancePaid}
                            onChange={(e) => setAdvancePaid(e.target.value)}
                          />
                          <div className="flex justify-between text-xs text-muted-foreground mt-1">
                            <span>Min: Rs 1</span>
                            <span>Remaining: <strong className="text-foreground">{formatCurrency(remainingNum)}</strong></span>
                          </div>
                        </div>
                      )}

                      {/* Full payment summary */}
                      {paymentType === "full" && (
                        <div className="rounded-lg bg-[#EBF6F0] border border-[#B0E4CC] p-3 text-sm">
                          <div className="flex justify-between">
                            <span className="text-[#285A48]">Payment Amount</span>
                            <span className="font-bold text-[#285A48]">{formatCurrency(cartTotal)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                    </div>

                  <Separator />

                  {/* Notes */}
                  <div className="space-y-1.5">
                    <Label htmlFor="order-notes" className="text-xs">
                      Order Notes (optional)
                    </Label>
                    <Textarea
                      id="order-notes"
                      placeholder="Any special instructions..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={2}
                      className="resize-none text-sm"
                    />
                  </div>

                  {/* Submit */}
                  <Button
                    className="w-full gap-2"
                    onClick={handleSubmitOrder}
                    disabled={submitting}
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    {submitting ? "Submitting..." : `Place Order - ${formatCurrency(cartTotal)}`}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Order Success Dialog */}
      <OrderSuccessDialog />
    </div>
  );
}
