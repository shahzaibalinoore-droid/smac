"use client";

import { useEffect, useState, useCallback } from "react";
import {
  FileText,
  Eye,
  Search,
  RefreshCw,
  Clock,
  CheckCircle,
  AlertTriangle,
  Banknote,
  X,
  ShoppingBag,
  Printer,
  MessageCircle,
} from "lucide-react";
import { printInvoice, getWhatsAppLink } from "@/lib/invoice-utils";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import type { Invoice, PaymentStatus } from "@/lib/types";

// ── Currency formatter ──────────────────────────────────────────────
const currencyFormatter = new Intl.NumberFormat("en-PK", {
  style: "currency",
  currency: "PKR",
  maximumFractionDigits: 0,
});

const formatCurrency = (value: number) => currencyFormatter.format(value);

const formatDate = (dateStr: string) =>
  new Date(dateStr).toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

const formatDateTime = (dateStr: string) =>
  new Date(dateStr).toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

// ── Status badge helper ─────────────────────────────────────────────
function getStatusBadge(status: string) {
  switch (status) {
    case "Paid":
      return (
        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">
          Paid
        </Badge>
      );
    case "Partial":
      return (
        <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">
          Partial
        </Badge>
      );
    case "Unpaid":
      return (
        <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">
          Unpaid
        </Badge>
      );
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case "Paid":
      return <CheckCircle className="h-5 w-5 text-emerald-600" />;
    case "Partial":
      return <Clock className="h-5 w-5 text-amber-600" />;
    case "Unpaid":
      return <AlertTriangle className="h-5 w-5 text-red-600" />;
    default:
      return <FileText className="h-5 w-5" />;
  }
}

// ── Status filter type ──────────────────────────────────────────────
type StatusFilter = "All" | PaymentStatus;

const STATUS_OPTIONS: { label: string; value: StatusFilter }[] = [
  { label: "All", value: "All" },
  { label: "Paid", value: "Paid" },
  { label: "Partial", value: "Partial" },
  { label: "Unpaid", value: "Unpaid" },
];

// ── Skeleton loader ─────────────────────────────────────────────────
function TableSkeleton() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-4">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-4 w-20 ml-auto" />
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-5 w-16 rounded-full" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ── Detail dialog content ───────────────────────────────────────────
function InvoiceDetailDialog({
  invoice,
  open,
  onOpenChange,
}: {
  invoice: Invoice | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  if (!invoice) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {getStatusIcon(invoice.paymentStatus)}
            {invoice.invoiceNumber}
          </DialogTitle>
          <DialogDescription>
            Created on {formatDateTime(invoice.createdAt)}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Company Logo & Action Buttons */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
                src="/dashboard-bg.jpg"
                alt="Beraj Digital"
                className="h-12 w-12 rounded-xl object-cover border border-border shadow-sm"
              />
              <div>
                <h2 className="text-base font-bold text-[#285A48]">Beraj Digital Inventory</h2>
                <p className="text-[11px] text-muted-foreground">Invoice & Dealer Management</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => printInvoice(invoice)}
              >
                <Printer className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Print</span>
              </Button>
              <a
                href={getWhatsAppLink(invoice)}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5 border-green-300 text-green-700 hover:bg-green-50"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">WhatsApp</span>
                </Button>
              </a>
            </div>
          </div>

          {/* Payment Summary */}
          <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <Banknote className="h-4 w-4" />
              Payment Summary
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">Total Amount</p>
                <p className="text-lg font-bold font-mono">
                  {formatCurrency(invoice.totalAmount)}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Advance Paid</p>
                <p className="text-lg font-bold font-mono text-[#408A71]">
                  {formatCurrency(invoice.advancePaid)}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Remaining</p>
                <p
                  className={`text-lg font-bold font-mono ${
                    invoice.remainingAmount > 0
                      ? "text-red-600"
                      : "text-muted-foreground"
                  }`}
                >
                  {formatCurrency(invoice.remainingAmount)}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Status</p>
                <div className="mt-1">{getStatusBadge(invoice.paymentStatus)}</div>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <ShoppingBag className="h-4 w-4" />
              Items ({invoice.items.length})
            </h4>
            {invoice.items.length === 0 ? (
              <p className="text-sm text-muted-foreground">No items in this invoice.</p>
            ) : (
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead className="hidden sm:table-cell">Code</TableHead>
                      <TableHead className="hidden md:table-cell">Type</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoice.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">
                          {item.inventoryItem.category?.name ?? "—"}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell font-mono text-muted-foreground">
                          {item.inventoryItem.category?.codePrefix ?? ""}
                          {item.inventoryItem.categoryCode ?? ""}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {item.inventoryItem.productType?.name ?? "—"}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {item.quantity}
                        </TableCell>
                        <TableCell className="text-right font-mono text-muted-foreground">
                          {formatCurrency(item.unitPrice)}
                        </TableCell>
                        <TableCell className="text-right font-mono font-semibold">
                          {formatCurrency(item.totalPrice)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>

          {/* Notes */}
          {invoice.notes && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Notes</h4>
              <p className="text-sm text-muted-foreground rounded-lg border bg-muted/30 p-3">
                {invoice.notes}
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── Main component ──────────────────────────────────────────────────
export function DealerInvoices({ dealerId }: { dealerId: string }) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filter state
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("All");
  const [searchQuery, setSearchQuery] = useState("");

  // Detail dialog state
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const { toast } = useToast();

  // ── Data fetching ─────────────────────────────────────────────────
  const fetchInvoices = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ dealerId });
      const res = await fetch(`/api/invoices?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch invoices");
      const json = await res.json();
      setInvoices(json.invoices ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred");
      toast({
        title: "Error",
        description: "Could not load invoices.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [dealerId, toast]);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  // ── Filtering ─────────────────────────────────────────────────────
  const filteredInvoices = invoices.filter((inv) => {
    // Status filter
    if (statusFilter !== "All" && inv.paymentStatus !== statusFilter) return false;

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesInvoice = inv.invoiceNumber.toLowerCase().includes(q);
      const matchesItem = inv.items.some(
        (item) =>
          item.inventoryItem.category?.name?.toLowerCase().includes(q) ||
          item.inventoryItem.productType?.name?.toLowerCase().includes(q)
      );
      if (!matchesInvoice && !matchesItem) return false;
    }

    return true;
  });

  // ── Action handlers ───────────────────────────────────────────────
  const handleViewDetails = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setDetailOpen(true);
  };

  const hasActiveFilters = statusFilter !== "All" || searchQuery.trim() !== "";

  const clearFilters = () => {
    setStatusFilter("All");
    setSearchQuery("");
  };

  // ── Render ────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Invoices</h1>
          <p className="text-muted-foreground text-sm">
            View and manage your purchase history
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchInvoices}>
          <RefreshCw className={loading ? "animate-spin" : ""} />
          Refresh
        </Button>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 shrink-0 text-red-600" />
              <div>
                <p className="font-medium text-red-800">Failed to load invoices</p>
                <p className="text-sm text-red-600">{error}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto"
                onClick={fetchInvoices}
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filter Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by invoice #, category, or product type..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Status Filter Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {STATUS_OPTIONS.map((opt) => (
                <Button
                  key={opt.value}
                  variant={statusFilter === opt.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setStatusFilter(opt.value)}
                >
                  {opt.label}
                  {opt.value !== "All" && (
                    <Badge
                      variant="secondary"
                      className="ml-1.5 h-5 px-1.5 text-[10px]"
                    >
                      {
                        invoices.filter(
                          (i) =>
                            opt.value === "All" ||
                            i.paymentStatus === opt.value
                        ).length
                      }
                    </Badge>
                  )}
                </Button>
              ))}
            </div>

            {/* Clear Filters */}
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="shrink-0"
              >
                <X className="h-4 w-4" />
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Invoices Table */}
      {loading ? (
        <TableSkeleton />
      ) : (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {hasActiveFilters
                ? `Results (${filteredInvoices.length})`
                : `All Invoices (${invoices.length})`}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredInvoices.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <FileText className="h-12 w-12 text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground font-medium">
                  {hasActiveFilters
                    ? "No invoices match your filters"
                    : "No invoices found"}
                </p>
                <p className="text-sm text-muted-foreground/70 mt-1">
                  {hasActiveFilters
                    ? "Try adjusting your search or status filter"
                    : "Your purchase history will appear here"}
                </p>
                {hasActiveFilters && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3"
                    onClick={clearFilters}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            ) : (
              <div className="max-h-[500px] overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="hidden sm:table-cell">Items</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="hidden md:table-cell text-right">
                        Advance
                      </TableHead>
                      <TableHead className="hidden md:table-cell text-right">
                        Remaining
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredInvoices.map((invoice) => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">
                          {invoice.invoiceNumber}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(invoice.createdAt)}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          {invoice.items.length}
                        </TableCell>
                        <TableCell className="text-right font-mono font-semibold">
                          {formatCurrency(invoice.totalAmount)}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-right font-mono text-[#408A71]">
                          {formatCurrency(invoice.advancePaid)}
                        </TableCell>
                        <TableCell
                          className={`hidden md:table-cell text-right font-mono ${
                            invoice.remainingAmount > 0
                              ? "text-red-600 font-medium"
                              : "text-muted-foreground"
                          }`}
                        >
                          {invoice.remainingAmount > 0
                            ? formatCurrency(invoice.remainingAmount)
                            : "—"}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(invoice.paymentStatus)}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewDetails(invoice)}
                            className="h-8 px-2"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            <span className="hidden sm:inline">View</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Invoice Detail Dialog */}
      <InvoiceDetailDialog
        invoice={selectedInvoice}
        open={detailOpen}
        onOpenChange={(open) => {
          setDetailOpen(open);
          if (!open) setSelectedInvoice(null);
        }}
      />
    </div>
  );
}
