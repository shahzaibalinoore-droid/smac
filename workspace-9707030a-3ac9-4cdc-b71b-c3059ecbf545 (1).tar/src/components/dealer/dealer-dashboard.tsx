"use client";

import { useEffect, useState } from "react";
import {
  ShoppingBag,
  Banknote,
  AlertTriangle,
  CheckCircle,
  FileText,
  Clock,
  RefreshCw,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import type { Invoice } from "@/lib/types";

// ── Currency formatter ──────────────────────────────────────────────
const currencyFormatter = new Intl.NumberFormat("en-PK", {
  style: "currency",
  currency: "PKR",
  maximumFractionDigits: 0,
});

const formatCurrency = (value: number) => currencyFormatter.format(value);

const formatDate = (dateStr: string) =>
  new Date(dateStr).toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

// ── Status badge helper ─────────────────────────────────────────────
function getStatusBadge(status: string) {
  switch (status) {
    case "Paid":
      return (
        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">
          Paid
        </Badge>
      );
    case "Partial":
      return (
        <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">
          Partial
        </Badge>
      );
    case "Unpaid":
      return (
        <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">
          Unpaid
        </Badge>
      );
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

// ── Computed stats from invoices ────────────────────────────────────
interface DealerStats {
  totalPurchases: number;
  totalSpent: number;
  pendingBalance: number;
  paidCount: number;
  paidAmount: number;
  partialCount: number;
  partialAmount: number;
  unpaidCount: number;
  unpaidAmount: number;
  completionPercent: number;
}

function computeStats(invoices: Invoice[]): DealerStats {
  const totalPurchases = invoices.length;
  const totalSpent = invoices.reduce((s, i) => s + i.totalAmount, 0);
  const pendingBalance = invoices
    .filter((i) => i.paymentStatus === "Unpaid" || i.paymentStatus === "Partial")
    .reduce((s, i) => s + i.remainingAmount, 0);

  const paid = invoices.filter((i) => i.paymentStatus === "Paid");
  const partial = invoices.filter((i) => i.paymentStatus === "Partial");
  const unpaid = invoices.filter((i) => i.paymentStatus === "Unpaid");

  const paidAmount = paid.reduce((s, i) => s + i.totalAmount, 0);
  const partialAmount = partial.reduce((s, i) => s + i.totalAmount, 0);
  const unpaidAmount = unpaid.reduce((s, i) => s + i.totalAmount, 0);

  const completionPercent =
    totalSpent > 0
      ? Math.round((paid.reduce((s, i) => s + i.advancePaid, 0) / totalSpent) * 100)
      : 100;

  return {
    totalPurchases,
    totalSpent,
    pendingBalance,
    paidCount: paid.length,
    paidAmount,
    partialCount: partial.length,
    partialAmount,
    unpaidCount: unpaid.length,
    unpaidAmount,
    completionPercent,
  };
}

// ── Skeleton loaders ────────────────────────────────────────────────
function StatsCardsSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <Card key={i}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-8 w-8 rounded-lg" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-8 w-28 mb-1" />
            <Skeleton className="h-3 w-20" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function PaymentOverviewSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-44" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-3 w-24" />
            </div>
          ))}
        </div>
        <Skeleton className="h-2 w-full rounded-full" />
      </CardContent>
    </Card>
  );
}

function RecentPurchasesSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-44" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-4">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-12" />
              <Skeleton className="h-4 w-20 ml-auto" />
              <Skeleton className="h-5 w-16 rounded-full" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ── Main component ──────────────────────────────────────────────────
export function DealerDashboard({ dealerId }: { dealerId: string }) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/invoices?dealerId=${dealerId}`);
      if (!res.ok) throw new Error("Failed to fetch dealer data");
      const json = await res.json();
      setInvoices(json.invoices ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred");
      toast({
        title: "Error",
        description: "Could not load dashboard data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [dealerId]);

  const stats = invoices.length > 0 ? computeStats(invoices) : null;
  const recentInvoices = invoices.slice(0, 5);
  const today = new Date().toLocaleDateString("en-PK", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  // ── Stats cards data ──────────────────────────────────────────────
  const statsCards = stats
    ? [
        {
          title: "Total Purchases",
          value: stats.totalPurchases.toString(),
          icon: ShoppingBag,
          accentClass: "text-[#408A71] bg-[#EBF6F0]",
          description: "Invoice count",
        },
        {
          title: "Total Spent",
          value: formatCurrency(stats.totalSpent),
          icon: Banknote,
          accentClass: "text-emerald-600 bg-emerald-50",
          description: "Cumulative order value",
        },
        {
          title: "Pending Balance",
          value: formatCurrency(stats.pendingBalance),
          icon: AlertTriangle,
          accentClass: stats.pendingBalance > 0 ? "text-red-600 bg-red-50" : "text-emerald-600 bg-emerald-50",
          description:
            stats.pendingBalance > 0
              ? "Unpaid + partial invoices"
              : "All clear!",
        },
      ]
    : [];

  // ── Render ────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* Hero Banner with Background Image */}
      <div
        className="relative rounded-xl overflow-hidden"
        style={{
          backgroundImage: "url('/dashboard-bg.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#091413]/80 via-[#091413]/50 to-transparent" />
        <div className="relative z-10 px-6 py-10 sm:px-10 sm:py-14">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Welcome back! 👋
              </h1>
              <p className="text-[#B0E4CC] mt-1 text-sm sm:text-base">{today}</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchData}
              className="bg-white/15 border-white/25 text-white hover:bg-white/25 hover:text-white backdrop-blur-sm"
            >
              <RefreshCw className={loading ? "animate-spin" : ""} />
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Error State */}
      {error && !loading && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 shrink-0 text-red-600" />
              <div>
                <p className="font-medium text-red-800">Failed to load data</p>
                <p className="text-sm text-red-600">{error}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto"
                onClick={fetchData}
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 1. Stats Cards */}
      {loading ? (
        <StatsCardsSkeleton />
      ) : stats ? (
        <div className="grid gap-4 sm:grid-cols-3">
          {statsCards.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-lg ${stat.accentClass}`}
                >
                  <stat.icon className="h-5 w-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : null}

      {/* 2. Payment Status Overview */}
      {loading ? (
        <PaymentOverviewSkeleton />
      ) : stats ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Payment Status Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Breakdown Cards */}
            <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
              {/* Paid */}
              <div className="rounded-lg border border-[#B0E4CC] bg-[#EBF6F0] p-4">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="h-4 w-4 text-[#285A48]" />
                  <span className="text-sm font-medium text-[#285A48]">Paid</span>
                </div>
                <p className="text-2xl font-bold text-[#408A71]">
                  {stats.paidCount}
                </p>
                <p className="text-xs text-[#285A48]">
                  {formatCurrency(stats.paidAmount)}
                </p>
              </div>

              {/* Partial */}
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="h-4 w-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-800">Partial</span>
                </div>
                <p className="text-2xl font-bold text-amber-700">
                  {stats.partialCount}
                </p>
                <p className="text-xs text-amber-600">
                  {formatCurrency(stats.partialAmount)}
                </p>
              </div>

              {/* Unpaid */}
              <div className="rounded-lg border border-red-200 bg-red-50 p-4">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <span className="text-sm font-medium text-red-800">Unpaid</span>
                </div>
                <p className="text-2xl font-bold text-red-700">
                  {stats.unpaidCount}
                </p>
                <p className="text-xs text-red-600">
                  {formatCurrency(stats.unpaidAmount)}
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Payment Completion</span>
                <span className="font-semibold">{stats.completionPercent}%</span>
              </div>
              <Progress value={stats.completionPercent} className="h-3" />
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* 3. Recent Purchases Table */}
      {loading ? (
        <RecentPurchasesSkeleton />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="h-5 w-5" />
              Recent Purchases
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentInvoices.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <ShoppingBag className="h-12 w-12 text-muted-foreground/40 mb-3" />
                <p className="text-muted-foreground font-medium">
                  No purchases yet
                </p>
                <p className="text-sm text-muted-foreground/70 mt-1">
                  Your recent orders will appear here
                </p>
              </div>
            ) : (
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="hidden sm:table-cell">Items</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="hidden md:table-cell text-right">
                        Remaining
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentInvoices.map((invoice) => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">
                          {invoice.invoiceNumber}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(invoice.createdAt)}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          {invoice.items.length}{" "}
                          {invoice.items.length === 1 ? "item" : "items"}
                        </TableCell>
                        <TableCell className="text-right font-mono font-semibold">
                          {formatCurrency(invoice.totalAmount)}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(invoice.paymentStatus)}
                        </TableCell>
                        <TableCell
                          className={`hidden md:table-cell text-right font-mono ${
                            invoice.remainingAmount > 0
                              ? "text-red-600 font-medium"
                              : "text-muted-foreground"
                          }`}
                        >
                          {invoice.remainingAmount > 0
                            ? formatCurrency(invoice.remainingAmount)
                            : "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
