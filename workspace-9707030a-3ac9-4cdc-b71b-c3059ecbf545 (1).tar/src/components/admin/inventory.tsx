"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Plus,
  Upload,
  Search,
  Pencil,
  Trash2,
  Filter,
  Package,
  FileSpreadsheet,
  X,
  Download,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { exportInventory } from "@/lib/export-excel";
import type { InventoryItem, Category, ProductType } from "@/lib/types";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// --- Helper ---
function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

// --- Form State ---
interface ItemFormData {
  categoryId: string;
  categoryCode: string;
  productTypeId: string;
  quantity: string;
  costPrice: string;
  discountPrice: string;
  sellingPrice: string;
}

const EMPTY_FORM: ItemFormData = {
  categoryId: "",
  categoryCode: "",
  productTypeId: "",
  quantity: "",
  costPrice: "",
  discountPrice: "",
  sellingPrice: "",
};

// --- Component ---
export function InventoryManagement() {
  const { toast } = useToast();

  // Data
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);

  // Loading
  const [loadingItems, setLoadingItems] = useState(true);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [loadingProductTypes, setLoadingProductTypes] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Filters
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [filterProductType, setFilterProductType] = useState("");

  // Dialogs
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [csvDialogOpen, setCsvDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  // Form
  const [form, setForm] = useState<ItemFormData>(EMPTY_FORM);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // CSV
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvUploading, setCsvUploading] = useState(false);

  // Delete
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // ==================== Data Fetching ====================

  const fetchCategories = useCallback(async () => {
    try {
      setLoadingCategories(true);
      const res = await fetch("/api/categories");
      if (!res.ok) throw new Error("Failed to fetch categories");
      const data = await res.json();
      setCategories(data.categories ?? []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load categories",
        variant: "destructive",
      });
    } finally {
      setLoadingCategories(false);
    }
  }, [toast]);

  const fetchProductTypes = useCallback(async () => {
    try {
      setLoadingProductTypes(true);
      const res = await fetch("/api/product-types");
      if (!res.ok) throw new Error("Failed to fetch product types");
      const data = await res.json();
      setProductTypes(data.productTypes ?? []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load product types",
        variant: "destructive",
      });
    } finally {
      setLoadingProductTypes(false);
    }
  }, [toast]);

  const fetchItems = useCallback(async () => {
    try {
      setLoadingItems(true);
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (filterCategory) params.set("categoryId", filterCategory);
      if (filterProductType) params.set("productTypeId", filterProductType);
      const res = await fetch(`/api/inventory?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch inventory");
      const data = await res.json();
      setItems(data.inventory ?? []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load inventory items",
        variant: "destructive",
      });
    } finally {
      setLoadingItems(false);
    }
  }, [search, filterCategory, filterProductType, toast]);

  useEffect(() => {
    fetchCategories();
    fetchProductTypes();
  }, [fetchCategories, fetchProductTypes]);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  // ==================== Form Helpers ====================

  const openAddDialog = () => {
    setEditingItem(null);
    setForm(EMPTY_FORM);
    setFormErrors({});
    setItemDialogOpen(true);
  };

  const openEditDialog = (item: InventoryItem) => {
    setEditingItem(item);
    setForm({
      categoryId: item.categoryId,
      categoryCode: String(item.categoryCode),
      productTypeId: item.productTypeId,
      quantity: String(item.quantity),
      costPrice: String(item.costPrice),
      discountPrice: String(item.discountPrice),
      sellingPrice: String(item.sellingPrice),
    });
    setFormErrors({});
    setItemDialogOpen(true);
  };

  const updateForm = (field: keyof ItemFormData, value: string | File | null) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setFormErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!form.categoryId) errors.categoryId = "Category is required";
    if (!form.categoryCode || isNaN(Number(form.categoryCode)) || Number(form.categoryCode) <= 0) {
      errors.categoryCode = "Valid category code is required";
    }
    if (!form.productTypeId) errors.productTypeId = "Product type is required";
    if (!form.quantity || isNaN(Number(form.quantity)) || Number(form.quantity) <= 0) {
      errors.quantity = "Valid quantity is required";
    }
    if (!form.costPrice || isNaN(Number(form.costPrice)) || Number(form.costPrice) < 0) {
      errors.costPrice = "Valid cost price is required";
    }
    if (!form.discountPrice || isNaN(Number(form.discountPrice)) || Number(form.discountPrice) < 0) {
      errors.discountPrice = "Valid discount price is required";
    }
    if (!form.sellingPrice || isNaN(Number(form.sellingPrice)) || Number(form.sellingPrice) <= 0) {
      errors.sellingPrice = "Valid selling price is required";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmitItem = async () => {
    if (!validateForm()) return;

    try {
      setSubmitting(true);
      const body: Record<string, unknown> = {
        categoryId: form.categoryId,
        categoryCode: Number(form.categoryCode),
        productTypeId: form.productTypeId,
        quantity: Number(form.quantity),
        costPrice: Number(form.costPrice),
        discountPrice: Number(form.discountPrice),
        sellingPrice: Number(form.sellingPrice),
      };

      let res: Response;
      if (editingItem) {
        body.id = editingItem.id;
        res = await fetch("/api/inventory", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
      } else {
        res = await fetch("/api/inventory", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
      }

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to save item");
      }

      toast({
        title: "Success",
        description: editingItem
          ? "Inventory item updated successfully"
          : "Inventory item added successfully",
      });

      setItemDialogOpen(false);
      fetchItems();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to save item",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      setDeletingId(id);
      const res = await fetch(`/api/inventory?id=${id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to delete item");
      }
      toast({
        title: "Success",
        description: "Inventory item deleted successfully",
      });
      fetchItems();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to delete item",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleCsvUpload = async () => {
    if (!csvFile) {
      toast({
        title: "Error",
        description: "Please select a CSV file",
        variant: "destructive",
      });
      return;
    }

    try {
      setCsvUploading(true);
      const formData = new FormData();
      formData.append("file", csvFile);

      const res = await fetch("/api/inventory/csv", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to upload CSV");
      }

      const result = await res.json();
      toast({
        title: "CSV Upload Complete",
        description: `${result.created || 0} items created, ${result.updated || 0} updated, ${result.failed || 0} failed.`,
      });

      setCsvDialogOpen(false);
      setCsvFile(null);
      fetchItems();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to upload CSV",
        variant: "destructive",
      });
    } finally {
      setCsvUploading(false);
    }
  };

  const clearFilters = () => {
    setSearch("");
    setFilterCategory("");
    setFilterProductType("");
  };

  const hasActiveFilters = search || filterCategory || filterProductType;

  // ==================== Render ====================

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Package className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Inventory</h2>
            <p className="text-sm text-muted-foreground">
              Manage your product inventory items
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {items.length} item{items.length !== 1 ? "s" : ""}
          </Badge>
        </div>
      </div>

      {/* Filter Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
            {/* Search */}
            <div className="flex-1 space-y-1.5">
              <Label htmlFor="inv-search" className="text-xs font-medium text-muted-foreground">
                Search
              </Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="inv-search"
                  placeholder="Search by category, product type, or code..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div className="w-full space-y-1.5 lg:w-48">
              <Label className="text-xs font-medium text-muted-foreground">Category</Label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  {loadingCategories ? (
                    <SelectItem value="__loading" disabled>
                      Loading...
                    </SelectItem>
                  ) : (
                    categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Product Type Filter */}
            <div className="w-full space-y-1.5 lg:w-48">
              <Label className="text-xs font-medium text-muted-foreground">Product Type</Label>
              <Select value={filterProductType} onValueChange={setFilterProductType}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  {loadingProductTypes ? (
                    <SelectItem value="__loading" disabled>
                      Loading...
                    </SelectItem>
                  ) : (
                    productTypes.map((pt) => (
                      <SelectItem key={pt.id} value={pt.id}>
                        {pt.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Clear Filters */}
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="shrink-0">
                <X className="mr-1 h-4 w-4" />
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            {loadingItems
              ? "Loading..."
              : `${items.length} item${items.length !== 1 ? "s" : ""} found`}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            disabled={items.length === 0}
            onClick={() => {
              const parts: string[] = [];
              if (search) parts.push(`Search: ${search}`);
              if (filterCategory) {
                const cat = categories.find((c) => c.id === filterCategory);
                if (cat) parts.push(`Category: ${cat.name}`);
              }
              if (filterProductType) {
                const pt = productTypes.find((p) => p.id === filterProductType);
                if (pt) parts.push(`Type: ${pt.name}`);
              }
              exportInventory(items, parts.length > 0 ? parts.join(", ") : undefined);
            }}
          >
            <Download className="h-4 w-4" />
            Export Excel
          </Button>
          <Button onClick={openAddDialog} size="sm">
            <Plus className="mr-1 h-4 w-4" />
            Add Item
          </Button>
          <Button variant="outline" size="sm" onClick={() => setCsvDialogOpen(true)}>
            <Upload className="mr-1 h-4 w-4" />
            Upload CSV
          </Button>
        </div>
      </div>

      {/* Inventory Table */}
      <Card>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow className="sticky top-0 z-10 bg-muted/80 backdrop-blur-sm">
                  <TableHead className="pl-4">Category</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Product Type</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Cost Price</TableHead>
                  <TableHead className="text-right">Discount</TableHead>
                  <TableHead className="text-right">Selling Price</TableHead>
                  <TableHead className="pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingItems ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell className="pl-4"><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-28" /></TableCell>
                      <TableCell><Skeleton className="ml-auto h-4 w-10" /></TableCell>
                      <TableCell><Skeleton className="ml-auto h-4 w-20" /></TableCell>
                      <TableCell><Skeleton className="ml-auto h-4 w-20" /></TableCell>
                      <TableCell><Skeleton className="ml-auto h-4 w-20" /></TableCell>
                      <TableCell><Skeleton className="ml-auto h-4 w-16" /></TableCell>
                    </TableRow>
                  ))
                ) : items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="h-32 text-center">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Package className="h-8 w-8" />
                        <p className="text-sm">No inventory items found</p>
                        {hasActiveFilters && (
                          <Button variant="link" size="sm" onClick={clearFilters}>
                            Clear filters
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="pl-4">
                        <span className="font-medium">{item.category.name}</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-mono text-xs">
                          {item.category.codePrefix}{item.categoryCode}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.productType.name}</TableCell>
                      <TableCell className="text-right font-medium">{item.quantity}</TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        {formatCurrency(item.costPrice)}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        {formatCurrency(item.discountPrice)}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-foreground">
                        {formatCurrency(item.sellingPrice)}
                      </TableCell>
                      <TableCell className="pr-4">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => openEditDialog(item)}
                          >
                            <Pencil className="h-3.5 w-3.5" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => handleDeleteItem(item.id)}
                            disabled={deletingId === item.id}
                          >
                            {deletingId === item.id ? (
                              <Skeleton className="h-3.5 w-3.5 rounded-full" />
                            ) : (
                              <Trash2 className="h-3.5 w-3.5" />
                            )}
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ==================== Add/Edit Item Dialog ==================== */}
      <Dialog open={itemDialogOpen} onOpenChange={(open) => {
        if (!open) {
          setItemDialogOpen(false);
          setEditingItem(null);
        }
      }}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Edit Inventory Item" : "Add Inventory Item"}
            </DialogTitle>
            <DialogDescription>
              {editingItem
                ? "Update the inventory item details below."
                : "Fill in the details to add a new inventory item."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            {/* Category */}
            <div className="space-y-2">
              <Label htmlFor="form-category">Category *</Label>
              <Select
                value={form.categoryId}
                onValueChange={(val) => updateForm("categoryId", val)}
              >
                <SelectTrigger className="w-full" id="form-category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formErrors.categoryId && (
                <p className="text-xs text-destructive">{formErrors.categoryId}</p>
              )}
            </div>

            {/* Category Code */}
            <div className="space-y-2">
              <Label htmlFor="form-code">Category Code *</Label>
              <Input
                id="form-code"
                type="number"
                placeholder="e.g. 1001"
                value={form.categoryCode}
                onChange={(e) => updateForm("categoryCode", e.target.value)}
                min={1}
              />
              {formErrors.categoryCode && (
                <p className="text-xs text-destructive">{formErrors.categoryCode}</p>
              )}
            </div>

            {/* Product Type */}
            <div className="space-y-2">
              <Label htmlFor="form-product-type">Product Type *</Label>
              <Select
                value={form.productTypeId}
                onValueChange={(val) => updateForm("productTypeId", val)}
              >
                <SelectTrigger className="w-full" id="form-product-type">
                  <SelectValue placeholder="Select product type" />
                </SelectTrigger>
                <SelectContent>
                  {productTypes.map((pt) => (
                    <SelectItem key={pt.id} value={pt.id}>
                      {pt.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formErrors.productTypeId && (
                <p className="text-xs text-destructive">{formErrors.productTypeId}</p>
              )}
            </div>

            {/* Quantity */}
            <div className="space-y-2">
              <Label htmlFor="form-qty">Quantity *</Label>
              <Input
                id="form-qty"
                type="number"
                placeholder="e.g. 50"
                value={form.quantity}
                onChange={(e) => updateForm("quantity", e.target.value)}
                min={1}
              />
              {formErrors.quantity && (
                <p className="text-xs text-destructive">{formErrors.quantity}</p>
              )}
            </div>

            {/* Price Fields */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="form-cost">Cost Price *</Label>
                <Input
                  id="form-cost"
                  type="number"
                  placeholder="0.00"
                  value={form.costPrice}
                  onChange={(e) => updateForm("costPrice", e.target.value)}
                  min={0}
                  step="0.01"
                />
                {formErrors.costPrice && (
                  <p className="text-xs text-destructive">{formErrors.costPrice}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="form-discount">Discount Price *</Label>
                <Input
                  id="form-discount"
                  type="number"
                  placeholder="0.00"
                  value={form.discountPrice}
                  onChange={(e) => updateForm("discountPrice", e.target.value)}
                  min={0}
                  step="0.01"
                />
                {formErrors.discountPrice && (
                  <p className="text-xs text-destructive">{formErrors.discountPrice}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="form-selling">Selling Price *</Label>
                <Input
                  id="form-selling"
                  type="number"
                  placeholder="0.00"
                  value={form.sellingPrice}
                  onChange={(e) => updateForm("sellingPrice", e.target.value)}
                  min={0}
                  step="0.01"
                />
                {formErrors.sellingPrice && (
                  <p className="text-xs text-destructive">{formErrors.sellingPrice}</p>
                )}
              </div>
            </div>


          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setItemDialogOpen(false)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button onClick={handleSubmitItem} disabled={submitting}>
              {submitting ? "Saving..." : editingItem ? "Update Item" : "Add Item"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== CSV Upload Dialog ==================== */}
      <Dialog open={csvDialogOpen} onOpenChange={(open) => {
        if (!open) {
          setCsvDialogOpen(false);
          setCsvFile(null);
        }
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" />
              Upload CSV
            </DialogTitle>
            <DialogDescription>
              Upload a CSV file to bulk-add or update inventory items.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* File Input */}
            <div className="space-y-2">
              <Label htmlFor="csv-file">CSV File</Label>
              <Input
                id="csv-file"
                type="file"
                accept=".csv"
                onChange={(e) => setCsvFile(e.target.files?.[0] ?? null)}
              />
            </div>

            {/* Info Section */}
            <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
              <div>
                <p className="text-sm font-medium">Expected CSV Format:</p>
                <code className="mt-1 block rounded bg-muted px-2 py-1 text-xs font-mono">
                  categoryCode,productType,quantity,costPrice,discountPrice,sellingPrice
                </code>
              </div>

              <div>
                <p className="text-sm font-medium">Example Data:</p>
                <Textarea
                  readOnly
                  value={`1001,SHIRT,50,500,450,700
1002,TROUSER,30,800,720,1100
1003,JACKET,20,2000,1800,2800`}
                  className="mt-1 font-mono text-xs resize-none"
                  rows={4}
                />
              </div>

              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">
                  <strong>Note:</strong> Category codes are matched against category ranges.
                  Product types are matched by name (auto-created if not found).
                  Existing items with the same category+code+type will have their quantity updated.
                </p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setCsvDialogOpen(false);
                setCsvFile(null);
              }}
              disabled={csvUploading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleCsvUpload}
              disabled={!csvFile || csvUploading}
            >
              {csvUploading ? (
                <>
                  <Upload className="mr-1 h-4 w-4 animate-pulse" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="mr-1 h-4 w-4" />
                  Upload
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
