"use client";

import { useState, useEffect, useCallback } from "react";
import type { ProductType } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  Pencil,
  Trash2,
  Tags,
  Loader2,
  Package,
  Hash,
} from "lucide-react";

interface ProductTypeFormData {
  code: string;
  name: string;
  description: string;
}

const emptyForm: ProductTypeFormData = {
  code: "",
  name: "",
  description: "",
};

export function ProductTypeManagement() {
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingProductType, setEditingProductType] = useState<ProductType | null>(null);
  const [deletingProductType, setDeletingProductType] = useState<ProductType | null>(null);
  const [form, setForm] = useState<ProductTypeFormData>(emptyForm);
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof ProductTypeFormData, string>>>({});
  const { toast } = useToast();

  const fetchProductTypes = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/product-types");
      if (!res.ok) throw new Error("Failed to fetch product types");
      const data = await res.json();
      setProductTypes(data.productTypes ?? []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load product types. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchProductTypes();
  }, [fetchProductTypes]);

  const validateForm = (): boolean => {
    const errors: Partial<Record<keyof ProductTypeFormData, string>> = {};

    if (!form.code.trim()) {
      errors.code = "Product type code is required";
    }
    if (!form.name.trim()) {
      errors.name = "Product type name is required";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const openAddDialog = () => {
    setEditingProductType(null);
    setForm(emptyForm);
    setFormErrors({});
    setDialogOpen(true);
  };

  const openEditDialog = (productType: ProductType) => {
    setEditingProductType(productType);
    setForm({
      code: productType.code,
      name: productType.name,
      description: productType.description ?? "",
    });
    setFormErrors({});
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      const isEditing = !!editingProductType;
      const url = "/api/product-types";
      const method = isEditing ? "PUT" : "POST";
      const body = isEditing
        ? { id: editingProductType.id, ...form }
        : form;

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to save product type");
      }

      toast({
        title: isEditing ? "Product Type Updated" : "Product Type Created",
        description: isEditing
          ? `"${form.name}" has been updated successfully.`
          : `"${form.name}" has been created successfully.`,
      });

      setDialogOpen(false);
      fetchProductTypes();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to save product type.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingProductType) return;

    setSubmitting(true);
    try {
      const res = await fetch(`/api/product-types?id=${deletingProductType.id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to delete product type");
      }

      toast({
        title: "Product Type Deleted",
        description: `"${deletingProductType.name}" has been deleted successfully.`,
      });

      setDeleteDialogOpen(false);
      setDeletingProductType(null);
      fetchProductTypes();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to delete product type.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const updateField = <K extends keyof ProductTypeFormData>(
    key: K,
    value: ProductTypeFormData[K]
  ) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (formErrors[key]) {
      setFormErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Tags className="h-6 w-6 text-primary" />
            Product Types
          </h2>
          <p className="text-muted-foreground mt-1">
            Manage product type classifications
          </p>
        </div>
        <Button onClick={openAddDialog} className="gap-2 shrink-0">
          <Plus className="h-4 w-4" />
          Add Product Type
        </Button>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-10 w-full" />
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : productTypes.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Tags className="h-12 w-12 mb-4 opacity-50" />
              <p className="text-lg font-medium">No product types yet</p>
              <p className="text-sm mt-1">Create your first product type to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="pl-6">Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden md:table-cell">Description</TableHead>
                    <TableHead className="text-center">Inventory</TableHead>
                    <TableHead className="text-right pr-6">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productTypes.map((pt) => (
                    <TableRow key={pt.id}>
                      <TableCell className="pl-6">
                        <Badge variant="secondary" className="font-mono gap-1">
                          <Hash className="h-3 w-3" />
                          {pt.code}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{pt.name}</TableCell>
                      <TableCell className="hidden md:table-cell max-w-[250px] truncate text-muted-foreground">
                        {pt.description || "—"}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="gap-1">
                          <Package className="h-3 w-3" />
                          {pt._count?.inventory ?? 0}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => openEditDialog(pt)}
                          >
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => setDeletingProductType(pt)}
                            disabled={(pt._count?.inventory ?? 0) > 0}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary */}
      {!loading && productTypes.length > 0 && (
        <div className="flex flex-wrap gap-3">
          <Card className="flex-1 min-w-[200px]">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <Tags className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Product Types</p>
                <p className="text-2xl font-bold">{productTypes.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="flex-1 min-w-[200px]">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <Package className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Items</p>
                <p className="text-2xl font-bold">
                  {productTypes.reduce((sum, pt) => sum + (pt._count?.inventory ?? 0), 0)}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingProductType ? "Edit Product Type" : "Add New Product Type"}
            </DialogTitle>
            <DialogDescription>
              {editingProductType
                ? "Update the product type details below."
                : "Fill in the details to create a new product type."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              {/* Code */}
              <div className="space-y-2">
                <Label htmlFor="pt-code">
                  Code <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="pt-code"
                  placeholder="e.g., WIDGET"
                  value={form.code}
                  onChange={(e) => updateField("code", e.target.value)}
                  className="font-mono uppercase"
                  disabled={!!editingProductType}
                  aria-invalid={!!formErrors.code}
                />
                {formErrors.code && (
                  <p className="text-xs text-destructive">{formErrors.code}</p>
                )}
                {editingProductType && (
                  <p className="text-xs text-muted-foreground">
                    Product type code cannot be changed after creation.
                  </p>
                )}
              </div>

              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="pt-name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="pt-name"
                  placeholder="e.g., Premium Widget"
                  value={form.name}
                  onChange={(e) => updateField("name", e.target.value)}
                  aria-invalid={!!formErrors.name}
                />
                {formErrors.name && (
                  <p className="text-xs text-destructive">{formErrors.name}</p>
                )}
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="pt-desc">Description</Label>
                <Input
                  id="pt-desc"
                  placeholder="Optional description"
                  value={form.description}
                  onChange={(e) => updateField("description", e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
                disabled={submitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {editingProductType ? "Update Product Type" : "Create Product Type"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Product Type</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-semibold text-foreground">
                {deletingProductType?.name}
              </span>
              ? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {deletingProductType && (deletingProductType._count?.inventory ?? 0) > 0 && (
            <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
              This product type has {deletingProductType._count?.inventory ?? 0} inventory
              item(s) associated with it. Please remove them before deleting.
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={
                submitting ||
                (deletingProductType ? (deletingProductType._count?.inventory ?? 0) > 0 : true)
              }
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
