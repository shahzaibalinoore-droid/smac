"use client";

import * as React from "react";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Users,
  Phone,
  Mail,
  Building,
  Download,
  Key,
  Copy,
  Check,
  Eye,
  EyeOff,
} from "lucide-react";
import type { Dealer } from "@/lib/types";
import { exportDealers } from "@/lib/export-excel";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

/* ------------------------------------------------------------------ */
/*  Form data shape                                                    */
/* ------------------------------------------------------------------ */
interface DealerFormData {
  name: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  password: string;
}

const EMPTY_FORM: DealerFormData = {
  name: "",
  company: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  state: "",
  zipCode: "",
  password: "",
};

/* ------------------------------------------------------------------ */
/*  Simple email / phone validation helpers                            */
/* ------------------------------------------------------------------ */
function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone: string): boolean {
  const digits = phone.replace(/\D/g, "");
  return digits.length >= 7;
}

/* ------------------------------------------------------------------ */
/*  Credentials Dialog                                                 */
/* ------------------------------------------------------------------ */
function CredentialsDialog({
  open,
  onClose,
  email,
  password,
  isNew,
}: {
  open: boolean;
  onClose: () => void;
  email: string;
  password: string;
  isNew: boolean;
}) {
  const { toast } = useToast();
  const [copiedField, setCopiedField] = React.useState<"email" | "password" | null>(null);
  const [showPwd, setShowPwd] = React.useState(false);

  async function copyToClipboard(text: string, field: "email" | "password") {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      toast({ title: "Copied!", description: `${field === "email" ? "Email" : "Password"} copied to clipboard.` });
      setTimeout(() => setCopiedField(null), 2000);
    } catch {
      toast({ title: "Copy failed", description: "Please copy manually.", variant: "destructive" });
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="h-5 w-5 text-primary" />
            {isNew ? "Dealer Credentials Created" : "Dealer Credentials"}
          </DialogTitle>
          <DialogDescription>
            {isNew
              ? "Share these login details with the dealer. They can change their password after logging in."
              : "Here are the login details for this dealer. They can change their password after logging in."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Email */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Login Email</Label>
            <div className="flex items-center gap-2">
              <div className="flex-1 rounded-md border bg-muted/50 px-3 py-2 text-sm font-mono">
                {email}
              </div>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 h-9 w-9"
                onClick={() => copyToClipboard(email, "email")}
              >
                {copiedField === "email" ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {/* Password */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Login Password</Label>
            <div className="flex items-center gap-2">
              <div className="flex-1 rounded-md border bg-muted/50 px-3 py-2 text-sm font-mono">
                {showPwd ? password : "••••••••••"}
              </div>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 h-9 w-9"
                onClick={() => setShowPwd(!showPwd)}
              >
                {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 h-9 w-9"
                onClick={() => copyToClipboard(password, "password")}
              >
                {copiedField === "password" ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {/* Warning info box */}
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 dark:border-amber-800 dark:bg-amber-950/50 dark:text-amber-200">
            <strong>Note:</strong> Share these credentials securely (e.g., via WhatsApp or phone).
            The dealer can change their password after first login.
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose}>
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/*  Reset Password Dialog                                              */
/* ------------------------------------------------------------------ */
function ResetPasswordDialog({
  open,
  onClose,
  dealer,
}: {
  open: boolean;
  onClose: () => void;
  dealer: Dealer | null;
}) {
  const { toast } = useToast();
  const [newCredentials, setNewCredentials] = React.useState<{ email: string; password: string } | null>(null);
  const [loading, setLoading] = React.useState(false);

  async function handleReset() {
    if (!dealer) return;
    setLoading(true);
    try {
      const res = await fetch("/api/dealers/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dealerId: dealer.id }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => null);
        throw new Error(err?.error || "Failed to reset password");
      }
      const data = await res.json();
      setNewCredentials(data.credentials);
      toast({
        title: "Password Reset",
        description: "New credentials generated successfully.",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to reset password",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  function handleClose() {
    setNewCredentials(null);
    onClose();
  }

  // Show the new credentials
  if (newCredentials) {
    return (
      <CredentialsDialog
        open={open}
        onClose={handleClose}
        email={newCredentials.email}
        password={newCredentials.password}
        isNew={false}
      />
    );
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) handleClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="h-5 w-5 text-primary" />
            Reset Password
          </DialogTitle>
          <DialogDescription>
            Generate a new password for <span className="font-semibold">{dealer?.name}</span> ({dealer?.email})
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800 dark:border-blue-800 dark:bg-blue-950/50 dark:text-blue-200">
          A new random password will be generated. The current password will stop working immediately.
          Share the new credentials with the dealer via a secure channel.
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleReset} disabled={loading}>
            {loading ? "Generating..." : "Generate New Password"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Component                                                     */
/* ------------------------------------------------------------------ */
export function DealerManagement() {
  const { toast } = useToast();

  /* ---- state ---- */
  const [dealers, setDealers] = React.useState<Dealer[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [formOpen, setFormOpen] = React.useState(false);
  const [editingDealer, setEditingDealer] = React.useState<Dealer | null>(null);
  const [form, setForm] = React.useState<DealerFormData>(EMPTY_FORM);
  const [formErrors, setFormErrors] = React.useState<
    Partial<Record<keyof DealerFormData, string>>
  >({});
  const [submitting, setSubmitting] = React.useState(false);

  const [deleteTarget, setDeleteTarget] = React.useState<Dealer | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  // Credentials dialog
  const [credsDialogOpen, setCredsDialogOpen] = React.useState(false);
  const [credsData, setCredsData] = React.useState<{ email: string; password: string } | null>(null);
  const [credsIsNew, setCredsIsNew] = React.useState(false);

  // Reset password dialog
  const [resetTarget, setResetTarget] = React.useState<Dealer | null>(null);

  /* ---- fetch dealers ---- */
  const fetchDealers = React.useCallback(async (query?: string) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (query) params.set("search", query);
      const res = await fetch(`/api/dealers?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch dealers");
      const json = await res.json();
      const data: Dealer[] = json.dealers ?? json;
      setDealers(data);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load dealers. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  React.useEffect(() => {
    fetchDealers();
  }, [fetchDealers]);

  /* ---- debounced search ---- */
  const searchTimerRef = React.useRef<ReturnType<typeof setTimeout>>(null);

  function handleSearchChange(value: string) {
    setSearch(value);
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    searchTimerRef.current = setTimeout(() => {
      fetchDealers(value);
    }, 300);
  }

  /* ---- open add dialog ---- */
  function openAddDialog() {
    setEditingDealer(null);
    setForm(EMPTY_FORM);
    setFormErrors({});
    setFormOpen(true);
  }

  /* ---- open edit dialog ---- */
  function openEditDialog(dealer: Dealer) {
    setEditingDealer(dealer);
    setForm({
      name: dealer.name,
      company: dealer.company ?? "",
      email: dealer.email,
      phone: dealer.phone,
      address: dealer.address ?? "",
      city: dealer.city ?? "",
      state: dealer.state ?? "",
      zipCode: dealer.zipCode ?? "",
      password: "", // always empty on edit
    });
    setFormErrors({});
    setFormOpen(true);
  }

  /* ---- validate form ---- */
  function validateForm(): boolean {
    const errors: Partial<Record<keyof DealerFormData, string>> = {};

    if (!form.name.trim()) errors.name = "Name is required";
    if (!form.email.trim()) {
      errors.email = "Email is required";
    } else if (!isValidEmail(form.email.trim())) {
      errors.email = "Enter a valid email address";
    }
    if (!form.phone.trim()) {
      errors.phone = "Phone is required";
    } else if (!isValidPhone(form.phone.trim())) {
      errors.phone = "Enter a valid phone number";
    }
    // Only validate password on create (not edit)
    if (!editingDealer && form.password && form.password.length < 6) {
      errors.password = "Password must be at least 6 characters";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  }

  /* ---- submit (create / update) ---- */
  async function handleSubmit() {
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      const isEditing = !!editingDealer;

      if (isEditing) {
        // Update dealer (no password change here)
        const { password: _pwd, ...dealerFields } = form;
        const res = await fetch("/api/dealers", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingDealer.id, ...dealerFields }),
        });

        if (!res.ok) {
          const body = await res.json().catch(() => null);
          throw new Error(body?.error ?? "Operation failed");
        }

        toast({
          title: "Dealer Updated",
          description: `${form.name} has been updated successfully.`,
        });
      } else {
        // Create dealer + user account
        const payload: Record<string, string> = { ...form };
        // Remove password if empty so backend generates one
        if (!payload.password) delete payload.password;

        const res = await fetch("/api/dealers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        if (!res.ok) {
          const body = await res.json().catch(() => null);
          throw new Error(body?.error ?? "Operation failed");
        }

        const data = await res.json();
        toast({
          title: "Dealer Created",
          description: `${form.name} has been added with a login account.`,
        });

        // Show credentials dialog
        if (data.credentials) {
          setCredsData(data.credentials);
          setCredsIsNew(true);
          setCredsDialogOpen(true);
        }
      }

      setFormOpen(false);
      fetchDealers(search);
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Something went wrong";
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  }

  /* ---- delete ---- */
  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/dealers?id=${deleteTarget.id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.error ?? "Delete failed");
      }

      toast({
        title: "Dealer Deleted",
        description: `${deleteTarget.name} has been removed.`,
      });

      setDeleteTarget(null);
      fetchDealers(search);
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Failed to delete dealer";
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  }

  /* ---- helper to update a single form field ---- */
  function updateField(field: keyof DealerFormData, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (formErrors[field]) {
      setFormErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  }

  /* ================================================================ */
  /*  Render                                                           */
  /* ================================================================ */
  return (
    <div className="flex flex-col gap-6">
      {/* Header + search + add */}
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                <Users className="size-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-lg">Dealers</CardTitle>
                <CardDescription>
                  Manage your dealer network &amp; login credentials
                </CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                disabled={dealers.length === 0}
                onClick={() => {
                  const parts: string[] = [];
                  if (search) parts.push(`Search: ${search}`);
                  exportDealers(dealers, parts.length > 0 ? parts.join(", ") : undefined);
                }}
              >
                <Download className="size-4" />
                Export Excel
              </Button>
              <Button onClick={openAddDialog} size="sm">
                <Plus className="size-4" />
                Add Dealer
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <div className="relative max-w-sm">
            <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search dealers..."
              value={search}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardContent>
      </Card>

      {/* Dealers table */}
      <Card>
        <CardContent className="p-0">
          <div className="max-h-96 overflow-y-auto">
            {loading ? (
              <div className="space-y-3 p-6">
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
              </div>
            ) : dealers.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-2 py-16 text-center">
                <Users className="size-12 text-muted-foreground/40" />
                <p className="text-sm font-medium text-muted-foreground">
                  {search
                    ? "No dealers match your search"
                    : "No dealers yet"}
                </p>
                {!search && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={openAddDialog}
                  >
                    <Plus className="size-4" />
                    Add your first dealer
                  </Button>
                )}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden md:table-cell">
                      Company
                    </TableHead>
                    <TableHead className="hidden lg:table-cell">
                      Email
                    </TableHead>
                    <TableHead className="hidden lg:table-cell">
                      Phone
                    </TableHead>
                    <TableHead className="hidden sm:table-cell">
                      City
                    </TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dealers.map((dealer) => (
                    <TableRow key={dealer.id}>
                      {/* Name */}
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-muted">
                            <Users className="size-4 text-muted-foreground" />
                          </div>
                          <div className="flex flex-col">
                            <span className="font-medium leading-tight">
                              {dealer.name}
                            </span>
                            <span className="text-xs text-muted-foreground md:hidden">
                              {dealer.company ?? dealer.email}
                            </span>
                          </div>
                        </div>
                      </TableCell>

                      {/* Company */}
                      <TableCell className="hidden md:table-cell">
                        <div className="flex items-center gap-1.5">
                          <Building className="size-3.5 text-muted-foreground" />
                          {dealer.company ?? "—"}
                        </div>
                      </TableCell>

                      {/* Email */}
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-center gap-1.5">
                          <Mail className="size-3.5 text-muted-foreground" />
                          {dealer.email}
                        </div>
                      </TableCell>

                      {/* Phone */}
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-center gap-1.5">
                          <Phone className="size-3.5 text-muted-foreground" />
                          {dealer.phone}
                        </div>
                      </TableCell>

                      {/* City */}
                      <TableCell className="hidden sm:table-cell">
                        {dealer.city ?? "—"}
                      </TableCell>

                      {/* Status */}
                      <TableCell>
                        <Badge
                          variant={
                            dealer.isActive ? "default" : "secondary"
                          }
                        >
                          {dealer.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>

                      {/* Actions */}
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {/* Reset / View Credentials */}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-amber-600 hover:text-amber-700 hover:bg-amber-50 dark:text-amber-400 dark:hover:text-amber-300 dark:hover:bg-amber-950/30"
                            onClick={() => setResetTarget(dealer)}
                            aria-label={`Reset credentials for ${dealer.name}`}
                            title="Reset Password"
                          >
                            <Key className="size-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8"
                            onClick={() => openEditDialog(dealer)}
                            aria-label={`Edit ${dealer.name}`}
                          >
                            <Pencil className="size-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-destructive hover:text-destructive"
                            onClick={() => setDeleteTarget(dealer)}
                            aria-label={`Delete ${dealer.name}`}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ============================================================ */}
      {/*  Add / Edit Dialog                                            */}
      {/* ============================================================ */}
      <Dialog open={formOpen} onOpenChange={(open) => setFormOpen(open)}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingDealer ? "Edit Dealer" : "Add New Dealer"}
            </DialogTitle>
            <DialogDescription>
              {editingDealer
                ? "Update the dealer information below."
                : "Fill in the details to create a new dealer with a login account."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            {/* Name */}
            <div className="grid gap-2">
              <Label htmlFor="dealer-name">
                Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="dealer-name"
                placeholder="John Doe"
                value={form.name}
                onChange={(e) => updateField("name", e.target.value)}
                aria-invalid={!!formErrors.name}
              />
              {formErrors.name && (
                <p className="text-xs text-destructive">{formErrors.name}</p>
              )}
            </div>

            {/* Company */}
            <div className="grid gap-2">
              <Label htmlFor="dealer-company">Company</Label>
              <Input
                id="dealer-company"
                placeholder="Acme Corp"
                value={form.company}
                onChange={(e) => updateField("company", e.target.value)}
              />
            </div>

            {/* Email */}
            <div className="grid gap-2">
              <Label htmlFor="dealer-email">
                Email <span className="text-destructive">*</span>
              </Label>
              <Input
                id="dealer-email"
                type="email"
                placeholder="dealer@example.com"
                value={form.email}
                onChange={(e) => updateField("email", e.target.value)}
                aria-invalid={!!formErrors.email}
                disabled={!!editingDealer} // don't allow email change on edit
              />
              {formErrors.email && (
                <p className="text-xs text-destructive">{formErrors.email}</p>
              )}
              {editingDealer && (
                <p className="text-xs text-muted-foreground">Email cannot be changed after creation.</p>
              )}
            </div>

            {/* Phone */}
            <div className="grid gap-2">
              <Label htmlFor="dealer-phone">
                Phone <span className="text-destructive">*</span>
              </Label>
              <Input
                id="dealer-phone"
                type="tel"
                placeholder="+1 555 123 4567"
                value={form.phone}
                onChange={(e) => updateField("phone", e.target.value)}
                aria-invalid={!!formErrors.phone}
              />
              {formErrors.phone && (
                <p className="text-xs text-destructive">{formErrors.phone}</p>
              )}
            </div>

            {/* Address */}
            <div className="grid gap-2">
              <Label htmlFor="dealer-address">Address</Label>
              <Input
                id="dealer-address"
                placeholder="123 Main Street"
                value={form.address}
                onChange={(e) => updateField("address", e.target.value)}
              />
            </div>

            {/* City / State / Zip row */}
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              <div className="grid gap-2">
                <Label htmlFor="dealer-city">City</Label>
                <Input
                  id="dealer-city"
                  placeholder="New York"
                  value={form.city}
                  onChange={(e) => updateField("city", e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="dealer-state">State</Label>
                <Input
                  id="dealer-state"
                  placeholder="NY"
                  value={form.state}
                  onChange={(e) => updateField("state", e.target.value)}
                />
              </div>
              <div className="grid gap-2 col-span-2 sm:col-span-1">
                <Label htmlFor="dealer-zip">Zip Code</Label>
                <Input
                  id="dealer-zip"
                  placeholder="10001"
                  value={form.zipCode}
                  onChange={(e) => updateField("zipCode", e.target.value)}
                />
              </div>
            </div>

            {/* Password — only on create */}
            {!editingDealer && (
              <div className="grid gap-2">
                <Label htmlFor="dealer-password">
                  Password{" "}
                  <span className="text-xs font-normal text-muted-foreground">(optional — auto-generated if empty)</span>
                </Label>
                <Input
                  id="dealer-password"
                  type="text"
                  placeholder="Leave empty to auto-generate"
                  value={form.password}
                  onChange={(e) => updateField("password", e.target.value)}
                  aria-invalid={!!formErrors.password}
                />
                {formErrors.password && (
                  <p className="text-xs text-destructive">{formErrors.password}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  You can set a custom password now, or a random one will be created. Credentials will be shown after creation.
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setFormOpen(false)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={submitting}>
              {submitting
                ? "Saving..."
                : editingDealer
                  ? "Update Dealer"
                  : "Create Dealer & Login"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============================================================ */}
      {/*  Credentials Dialog (shown after dealer creation)              */}
      {/* ============================================================ */}
      {credsData && (
        <CredentialsDialog
          open={credsDialogOpen}
          onClose={() => {
            setCredsDialogOpen(false);
            setCredsData(null);
          }}
          email={credsData.email}
          password={credsData.password}
          isNew={credsIsNew}
        />
      )}

      {/* ============================================================ */}
      {/*  Reset Password Dialog                                         */}
      {/* ============================================================ */}
      <ResetPasswordDialog
        open={!!resetTarget}
        onClose={() => setResetTarget(null)}
        dealer={resetTarget}
      />

      {/* ============================================================ */}
      {/*  Delete Confirmation                                           */}
      {/* ============================================================ */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Dealer</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-semibold">{deleteTarget?.name}</span>?
              This will also remove their login account. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
