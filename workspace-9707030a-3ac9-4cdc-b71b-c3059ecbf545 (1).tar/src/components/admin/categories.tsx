"use client";

import { useState, useEffect, useCallback } from "react";
import type { Category } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  Pencil,
  Trash2,
  FolderOpen,
  Loader2,
  Package,
} from "lucide-react";

interface CategoryFormData {
  name: string;
  codePrefix: string;
  codeStart: number;
  codeEnd: number;
  description: string;
}

const emptyForm: CategoryFormData = {
  name: "",
  codePrefix: "",
  codeStart: 1,
  codeEnd: 100,
  description: "",
};

export function CategoryManagement() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null);
  const [form, setForm] = useState<CategoryFormData>(emptyForm);
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof CategoryFormData, string>>>({});
  const { toast } = useToast();

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/categories");
      if (!res.ok) throw new Error("Failed to fetch categories");
      const data = await res.json();
      setCategories(data.categories ?? []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load categories. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const validateForm = (): boolean => {
    const errors: Partial<Record<keyof CategoryFormData, string>> = {};

    if (!form.name.trim()) {
      errors.name = "Category name is required";
    }
    if (!form.codePrefix.trim()) {
      errors.codePrefix = "Code prefix is required";
    }
    if (isNaN(form.codeStart) || form.codeStart < 1) {
      errors.codeStart = "Code start must be at least 1";
    }
    if (isNaN(form.codeEnd) || form.codeEnd < 1) {
      errors.codeEnd = "Code end must be at least 1";
    }
    if (!isNaN(form.codeStart) && !isNaN(form.codeEnd) && form.codeStart > form.codeEnd) {
      errors.codeEnd = "Code end must be greater than or equal to code start";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const openAddDialog = () => {
    setEditingCategory(null);
    setForm(emptyForm);
    setFormErrors({});
    setDialogOpen(true);
  };

  const openEditDialog = (category: Category) => {
    setEditingCategory(category);
    setForm({
      name: category.name,
      codePrefix: category.codePrefix,
      codeStart: category.codeStart,
      codeEnd: category.codeEnd,
      description: category.description ?? "",
    });
    setFormErrors({});
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      const isEditing = !!editingCategory;
      const url = "/api/categories";
      const method = isEditing ? "PUT" : "POST";
      const body = isEditing
        ? { id: editingCategory.id, ...form }
        : form;

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to save category");
      }

      toast({
        title: isEditing ? "Category Updated" : "Category Created",
        description: isEditing
          ? `"${form.name}" has been updated successfully.`
          : `"${form.name}" has been created successfully.`,
      });

      setDialogOpen(false);
      fetchCategories();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to save category.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingCategory) return;

    setSubmitting(true);
    try {
      const res = await fetch(`/api/categories?id=${deletingCategory.id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to delete category");
      }

      toast({
        title: "Category Deleted",
        description: `"${deletingCategory.name}" has been deleted successfully.`,
      });

      setDeleteDialogOpen(false);
      setDeletingCategory(null);
      fetchCategories();
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to delete category.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const updateField = <K extends keyof CategoryFormData>(
    key: K,
    value: CategoryFormData[K]
  ) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (formErrors[key]) {
      setFormErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <FolderOpen className="h-6 w-6 text-primary" />
            Categories
          </h2>
          <p className="text-muted-foreground mt-1">
            Manage product categories and code ranges
          </p>
        </div>
        <Button onClick={openAddDialog} className="gap-2 shrink-0">
          <Plus className="h-4 w-4" />
          Add Category
        </Button>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-10 w-full" />
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : categories.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <FolderOpen className="h-12 w-12 mb-4 opacity-50" />
              <p className="text-lg font-medium">No categories yet</p>
              <p className="text-sm mt-1">Create your first category to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="pl-6">Name</TableHead>
                    <TableHead>Code Prefix</TableHead>
                    <TableHead>Code Range</TableHead>
                    <TableHead className="hidden md:table-cell">Description</TableHead>
                    <TableHead className="text-center">Inventory</TableHead>
                    <TableHead className="text-right pr-6">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {categories.map((category) => (
                    <TableRow key={category.id}>
                      <TableCell className="pl-6 font-medium">
                        {category.name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="font-mono">
                          {category.codePrefix}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {category.codeStart} - {category.codeEnd}
                      </TableCell>
                      <TableCell className="hidden md:table-cell max-w-[200px] truncate text-muted-foreground">
                        {category.description || "—"}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="gap-1">
                          <Package className="h-3 w-3" />
                          {category._count?.inventory ?? 0}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => openEditDialog(category)}
                          >
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => setDeletingCategory(category)}
                            disabled={(category._count?.inventory ?? 0) > 0}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary */}
      {!loading && categories.length > 0 && (
        <div className="flex flex-wrap gap-3">
          <Card className="flex-1 min-w-[200px]">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <FolderOpen className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Categories</p>
                <p className="text-2xl font-bold">{categories.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="flex-1 min-w-[200px]">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <Package className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Items</p>
                <p className="text-2xl font-bold">
                  {categories.reduce((sum, c) => sum + (c._count?.inventory ?? 0), 0)}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCategory ? "Edit Category" : "Add New Category"}
            </DialogTitle>
            <DialogDescription>
              {editingCategory
                ? "Update the category details below."
                : "Fill in the details to create a new category."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="cat-name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="cat-name"
                  placeholder="e.g., Electronics"
                  value={form.name}
                  onChange={(e) => updateField("name", e.target.value)}
                  aria-invalid={!!formErrors.name}
                />
                {formErrors.name && (
                  <p className="text-xs text-destructive">{formErrors.name}</p>
                )}
              </div>

              {/* Code Prefix */}
              <div className="space-y-2">
                <Label htmlFor="cat-prefix">
                  Code Prefix <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="cat-prefix"
                  placeholder="e.g., ELC"
                  value={form.codePrefix}
                  onChange={(e) => updateField("codePrefix", e.target.value)}
                  className="font-mono uppercase"
                  aria-invalid={!!formErrors.codePrefix}
                />
                {formErrors.codePrefix && (
                  <p className="text-xs text-destructive">{formErrors.codePrefix}</p>
                )}
              </div>

              {/* Code Range */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cat-start">
                    Code Start <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="cat-start"
                    type="number"
                    min={1}
                    placeholder="1"
                    value={form.codeStart}
                    onChange={(e) => updateField("codeStart", Number(e.target.value))}
                    className="font-mono"
                    aria-invalid={!!formErrors.codeStart}
                  />
                  {formErrors.codeStart && (
                    <p className="text-xs text-destructive">{formErrors.codeStart}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cat-end">
                    Code End <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="cat-end"
                    type="number"
                    min={1}
                    placeholder="100"
                    value={form.codeEnd}
                    onChange={(e) => updateField("codeEnd", Number(e.target.value))}
                    className="font-mono"
                    aria-invalid={!!formErrors.codeEnd}
                  />
                  {formErrors.codeEnd && (
                    <p className="text-xs text-destructive">{formErrors.codeEnd}</p>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="cat-desc">Description</Label>
                <Input
                  id="cat-desc"
                  placeholder="Optional description"
                  value={form.description}
                  onChange={(e) => updateField("description", e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
                disabled={submitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {editingCategory ? "Update Category" : "Create Category"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Category</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-semibold text-foreground">
                {deletingCategory?.name}
              </span>
              ? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {deletingCategory && (deletingCategory._count?.inventory ?? 0) > 0 && (
            <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
              This category has {(deletingCategory._count?.inventory ?? 0)} inventory item(s)
              associated with it. Please remove them before deleting.
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={
                submitting ||
                (deletingCategory ? (deletingCategory._count?.inventory ?? 0) > 0 : true)
              }
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
