"use client";

import { useState, useEffect, useCallback } from "react";
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Search,
  CheckCircle,
  FileText,
  ArrowRight,
  ArrowLeft,
  User,
  Loader2,
  Package,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Dealer, InventoryItem, Category, ProductType, PurchaseItem, Invoice } from "@/lib/types";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ==================== Helpers ====================

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function getPaymentStatusBadge(status: string) {
  switch (status) {
    case "Paid":
      return <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">Paid</Badge>;
    case "Partial":
      return <Badge className="bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100">Partial</Badge>;
    case "Unpaid":
      return <Badge className="bg-red-100 text-red-700 border-red-200 hover:bg-red-100">Unpaid</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function getItemCode(item: InventoryItem): string {
  return `${item.category.codePrefix}${item.categoryCode}`;
}

// ==================== Component ====================

export function PurchaseFlow() {
  const { toast } = useToast();

  // ---- Step State ----
  const [currentStep, setCurrentStep] = useState(1);

  // ---- Data ----
  const [dealers, setDealers] = useState<Dealer[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);

  // ---- Loading ----
  const [loadingDealers, setLoadingDealers] = useState(true);
  const [loadingInventory, setLoadingInventory] = useState(true);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [loadingProductTypes, setLoadingProductTypes] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // ---- Step 1: Dealer Selection ----
  const [selectedDealer, setSelectedDealer] = useState<Dealer | null>(null);
  const [dealerSearch, setDealerSearch] = useState("");

  // ---- Step 2: Catalog Filters & Cart ----
  const [filterCategory, setFilterCategory] = useState("");
  const [filterProductType, setFilterProductType] = useState("");
  const [catalogSearch, setCatalogSearch] = useState("");
  const [cart, setCart] = useState<PurchaseItem[]>([]);
  const [addingItemId, setAddingItemId] = useState<string | null>(null);
  const [addQty, setAddQty] = useState<Record<string, string>>({});

  // ---- Step 3: Review ----
  const [advancePaid, setAdvancePaid] = useState("");
  const [notes, setNotes] = useState("");

  // ---- Invoice Preview ----
  const [generatedInvoice, setGeneratedInvoice] = useState<Invoice | null>(null);
  const [invoiceDialogOpen, setInvoiceDialogOpen] = useState(false);

  // ==================== Data Fetching ====================

  const fetchDealers = useCallback(async () => {
    try {
      setLoadingDealers(true);
      const params = new URLSearchParams();
      if (dealerSearch) params.set("search", dealerSearch);
      const res = await fetch(`/api/dealers?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch dealers");
      const data = await res.json();
      setDealers(data.dealers ?? data);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load dealers",
        variant: "destructive",
      });
    } finally {
      setLoadingDealers(false);
    }
  }, [dealerSearch, toast]);

  const fetchCategories = useCallback(async () => {
    try {
      setLoadingCategories(true);
      const res = await fetch("/api/categories");
      if (!res.ok) throw new Error("Failed to fetch categories");
      const data = await res.json();
      setCategories(data.categories ?? data);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load categories",
        variant: "destructive",
      });
    } finally {
      setLoadingCategories(false);
    }
  }, [toast]);

  const fetchProductTypes = useCallback(async () => {
    try {
      setLoadingProductTypes(true);
      const res = await fetch("/api/product-types");
      if (!res.ok) throw new Error("Failed to fetch product types");
      const data = await res.json();
      setProductTypes(data.productTypes ?? data);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load product types",
        variant: "destructive",
      });
    } finally {
      setLoadingProductTypes(false);
    }
  }, [toast]);

  const fetchInventory = useCallback(async () => {
    try {
      setLoadingInventory(true);
      const params = new URLSearchParams();
      if (filterCategory) params.set("categoryId", filterCategory);
      if (filterProductType) params.set("productTypeId", filterProductType);
      if (catalogSearch) params.set("search", catalogSearch);
      const res = await fetch(`/api/inventory?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch inventory");
      const data = await res.json();
      setInventory(data.inventory ?? data);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load inventory",
        variant: "destructive",
      });
    } finally {
      setLoadingInventory(false);
    }
  }, [filterCategory, filterProductType, catalogSearch, toast]);

  // Fetch on mount
  useEffect(() => {
    fetchDealers();
    fetchCategories();
    fetchProductTypes();
  }, [fetchDealers, fetchCategories, fetchProductTypes]);

  // Fetch inventory when step 2 becomes active or filters change
  useEffect(() => {
    if (currentStep >= 2) {
      fetchInventory();
    }
  }, [fetchInventory, currentStep]);

  // ==================== Cart Logic ====================

  const isInCart = (itemId: string) => cart.some((c) => c.inventoryItemId === itemId);

  const getCartQty = (itemId: string) => cart.find((c) => c.inventoryItemId === itemId)?.quantity ?? 0;

  const getAvailableQty = (item: InventoryItem) => {
    const cartQty = getCartQty(item.id);
    return item.quantity - cartQty;
  };

  const handleAddToCart = (item: InventoryItem) => {
    const qtyStr = addQty[item.id];
    const qty = qtyStr ? parseInt(qtyStr, 10) : 1;
    if (qty < 1) return;

    const existing = cart.find((c) => c.inventoryItemId === item.id);
    if (existing) {
      setCart((prev) =>
        prev.map((c) =>
          c.inventoryItemId === item.id
            ? { ...c, quantity: c.quantity + qty }
            : c
        )
      );
    } else {
      setCart((prev) => [
        ...prev,
        { inventoryItemId: item.id, inventoryItem: item, quantity: qty },
      ]);
    }
    setAddQty((prev) => {
      const next = { ...prev };
      delete next[item.id];
      return next;
    });
    setAddingItemId(null);
  };

  const handleUpdateCartQty = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      setCart((prev) => prev.filter((c) => c.inventoryItemId !== itemId));
    } else {
      setCart((prev) =>
        prev.map((c) =>
          c.inventoryItemId === itemId ? { ...c, quantity: newQty } : c
        )
      );
    }
  };

  const handleRemoveFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((c) => c.inventoryItemId !== itemId));
  };

  // ==================== Computed Values ====================

  const cartTotal = cart.reduce(
    (sum, c) => sum + c.inventoryItem.sellingPrice * c.quantity,
    0
  );
  const cartTotalQty = cart.reduce((sum, c) => sum + c.quantity, 0);
  const advanceAmount = advancePaid ? parseFloat(advancePaid) : 0;
  const remainingBalance = Math.max(0, cartTotal - advanceAmount);

  const paymentStatus: "Paid" | "Partial" | "Unpaid" =
    advanceAmount >= cartTotal
      ? "Paid"
      : advanceAmount > 0
        ? "Partial"
        : "Unpaid";

  // Filtered dealers for display
  const filteredDealers = dealers.filter((d) => d.isActive);

  // Filtered inventory for display
  const filteredInventory = inventory;

  // ==================== Step Navigation ====================

  const canGoNext = (): boolean => {
    switch (currentStep) {
      case 1:
        return !!selectedDealer;
      case 2:
        return cart.length > 0;
      case 3:
        return true;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (canGoNext()) {
      setCurrentStep((prev) => Math.min(prev + 1, 3));
    }
  };

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  // ==================== Submit Purchase ====================

  const handleSubmitPurchase = async () => {
    if (!selectedDealer || cart.length === 0) return;

    try {
      setSubmitting(true);
      const res = await fetch("/api/purchases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dealerId: selectedDealer.id,
          items: cart.map((c) => ({
            inventoryItemId: c.inventoryItemId,
            quantity: c.quantity,
          })),
          advancePaid: advanceAmount,
          notes: notes.trim() || undefined,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to create purchase");
      }

      const data = await res.json();
      setGeneratedInvoice(data.invoice ?? data);
      setInvoiceDialogOpen(true);
      toast({
        title: "Purchase Successful!",
        description: `Invoice ${data.invoice?.invoiceNumber ?? ""} generated successfully.`,
      });
    } catch (err) {
      toast({
        title: "Purchase Failed",
        description: err instanceof Error ? err.message : "Failed to create purchase",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // ==================== Reset Flow ====================

  const handleNewPurchase = () => {
    setCurrentStep(1);
    setSelectedDealer(null);
    setDealerSearch("");
    setCart([]);
    setAdvancePaid("");
    setNotes("");
    setFilterCategory("");
    setFilterProductType("");
    setCatalogSearch("");
    setAddQty({});
    setGeneratedInvoice(null);
    setInvoiceDialogOpen(false);
  };

  // ==================== Step Indicator ====================

  const steps = [
    { num: 1, label: "Select Dealer", icon: User },
    { num: 2, label: "Add Items", icon: ShoppingCart },
    { num: 3, label: "Review & Pay", icon: FileText },
  ];

  const StepIndicator = () => (
    <div className="flex items-center justify-center gap-2 sm:gap-4 mb-8">
      {steps.map((step, idx) => {
        const Icon = step.icon;
        const isActive = currentStep === step.num;
        const isCompleted = currentStep > step.num;
        return (
          <div key={step.num} className="flex items-center gap-2 sm:gap-4">
            <div className="flex flex-col items-center gap-1.5">
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all ${
                  isCompleted
                    ? "border-[#285A48] bg-[#285A48] text-white"
                    : isActive
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-muted-foreground/30 bg-muted text-muted-foreground"
                }`}
              >
                {isCompleted ? (
                  <CheckCircle className="h-5 w-5" />
                ) : (
                  <Icon className="h-4 w-4" />
                )}
              </div>
              <span
                className={`text-xs font-medium hidden sm:block ${
                  isActive
                    ? "text-primary"
                    : isCompleted
                      ? "text-[#408A71]"
                      : "text-muted-foreground"
                }`}
              >
                {step.label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div
                className={`h-0.5 w-8 sm:w-16 rounded-full transition-colors ${
                  isCompleted ? "bg-[#285A48]" : "bg-muted-foreground/20"
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );

  // ==================== Step 1: Select Dealer ====================

  const renderStep1 = () => (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-lg font-semibold">Select a Dealer</h3>
          <p className="text-sm text-muted-foreground">
            Choose the dealer for this purchase
          </p>
        </div>
        <Badge variant="secondary" className="w-fit">
          {filteredDealers.length} active dealer{filteredDealers.length !== 1 ? "s" : ""}
        </Badge>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search dealers by name, company, city..."
          value={dealerSearch}
          onChange={(e) => setDealerSearch(e.target.value)}
          className="pl-8"
        />
      </div>

      {/* Dealer Cards Grid */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 max-h-[400px] overflow-y-auto pr-1">
        {loadingDealers ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="cursor-pointer p-4">
              <div className="space-y-2">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-20" />
              </div>
            </Card>
          ))
        ) : filteredDealers.length === 0 ? (
          <div className="col-span-full py-12 text-center">
            <User className="mx-auto h-10 w-10 text-muted-foreground/40" />
            <p className="mt-3 text-sm text-muted-foreground">
              No active dealers found.
            </p>
          </div>
        ) : (
          filteredDealers.map((dealer) => {
            const isSelected = selectedDealer?.id === dealer.id;
            return (
              <Card
                key={dealer.id}
                className={`cursor-pointer transition-all hover:shadow-md p-4 ${
                  isSelected
                    ? "border-primary ring-2 ring-primary/20 bg-primary/5"
                    : "hover:border-primary/40"
                }`}
                onClick={() => setSelectedDealer(dealer)}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                      isSelected
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    <User className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium truncate">{dealer.name}</p>
                    {dealer.company && (
                      <p className="text-sm text-muted-foreground truncate">
                        {dealer.company}
                      </p>
                    )}
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      {dealer.city && <span>{dealer.city}</span>}
                      <span className="text-muted-foreground/40">|</span>
                      <span>{dealer.phone}</span>
                    </div>
                  </div>
                  {isSelected && (
                    <CheckCircle className="h-5 w-5 shrink-0 text-primary" />
                  )}
                </div>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );

  // ==================== Step 2: Catalog & Item Selection ====================

  const renderStep2 = () => (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-lg font-semibold">Add Items to Cart</h3>
          <p className="text-sm text-muted-foreground">
            Browse catalog and add items for {selectedDealer?.name}
          </p>
        </div>
        <Badge variant="secondary" className="w-fit">
          <ShoppingCart className="mr-1 h-3 w-3" />
          {cart.length} item{cart.length !== 1 ? "s" : ""} &middot; {formatCurrency(cartTotal)}
        </Badge>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
            <div className="flex-1 space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Search</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search inventory..."
                  value={catalogSearch}
                  onChange={(e) => setCatalogSearch(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="w-full space-y-1.5 lg:w-48">
              <Label className="text-xs font-medium text-muted-foreground">Category</Label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-full space-y-1.5 lg:w-48">
              <Label className="text-xs font-medium text-muted-foreground">Product Type</Label>
              <Select value={filterProductType} onValueChange={setFilterProductType}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  {productTypes.map((pt) => (
                    <SelectItem key={pt.id} value={pt.id}>
                      {pt.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {(filterCategory || filterProductType || catalogSearch) && (
              <Button
                variant="ghost"
                size="sm"
                className="shrink-0"
                onClick={() => {
                  setFilterCategory("");
                  setFilterProductType("");
                  setCatalogSearch("");
                }}
              >
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Inventory Items */}
        <div className="lg:col-span-2">
          <div className="max-h-[450px] overflow-y-auto space-y-2 pr-1">
            {loadingInventory ? (
              Array.from({ length: 5 }).map((_, i) => (
                <Card key={i} className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-40" />
                      <Skeleton className="h-3 w-28" />
                    </div>
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-12" />
                    <Skeleton className="h-9 w-20" />
                  </div>
                </Card>
              ))
            ) : filteredInventory.length === 0 ? (
              <Card className="p-8">
                <div className="flex flex-col items-center gap-2 text-muted-foreground">
                  <Package className="h-10 w-10" />
                  <p className="text-sm">No inventory items found</p>
                </div>
              </Card>
            ) : (
              filteredInventory.map((item) => {
                const inCart = isInCart(item.id);
                const available = getAvailableQty(item.id);
                const isAdding = addingItemId === item.id;

                return (
                  <Card
                    key={item.id}
                    className={`p-4 transition-all ${
                      inCart ? "border-[#B0E4CC] bg-[#EBF6F0]/50 dark:bg-[#1A3D30]/20" : ""
                    }`}
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      {/* Item Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{item.category.name}</span>
                          <Badge variant="outline" className="font-mono text-xs">
                            {getItemCode(item)}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-0.5">
                          {item.productType.name}
                        </p>
                      </div>

                      {/* Price & Qty */}
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="font-semibold">{formatCurrency(item.sellingPrice)}</p>
                          <p className="text-xs text-muted-foreground">
                            {available > 0 ? (
                              <>
                                {available} of {item.quantity} available
                              </>
                            ) : (
                              <span className="text-destructive">Out of stock</span>
                            )}
                          </p>
                        </div>

                        {/* Add to Cart Controls */}
                        <div className="flex items-center gap-2">
                          {isAdding ? (
                            <div className="flex items-center gap-1.5">
                              <Input
                                type="number"
                                min={1}
                                max={available}
                                value={addQty[item.id] || "1"}
                                onChange={(e) =>
                                  setAddQty((prev) => ({
                                    ...prev,
                                    [item.id]: e.target.value,
                                  }))
                                }
                                className="w-16 h-9 text-center text-sm"
                                autoFocus
                              />
                              <Button
                                size="sm"
                                className="h-9"
                                onClick={() => handleAddToCart(item)}
                                disabled={!addQty[item.id] || parseInt(addQty[item.id] || "0") < 1 || parseInt(addQty[item.id] || "0") > available}
                              >
                                <CheckCircle className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-9"
                                onClick={() => {
                                  setAddingItemId(null);
                                  setAddQty((prev) => {
                                    const next = { ...prev };
                                    delete next[item.id];
                                    return next;
                                  });
                                }}
                              >
                                <Minus className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          ) : inCart ? (
                            <div className="flex items-center gap-1.5">
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8"
                                onClick={() =>
                                  handleUpdateCartQty(item.id, getCartQty(item.id) - 1)
                                }
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="w-8 text-center font-medium text-sm">
                                {getCartQty(item.id)}
                              </span>
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8"
                                onClick={() =>
                                  handleUpdateCartQty(item.id, getCartQty(item.id) + 1)
                                }
                                disabled={available <= 0}
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => handleRemoveFromCart(item.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-9"
                              disabled={available <= 0}
                              onClick={() => {
                                setAddingItemId(item.id);
                                setAddQty((prev) => ({ ...prev, [item.id]: "1" }));
                              }}
                            >
                              <Plus className="mr-1 h-3.5 w-3.5" />
                              Add
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        </div>

        {/* Cart Sidebar */}
        <div className="lg:col-span-1">
          <Card className="sticky top-4">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <ShoppingCart className="h-4 w-4" />
                Cart
                {cart.length > 0 && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {cartTotalQty}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {cart.length === 0 ? (
                <div className="py-8 text-center">
                  <ShoppingCart className="mx-auto h-8 w-8 text-muted-foreground/30" />
                  <p className="mt-2 text-sm text-muted-foreground">
                    No items in cart
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="max-h-[280px] overflow-y-auto space-y-2 pr-1">
                    {cart.map((c) => (
                      <div
                        key={c.inventoryItemId}
                        className="flex items-center justify-between gap-2 rounded-lg bg-muted/50 p-2.5"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">
                            {c.inventoryItem.category.name}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {getItemCode(c.inventoryItem)} &middot;{" "}
                            {formatCurrency(c.inventoryItem.sellingPrice)} &times;{" "}
                            {c.quantity}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-sm font-semibold">
                            {formatCurrency(c.inventoryItem.sellingPrice * c.quantity)}
                          </span>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 text-destructive hover:text-destructive"
                            onClick={() => handleRemoveFromCart(c.inventoryItemId)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total</span>
                    <span className="text-lg font-bold">{formatCurrency(cartTotal)}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );

  // ==================== Step 3: Review & Confirm ====================

  const renderStep3 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold">Review Purchase</h3>
        <p className="text-sm text-muted-foreground">
          Verify details before generating invoice for {selectedDealer?.name}
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Items Table */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Selected Items</CardTitle>
              <CardDescription>
                {cart.length} item{cart.length !== 1 ? "s" : ""} &middot;{" "}
                {cartTotalQty} total quantity
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-[350px] overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="sticky top-0 z-10 bg-muted/80 backdrop-blur-sm">
                      <TableHead className="pl-4">Category</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead className="hidden sm:table-cell">Product Type</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="pr-4 text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cart.map((c) => (
                      <TableRow key={c.inventoryItemId}>
                        <TableCell className="pl-4 font-medium">
                          {c.inventoryItem.category.name}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="font-mono text-xs">
                            {getItemCode(c.inventoryItem)}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          {c.inventoryItem.productType.name}
                        </TableCell>
                        <TableCell className="text-right">{c.quantity}</TableCell>
                        <TableCell className="text-right text-muted-foreground">
                          {formatCurrency(c.inventoryItem.sellingPrice)}
                        </TableCell>
                        <TableCell className="pr-4 text-right font-semibold">
                          {formatCurrency(c.inventoryItem.sellingPrice * c.quantity)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Summary */}
        <div className="lg:col-span-1 space-y-4">
          {/* Dealer Info */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Dealer</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <User className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{selectedDealer?.name}</p>
                    {selectedDealer?.company && (
                      <p className="text-xs text-muted-foreground">
                        {selectedDealer.company}
                      </p>
                    )}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground space-y-0.5 ml-10">
                  {selectedDealer?.city && <p>{selectedDealer.city}</p>}
                  <p>{selectedDealer?.phone}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Payment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="advance-paid">Advance Payment (Rs)</Label>
                <Input
                  id="advance-paid"
                  type="number"
                  min={0}
                  step="0.01"
                  max={cartTotal}
                  placeholder="0.00"
                  value={advancePaid}
                  onChange={(e) => setAdvancePaid(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes (optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional notes..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="resize-none"
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Amount</span>
                  <span className="font-semibold">{formatCurrency(cartTotal)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Advance Paid</span>
                  <span className="font-medium">{formatCurrency(advanceAmount)}</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Remaining Balance</span>
                  <span className="text-lg font-bold">{formatCurrency(remainingBalance)}</span>
                </div>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Payment Status</span>
                {getPaymentStatusBadge(paymentStatus)}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );

  // ==================== Invoice Preview Dialog ====================

  const InvoicePreview = () => (
    <Dialog open={invoiceDialogOpen} onOpenChange={(open) => {
      if (!open) setInvoiceDialogOpen(false);
    }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-[#408A71]" />
            Invoice Generated
          </DialogTitle>
          <DialogDescription>
            Purchase has been recorded successfully.
          </DialogDescription>
        </DialogHeader>

        {generatedInvoice && (
          <div className="space-y-6 pt-2">
            {/* Invoice Header */}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h3 className="text-xl font-bold">{generatedInvoice.invoiceNumber}</h3>
                <p className="text-sm text-muted-foreground">
                  {formatDate(generatedInvoice.createdAt)}
                </p>
              </div>
              {getPaymentStatusBadge(generatedInvoice.paymentStatus)}
            </div>

            <Separator />

            {/* Dealer Info */}
            <div className="rounded-lg bg-muted/50 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold">{generatedInvoice.dealer.name}</p>
                  {generatedInvoice.dealer.company && (
                    <p className="text-sm text-muted-foreground">
                      {generatedInvoice.dealer.company}
                    </p>
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-1">
                    {generatedInvoice.dealer.city && <span>{generatedInvoice.dealer.city}</span>}
                    <span>{generatedInvoice.dealer.phone}</span>
                    <span>{generatedInvoice.dealer.email}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Items Table */}
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="pl-4">Category</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead className="hidden sm:table-cell">Product Type</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="pr-4 text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {generatedInvoice.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="pl-4 font-medium">
                          {item.inventoryItem.category.name}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="font-mono text-xs">
                            {getItemCode(item.inventoryItem)}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          {item.inventoryItem.productType.name}
                        </TableCell>
                        <TableCell className="text-right">{item.quantity}</TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(item.unitPrice)}
                        </TableCell>
                        <TableCell className="pr-4 text-right font-semibold">
                          {formatCurrency(item.totalPrice)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Totals */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Total Quantity
                </span>
                <span className="font-medium">{generatedInvoice.totalQuantity} items</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Total Amount
                </span>
                <span className="text-lg font-bold">
                  {formatCurrency(generatedInvoice.totalAmount)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Advance Paid
                </span>
                <span className="font-medium">
                  {formatCurrency(generatedInvoice.advancePaid)}
                </span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Remaining Balance</span>
                <span className="text-xl font-bold text-destructive">
                  {formatCurrency(generatedInvoice.remainingAmount)}
                </span>
              </div>
            </div>

            {generatedInvoice.notes && (
              <>
                <Separator />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Notes</p>
                  <p className="mt-1 text-sm">{generatedInvoice.notes}</p>
                </div>
              </>
            )}

            <Separator />

            {/* Actions */}
            <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
              <Button
                variant="outline"
                onClick={handleNewPurchase}
              >
                <ShoppingCart className="mr-2 h-4 w-4" />
                New Purchase
              </Button>
              <Button
                onClick={() => setInvoiceDialogOpen(false)}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                Done
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );

  // ==================== Main Render ====================

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <ShoppingCart className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">New Purchase</h2>
            <p className="text-sm text-muted-foreground">
              Create a new dealer purchase invoice
            </p>
          </div>
        </div>
      </div>

      {/* Step Indicator */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <StepIndicator />
        </CardContent>
      </Card>

      {/* Step Content */}
      {currentStep === 1 && renderStep1()}
      {currentStep === 2 && renderStep2()}
      {currentStep === 3 && renderStep3()}

      {/* Navigation */}
      <div className="flex items-center justify-between pt-2">
        <Button
          variant="outline"
          onClick={currentStep === 1 ? handleNewPurchase : handleBack}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          {currentStep === 1 ? "Reset" : "Back"}
        </Button>

        {currentStep < 3 ? (
          <Button onClick={handleNext} disabled={!canGoNext()}>
            Next
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        ) : (
          <Button
            onClick={handleSubmitPurchase}
            disabled={submitting || cart.length === 0}
            className="bg-[#285A48] hover:bg-[#1A3D30]"
          >
            {submitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Invoice...
              </>
            ) : (
              <>
                <FileText className="mr-2 h-4 w-4" />
                Generate Invoice
              </>
            )}
          </Button>
        )}
      </div>

      {/* Invoice Preview Dialog */}
      <InvoicePreview />
    </div>
  );
}
