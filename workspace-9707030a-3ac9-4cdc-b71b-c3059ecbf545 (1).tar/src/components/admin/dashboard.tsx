"use client";

import { useEffect, useState } from "react";
import {
  TrendingUp,
  Users,
  Package,
  AlertCircle,
  Plus,
  Upload,
  FileText,
  Download,
  RefreshCw,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Pie,
  PieChart,
  Cell,
} from "recharts";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";
import type { DashboardStats, Invoice } from "@/lib/types";
import { useAppStore } from "@/lib/store";

// ── Currency formatter ──────────────────────────────────────────────
const currencyFormatter = new Intl.NumberFormat("en-PK", {
  style: "currency",
  currency: "PKR",
  maximumFractionDigits: 0,
});

const formatCurrency = (value: number) => currencyFormatter.format(value);

// ── Chart color palette for pie chart ───────────────────────────────
const PIE_COLORS = [
  "#285A48",
  "#408A71",
  "#6BAF96",
  "#B0E4CC",
  "#1A3D30",
];

// ── Recharts chart configs ──────────────────────────────────────────
const barChartConfig: ChartConfig = {
  sales: { label: "Sales", color: "#285A48" },
  revenue: { label: "Revenue", color: "#408A71" },
};

const pieChartConfig: ChartConfig = {
  count: {
    label: "Items",
  },
};

// ── Status badge styling ────────────────────────────────────────────
function getStatusBadge(status: string) {
  switch (status) {
    case "Paid":
      return (
        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">
          Paid
        </Badge>
      );
    case "Partial":
      return (
        <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">
          Partial
        </Badge>
      );
    case "Unpaid":
      return (
        <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">
          Unpaid
        </Badge>
      );
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

// ── Loading skeletons ───────────────────────────────────────────────
function StatsCardsSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-5 w-5 rounded" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-8 w-32 mb-1" />
            <Skeleton className="h-3 w-20" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ChartsSkeleton() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {[1, 2].map((key) => (
        <Card key={key}>
          <CardHeader>
            <Skeleton className="h-5 w-40" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[280px] w-full" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function TableSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-40" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-4">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-20 ml-auto" />
              <Skeleton className="h-5 w-16 rounded-full" />
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ── Main component ──────────────────────────────────────────────────
export function AdminDashboard() {
  const { setAdminView } = useAppStore();
  const [data, setData] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleExport = () => {
    const rows = [
      ["Invoice #", "Dealer", "Amount", "Advance", "Remaining", "Status", "Date"],
      ...(data?.recentInvoices ?? []).map((inv) => [
        inv.invoiceNumber,
        inv.dealer.name,
        String(inv.totalAmount),
        String(inv.advancePaid),
        String(inv.remainingAmount),
        inv.paymentStatus,
        new Date(inv.createdAt).toLocaleDateString("en-PK"),
      ]),
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `inventory-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/dashboard");
      if (!res.ok) {
        throw new Error("Failed to fetch dashboard data");
      }
      const json = await res.json();
      setData(json);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "An unexpected error occurred"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // ── Stats cards data ──────────────────────────────────────────────
  const statsCards = data
    ? [
        {
          title: "Total Revenue",
          value: formatCurrency(data.totalRevenue),
          icon: TrendingUp,
          accentClass: "text-[#285A48] bg-[#EBF6F0]",
          description: "Total collected payments",
        },
        {
          title: "Total Dealers",
          value: data.totalDealers.toLocaleString("en-PK"),
          icon: Users,
          accentClass: "text-[#408A71] bg-[#EBF6F0]",
          description: "Registered dealers",
        },
        {
          title: "Inventory Items",
          value: data.totalInventory.toLocaleString("en-PK"),
          icon: Package,
          accentClass: "text-[#285A48] bg-[#EBF6F0]",
          description: `${formatCurrency(data.totalInventoryValue)} value`,
        },
        {
          title: "Pending Payments",
          value: formatCurrency(data.pendingPayments),
          icon: AlertCircle,
          accentClass: "text-red-600 bg-red-50",
          description: "Unpaid & partial invoices",
        },
      ]
    : [];

  // ── Pie chart data with fills ─────────────────────────────────────
  const pieData = data
    ? data.categoryDistribution.map((cat, idx) => ({
        name: cat.name,
        count: cat.itemCount ?? cat.totalQuantity ?? 0,
        fill: PIE_COLORS[idx % PIE_COLORS.length],
      }))
    : [];

  // ── Render ────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* Hero Banner with Background Image */}
      <div
        className="relative rounded-xl overflow-hidden"
        style={{
          backgroundImage: "url('/dashboard-bg.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#091413]/80 via-[#091413]/50 to-transparent" />
        <div className="relative z-10 px-6 py-10 sm:px-10 sm:py-14">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Dashboard
              </h1>
              <p className="text-[#B0E4CC] mt-1 text-sm sm:text-base">
                Overview of your business performance and activity
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchDashboardData}
              className="bg-white/15 border-white/25 text-white hover:bg-white/25 hover:text-white backdrop-blur-sm"
            >
              <RefreshCw className={loading ? "animate-spin" : ""} />
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Error state */}
      {error && !loading && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <div>
                <p className="font-medium text-red-800">Failed to load data</p>
                <p className="text-sm text-red-600">{error}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto"
                onClick={fetchDashboardData}
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 1. Stats Cards */}
      {loading ? (
        <StatsCardsSkeleton />
      ) : data ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {statsCards.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-lg ${stat.accentClass}`}
                >
                  <stat.icon className="h-5 w-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : null}

      {/* 2. Charts Section */}
      {loading ? (
        <ChartsSkeleton />
      ) : data ? (
        <div className="grid gap-6 md:grid-cols-2">
          {/* Monthly Sales Bar Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Monthly Sales</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer config={barChartConfig} className="h-[280px] w-full">
                <BarChart
                  data={data.monthlySales}
                  margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
                >
                  <CartesianGrid vertical={false} />
                  <XAxis
                    dataKey="month"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    fontSize={12}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    fontSize={12}
                    tickFormatter={(value: number) =>
                      value >= 100000
                        ? `Rs ${(value / 100000).toFixed(0)}L`
                        : value >= 1000
                          ? `Rs ${(value / 1000).toFixed(0)}K`
                          : `Rs ${value}`
                    }
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent
                        formatter={(value: number, name: string) => (
                          <span className="font-mono">
                            {name}: {formatCurrency(value)}
                          </span>
                        )}
                      />
                    }
                  />
                  <Bar
                    dataKey="sales"
                    fill="#285A48"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={40}
                  />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Category Distribution Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Category Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer config={pieChartConfig} className="h-[280px] w-full">
                <PieChart>
                  <ChartTooltip
                    content={<ChartTooltipContent nameKey="name" hideLabel />}
                  />
                  <Pie
                    data={pieData}
                    dataKey="count"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    strokeWidth={2}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
              {/* Custom legend for pie chart */}
              <div className="flex flex-wrap justify-center gap-3 mt-2">
                {pieData.map((entry) => (
                  <div
                    key={entry.name}
                    className="flex items-center gap-1.5 text-xs"
                  >
                    <div
                      className="h-2.5 w-2.5 rounded-[2px]"
                      style={{ backgroundColor: entry.fill }}
                    />
                    <span className="text-muted-foreground">{entry.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}

      {/* 3. Recent Invoices Table */}
      {loading ? (
        <TableSkeleton />
      ) : data ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Dealer</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden sm:table-cell">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.recentInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={5}
                      className="h-24 text-center text-muted-foreground"
                    >
                      No invoices found.
                    </TableCell>
                  </TableRow>
                ) : (
                  data.recentInvoices.slice(0, 5).map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">
                        {invoice.invoiceNumber}
                      </TableCell>
                      <TableCell>{invoice.dealer.name}</TableCell>
                      <TableCell className="text-right font-mono">
                        {formatCurrency(invoice.totalAmount)}
                      </TableCell>
                      <TableCell>{getStatusBadge(invoice.paymentStatus)}</TableCell>
                      <TableCell className="hidden sm:table-cell text-muted-foreground">
                        {new Date(invoice.createdAt).toLocaleDateString("en-PK", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        })}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : null}

      {/* 4. Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => setAdminView("purchases")}>
              <Plus className="h-5 w-5 text-[#285A48]" />
              <span className="text-xs font-medium">New Purchase</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => setAdminView("inventory")}>
              <Upload className="h-5 w-5 text-[#408A71]" />
              <span className="text-xs font-medium">Import CSV</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => setAdminView("invoices")}>
              <FileText className="h-5 w-5 text-[#285A48]" />
              <span className="text-xs font-medium">All Invoices</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={handleExport}>
              <Download className="h-5 w-5 text-[#408A71]" />
              <span className="text-xs font-medium">Export Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
