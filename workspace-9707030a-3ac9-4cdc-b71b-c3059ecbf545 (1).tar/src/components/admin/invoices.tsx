"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import {
  FileText,
  Search,
  Eye,
  RefreshCw,
  DollarSign,
  Receipt,
  X,
  User,
  Phone,
  Mail,
  Building,
  MapPin,
  Calendar,
  Package,
  Printer,
  MessageCircle,
  Download,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { printInvoice, getWhatsAppLink } from "@/lib/invoice-utils";
import { exportInvoices } from "@/lib/export-excel";
import type { Invoice, Dealer, PaymentStatus } from "@/lib/types";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// --- Helpers ---
function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function getStatusBadgeVariant(status: PaymentStatus) {
  switch (status) {
    case "Paid":
      return "bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-100";
    case "Partial":
      return "bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-100";
    case "Unpaid":
      return "bg-red-100 text-red-800 border-red-200 hover:bg-red-100";
    default:
      return "";
  }
}

// --- Component ---
export function InvoiceManagement() {
  const { toast } = useToast();

  // Data
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [dealers, setDealers] = useState<Dealer[]>([]);

  // Loading
  const [loadingInvoices, setLoadingInvoices] = useState(true);
  const [loadingDealers, setLoadingDealers] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Filters
  const [search, setSearch] = useState("");
  const [filterDealer, setFilterDealer] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  // Detail Sheet
  const [detailInvoice, setDetailInvoice] = useState<Invoice | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  // Update Payment Dialog
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [paymentForm, setPaymentForm] = useState({
    paymentStatus: "" as PaymentStatus | "",
    advancePaid: "",
    notes: "",
  });

  // ==================== Data Fetching ====================

  const fetchDealers = useCallback(async () => {
    try {
      setLoadingDealers(true);
      const res = await fetch("/api/dealers");
      if (!res.ok) throw new Error("Failed to fetch dealers");
      const data = await res.json();
      setDealers(data.dealers || []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load dealers",
        variant: "destructive",
      });
    } finally {
      setLoadingDealers(false);
    }
  }, [toast]);

  const fetchInvoices = useCallback(async () => {
    try {
      setLoadingInvoices(true);
      const params = new URLSearchParams();
      if (filterDealer) params.set("dealerId", filterDealer);
      if (filterStatus && filterStatus !== "all") params.set("status", filterStatus);
      const res = await fetch(`/api/invoices?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch invoices");
      const data = await res.json();
      setInvoices(data.invoices || []);
    } catch {
      toast({
        title: "Error",
        description: "Failed to load invoices",
        variant: "destructive",
      });
    } finally {
      setLoadingInvoices(false);
    }
  }, [filterDealer, filterStatus, toast]);

  useEffect(() => {
    fetchDealers();
  }, [fetchDealers]);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  // ==================== Derived / Computed ====================

  const filteredInvoices = useMemo(() => {
    if (!search.trim()) return invoices;
    const q = search.toLowerCase();
    return invoices.filter(
      (inv) =>
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.dealer.name.toLowerCase().includes(q) ||
        (inv.dealer.company && inv.dealer.company.toLowerCase().includes(q))
    );
  }, [invoices, search]);

  const summaryCards = useMemo(() => {
    const totalInvoices = invoices.length;
    let totalRevenue = 0;
    let pendingAmount = 0;

    for (const inv of invoices) {
      if (inv.paymentStatus === "Paid") {
        totalRevenue += inv.totalAmount;
      } else if (inv.paymentStatus === "Partial") {
        totalRevenue += inv.advancePaid;
        pendingAmount += inv.remainingAmount;
      } else if (inv.paymentStatus === "Unpaid") {
        pendingAmount += inv.totalAmount;
      }
    }

    return { totalInvoices, totalRevenue, pendingAmount };
  }, [invoices]);

  // ==================== Handlers ====================

  const clearFilters = () => {
    setSearch("");
    setFilterDealer("");
    setFilterStatus("all");
  };

  const hasActiveFilters = search || filterDealer || (filterStatus && filterStatus !== "all");

  const openDetailSheet = (invoice: Invoice) => {
    setDetailInvoice(invoice);
    setDetailOpen(true);
  };

  const openUpdateDialog = (invoice: Invoice) => {
    setPaymentForm({
      paymentStatus: invoice.paymentStatus,
      advancePaid: String(invoice.advancePaid),
      notes: invoice.notes || "",
    });
    setUpdateDialogOpen(true);
  };

  const handleUpdatePayment = async () => {
    if (!detailInvoice) return;

    const advancePaid = paymentForm.advancePaid ? Number(paymentForm.advancePaid) : undefined;
    const paymentStatus = paymentForm.paymentStatus || undefined;
    const notes = paymentForm.notes;

    if (!advancePaid && advancePaid !== 0 && !paymentStatus && notes === "") {
      toast({
        title: "Error",
        description: "Please update at least one field",
        variant: "destructive",
      });
      return;
    }

    try {
      setSubmitting(true);

      const body: Record<string, unknown> = { id: detailInvoice.id };
      if (paymentStatus) body.paymentStatus = paymentStatus;
      if (advancePaid !== undefined) body.advancePaid = advancePaid;
      body.notes = notes;

      const res = await fetch("/api/invoices", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to update invoice");
      }

      const updatedInvoice = await res.json();
      toast({
        title: "Success",
        description: "Invoice payment updated successfully",
      });

      // Update local state
      setDetailInvoice(updatedInvoice);
      setInvoices((prev) =>
        prev.map((inv) => (inv.id === updatedInvoice.id ? updatedInvoice : inv))
      );

      setUpdateDialogOpen(false);
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to update invoice",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // ==================== Render ====================

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Receipt className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Invoices</h2>
            <p className="text-sm text-muted-foreground">
              Manage and track all dealer invoices
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            disabled={filteredInvoices.length === 0}
            onClick={() => {
              const parts: string[] = [];
              if (search) parts.push(`Search: ${search}`);
              if (filterDealer) {
                const d = dealers.find((x) => x.id === filterDealer);
                if (d) parts.push(`Dealer: ${d.name}`);
              }
              if (filterStatus && filterStatus !== "all") parts.push(`Status: ${filterStatus}`);
              exportInvoices(filteredInvoices, parts.length > 0 ? parts.join(", ") : undefined);
            }}
          >
            <Download className="h-4 w-4" />
            Export Excel
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={fetchInvoices}
            disabled={loadingInvoices}
          >
            <RefreshCw className={`h-4 w-4 ${loadingInvoices ? "animate-spin" : ""}`} />
            <span className="sr-only">Refresh</span>
          </Button>
          <Badge variant="secondary" className="text-xs">
            {invoices.length} invoice{invoices.length !== 1 ? "s" : ""}
          </Badge>
        </div>
      </div>

      {/* ==================== Summary Cards ==================== */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {/* Total Invoices */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#EBF6F0]">
                <FileText className="h-5 w-5 text-[#285A48]" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-muted-foreground">Total Invoices</p>
                {loadingInvoices ? (
                  <Skeleton className="mt-1 h-6 w-16" />
                ) : (
                  <p className="text-xl font-bold">{summaryCards.totalInvoices}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Total Revenue */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-100">
                <DollarSign className="h-5 w-5 text-emerald-700" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-muted-foreground">Total Revenue</p>
                {loadingInvoices ? (
                  <Skeleton className="mt-1 h-6 w-28" />
                ) : (
                  <p className="text-xl font-bold text-emerald-700">
                    {formatCurrency(summaryCards.totalRevenue)}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pending Amount */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-red-100">
                <Receipt className="h-5 w-5 text-red-700" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-muted-foreground">Pending Amount</p>
                {loadingInvoices ? (
                  <Skeleton className="mt-1 h-6 w-28" />
                ) : (
                  <p className="text-xl font-bold text-red-700">
                    {formatCurrency(summaryCards.pendingAmount)}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ==================== Filter Bar ==================== */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
            {/* Search */}
            <div className="flex-1 space-y-1.5">
              <Label htmlFor="inv-search" className="text-xs font-medium text-muted-foreground">
                Search
              </Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="inv-search"
                  placeholder="Search by invoice # or dealer name..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            {/* Dealer Filter */}
            <div className="w-full space-y-1.5 lg:w-52">
              <Label className="text-xs font-medium text-muted-foreground">Dealer</Label>
              <Select value={filterDealer} onValueChange={setFilterDealer}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Dealers" />
                </SelectTrigger>
                <SelectContent>
                  {loadingDealers ? (
                    <SelectItem value="__loading" disabled>
                      Loading...
                    </SelectItem>
                  ) : (
                    dealers.map((dealer) => (
                      <SelectItem key={dealer.id} value={dealer.id}>
                        {dealer.name}
                        {dealer.company ? ` (${dealer.company})` : ""}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div className="w-full space-y-1.5 lg:w-40">
              <Label className="text-xs font-medium text-muted-foreground">Payment Status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                  <SelectItem value="Partial">Partial</SelectItem>
                  <SelectItem value="Unpaid">Unpaid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Clear Filters */}
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="shrink-0"
              >
                <X className="mr-1 h-4 w-4" />
                Clear Filters
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ==================== Invoices Table ==================== */}
      <Card>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow className="sticky top-0 z-10 bg-muted/80 backdrop-blur-sm">
                  <TableHead className="pl-4">Invoice #</TableHead>
                  <TableHead>Dealer</TableHead>
                  <TableHead className="hidden md:table-cell">Items</TableHead>
                  <TableHead className="hidden sm:table-cell text-right">Total Qty</TableHead>
                  <TableHead className="text-right">Total Amount</TableHead>
                  <TableHead className="hidden lg:table-cell text-right">Advance</TableHead>
                  <TableHead className="hidden lg:table-cell text-right">Remaining</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden xl:table-cell">Date</TableHead>
                  <TableHead className="pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingInvoices ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell className="pl-4">
                        <Skeleton className="h-4 w-24" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="h-4 w-28" />
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <Skeleton className="h-4 w-12" />
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <Skeleton className="ml-auto h-4 w-10" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="ml-auto h-4 w-20" />
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <Skeleton className="ml-auto h-4 w-20" />
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <Skeleton className="ml-auto h-4 w-20" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="h-5 w-16" />
                      </TableCell>
                      <TableCell className="hidden xl:table-cell">
                        <Skeleton className="h-4 w-20" />
                      </TableCell>
                      <TableCell className="pr-4">
                        <Skeleton className="ml-auto h-4 w-8" />
                      </TableCell>
                    </TableRow>
                  ))
                ) : filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="h-32 text-center">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Receipt className="h-8 w-8" />
                        <p className="text-sm">No invoices found</p>
                        {hasActiveFilters && (
                          <Button
                            variant="link"
                            size="sm"
                            onClick={clearFilters}
                          >
                            Clear filters
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map((inv) => (
                    <TableRow
                      key={inv.id}
                      className="cursor-pointer"
                      onClick={() => openDetailSheet(inv)}
                    >
                      <TableCell className="pl-4">
                        <span className="font-mono text-sm font-semibold">
                          {inv.invoiceNumber}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{inv.dealer.name}</p>
                          {inv.dealer.company && (
                            <p className="text-xs text-muted-foreground sm:hidden">
                              {inv.dealer.company}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <Badge variant="secondary" className="font-normal">
                          {inv.items.length} item{inv.items.length !== 1 ? "s" : ""}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-right font-medium">
                        {inv.totalQuantity}
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {formatCurrency(inv.totalAmount)}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-right text-muted-foreground">
                        {formatCurrency(inv.advancePaid)}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-right text-muted-foreground">
                        {formatCurrency(inv.remainingAmount)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={getStatusBadgeVariant(inv.paymentStatus)}
                        >
                          {inv.paymentStatus}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden xl:table-cell text-muted-foreground text-sm">
                        {formatDate(inv.createdAt)}
                      </TableCell>
                      <TableCell className="pr-4">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                            title="Send WhatsApp"
                            onClick={(e) => {
                              e.stopPropagation();
                              window.open(getWhatsAppLink(inv), "_blank");
                            }}
                          >
                            <MessageCircle className="h-3.5 w-3.5" />
                            <span className="sr-only">WhatsApp</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={(e) => {
                              e.stopPropagation();
                              printInvoice(inv);
                            }}
                          >
                            <Printer className="h-3.5 w-3.5" />
                            <span className="sr-only">Print</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={(e) => {
                              e.stopPropagation();
                              openDetailSheet(inv);
                            }}
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span className="sr-only">View</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ==================== Invoice Detail Sheet ==================== */}
      <Sheet open={detailOpen} onOpenChange={(open) => {
        if (!open) {
          setDetailOpen(false);
          setDetailInvoice(null);
        }
      }}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          {detailInvoice && (
            <>
              <SheetHeader className="space-y-3">
                <SheetTitle className="flex items-center justify-between">
                  <span className="font-mono">{detailInvoice.invoiceNumber}</span>
                  <Badge
                    variant="outline"
                    className={getStatusBadgeVariant(detailInvoice.paymentStatus)}
                  >
                    {detailInvoice.paymentStatus}
                  </Badge>
                </SheetTitle>
                <SheetDescription>
                  Invoice created on {formatDate(detailInvoice.createdAt)}
                </SheetDescription>
              </SheetHeader>

              <div className="mt-4 space-y-6">
                {/* Company Logo & Invoice Header */}
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img
                      src="/dashboard-bg.jpg"
                      alt="Beraj Digital"
                      className="h-14 w-14 rounded-xl object-cover border border-border shadow-sm"
                    />
                    <div>
                      <h2 className="text-lg font-bold text-[#285A48]">Beraj Digital Inventory</h2>
                      <p className="text-xs text-muted-foreground">Invoice & Dealer Management</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1.5"
                      onClick={() => detailInvoice && printInvoice(detailInvoice)}
                    >
                      <Printer className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Print</span>
                    </Button>
                    <a
                      href={detailInvoice ? getWhatsAppLink(detailInvoice) : "#"}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1.5 border-green-300 text-green-700 hover:bg-green-50"
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        <span className="hidden sm:inline">WhatsApp</span>
                      </Button>
                    </a>
                  </div>
                </div>

                {/* Dealer Info Section */}
                <div className="rounded-lg border p-4 space-y-3">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    Dealer Information
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{detailInvoice.dealer.name}</span>
                    </div>
                    {detailInvoice.dealer.company && (
                      <div className="flex items-center gap-2">
                        <Building className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          {detailInvoice.dealer.company}
                        </span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{detailInvoice.dealer.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{detailInvoice.dealer.phone}</span>
                    </div>
                    {(detailInvoice.dealer.city || detailInvoice.dealer.state) && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          {[detailInvoice.dealer.city, detailInvoice.dealer.state]
                            .filter(Boolean)
                            .join(", ")}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Items Table */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    Invoice Items
                  </h3>
                  <div className="rounded-lg border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="text-xs">Category + Code</TableHead>
                          <TableHead className="text-xs hidden sm:table-cell">Product Type</TableHead>
                          <TableHead className="text-xs text-right">Qty</TableHead>
                          <TableHead className="text-xs text-right hidden sm:table-cell">Unit Price</TableHead>
                          <TableHead className="text-xs text-right">Total Price</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {detailInvoice.items.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-6 text-sm text-muted-foreground">
                              No items found
                            </TableCell>
                          </TableRow>
                        ) : (
                          detailInvoice.items.map((item) => {
                            const invItem = item.inventoryItem;
                            const codeDisplay = `${invItem.category.codePrefix}${invItem.categoryCode}`;
                            return (
                              <TableRow key={item.id}>
                                <TableCell>
                                  <div className="flex flex-col">
                                    <Badge variant="outline" className="font-mono text-xs w-fit mb-1">
                                      {codeDisplay}
                                    </Badge>
                                    <span className="text-xs text-muted-foreground">
                                      {invItem.category.name}
                                    </span>
                                  </div>
                                </TableCell>
                                <TableCell className="hidden sm:table-cell text-sm">
                                  {invItem.productType.name}
                                </TableCell>
                                <TableCell className="text-right font-medium">
                                  {item.quantity}
                                </TableCell>
                                <TableCell className="text-right text-sm text-muted-foreground hidden sm:table-cell">
                                  {formatCurrency(item.unitPrice)}
                                </TableCell>
                                <TableCell className="text-right font-semibold">
                                  {formatCurrency(item.totalPrice)}
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                {/* Summary Section */}
                <div className="rounded-lg border p-4 space-y-3">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    Payment Summary
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Total Amount</span>
                      <span className="font-semibold">
                        {formatCurrency(detailInvoice.totalAmount)}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Advance Paid</span>
                      <span className="text-sm font-medium text-emerald-700">
                        {formatCurrency(detailInvoice.advancePaid)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Remaining Balance</span>
                      <span className={`text-sm font-medium ${detailInvoice.remainingAmount > 0 ? "text-red-700" : "text-emerald-700"}`}>
                        {formatCurrency(detailInvoice.remainingAmount)}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Payment Status</span>
                      <Badge
                        variant="outline"
                        className={getStatusBadgeVariant(detailInvoice.paymentStatus)}
                      >
                        {detailInvoice.paymentStatus}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Notes */}
                {detailInvoice.notes && (
                  <div className="rounded-lg border p-4 space-y-2">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                      Notes
                    </h3>
                    <p className="text-sm whitespace-pre-wrap">{detailInvoice.notes}</p>
                  </div>
                )}

                {/* Update Payment Button */}
                <Button
                  className="w-full"
                  onClick={() => openUpdateDialog(detailInvoice)}
                >
                  <DollarSign className="mr-2 h-4 w-4" />
                  Update Payment
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* ==================== Update Payment Dialog ==================== */}
      <Dialog open={updateDialogOpen} onOpenChange={(open) => {
        if (!open) setUpdateDialogOpen(false);
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Update Payment
            </DialogTitle>
            <DialogDescription>
              {detailInvoice
                ? `Update payment details for ${detailInvoice.invoiceNumber}`
                : "Update payment details"}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            {/* Payment Status */}
            <div className="space-y-2">
              <Label htmlFor="payment-status">Payment Status</Label>
              <Select
                value={paymentForm.paymentStatus}
                onValueChange={(val) =>
                  setPaymentForm((prev) => ({ ...prev, paymentStatus: val as PaymentStatus }))
                }
              >
                <SelectTrigger className="w-full" id="payment-status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Paid">Paid</SelectItem>
                  <SelectItem value="Partial">Partial</SelectItem>
                  <SelectItem value="Unpaid">Unpaid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Advance Paid */}
            <div className="space-y-2">
              <Label htmlFor="advance-paid">Advance Paid (Rs)</Label>
              <Input
                id="advance-paid"
                type="number"
                placeholder="0.00"
                value={paymentForm.advancePaid}
                onChange={(e) =>
                  setPaymentForm((prev) => ({ ...prev, advancePaid: e.target.value }))
                }
                min={0}
                step="0.01"
              />
              {detailInvoice && (
                <p className="text-xs text-muted-foreground">
                  Total amount: {formatCurrency(detailInvoice.totalAmount)} | Remaining:{" "}
                  <span className={detailInvoice.remainingAmount > 0 ? "text-red-600" : "text-emerald-600"}>
                    {formatCurrency(detailInvoice.remainingAmount)}
                  </span>
                </p>
              )}
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="payment-notes">Notes</Label>
              <Textarea
                id="payment-notes"
                placeholder="Add any notes about this payment..."
                value={paymentForm.notes}
                onChange={(e) =>
                  setPaymentForm((prev) => ({ ...prev, notes: e.target.value }))
                }
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setUpdateDialogOpen(false)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button onClick={handleUpdatePayment} disabled={submitting}>
              {submitting ? (
                <>
                  <RefreshCw className="mr-1 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
