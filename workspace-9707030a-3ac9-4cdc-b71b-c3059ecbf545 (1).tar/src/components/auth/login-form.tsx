"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, Loader2, Shield, Users } from "lucide-react";

export function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { setUser } = useAppStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const result = await signIn("credentials", {
        email,
        password,
        redirect: false,
      });

      if (result?.error) {
        setError(result.error);
        return;
      }

      // Fetch user info from session
      const res = await fetch("/api/auth/session");
      const session = await res.json();

      if (session?.user) {
        setUser({
          id: (session.user as Record<string, unknown>).id as string || "",
          email: session.user.email || "",
          name: session.user.name || "",
          role: (session.user as Record<string, unknown>).role as "admin" | "dealer",
          dealerId: (session.user as Record<string, unknown>).dealerId as string | null,
          dealerName: (session.user as Record<string, unknown>).dealerName as string | null,
        });
      }
    } catch {
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const fillCredentials = (role: "admin" | "dealer") => {
    if (role === "admin") {
      setEmail("admin@inventory.com");
      setPassword("admin123");
    } else {
      setEmail("rajesh@rkdist.com");
      setPassword("dealer123");
    }
    setError("");
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Dark blue background layers */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0f2140] to-[#162d50]" />
      {/* Decorative circles */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-blue-500/10 blur-3xl" />
      <div className="absolute -bottom-40 -right-40 w-[28rem] h-[28rem] rounded-full bg-blue-600/10 blur-3xl" />
      <div className="absolute top-1/3 right-1/4 w-64 h-64 rounded-full bg-indigo-500/5 blur-3xl" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-md px-4">
        {/* Logo / Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center mb-4">
            <img
              src="/dashboard-bg.jpg"
              alt="Beraj Digital"
              className="w-20 h-20 rounded-2xl object-cover shadow-lg shadow-black/30 ring-2 ring-white/10"
            />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Beraj Digital Inventory
          </h1>
          <p className="text-blue-200/70 mt-1 text-sm">
            Inventory & Dealer Management
          </p>
        </div>

        <Card className="shadow-2xl border-0 bg-white/[0.07] backdrop-blur-xl text-white">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-xl text-white">Welcome Back</CardTitle>
            <CardDescription className="text-blue-200/60">
              Sign in to your account to continue
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Quick Login Buttons */}
            <div className="flex gap-2 mb-6">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 gap-2 bg-white/10 border-white/10 text-white hover:bg-white/20 hover:text-white"
                onClick={() => fillCredentials("admin")}
              >
                <Shield className="w-3.5 h-3.5" />
                Admin Demo
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 gap-2 bg-white/10 border-white/10 text-white hover:bg-white/20 hover:text-white"
                onClick={() => fillCredentials("dealer")}
              >
                <Users className="w-3.5 h-3.5" />
                Dealer Demo
              </Button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-blue-100/80">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@inventory.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="email"
                  className="bg-white/10 border-white/10 text-white placeholder:text-blue-300/30 focus:border-blue-400/50 focus:ring-blue-400/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-blue-100/80">
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                    className="bg-white/10 border-white/10 text-white placeholder:text-blue-300/30 focus:border-blue-400/50 focus:ring-blue-400/20 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-300/50 hover:text-blue-200 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-red-500/15 border border-red-400/20 text-red-300 text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white shadow-lg shadow-blue-900/30"
                disabled={loading}
              >
                {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Sign In
              </Button>
            </form>

            {/* Demo Credentials Info */}
            <div className="mt-6 p-3 rounded-lg bg-white/5 border border-white/5">
              <p className="text-xs font-medium text-blue-200/50 mb-2">Demo Credentials</p>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-blue-200/40">
                  <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-white/10 text-blue-100/60 border-white/5">
                    Admin
                  </Badge>
                  <span>admin@inventory.com / admin123</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-blue-200/40">
                  <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-white/10 text-blue-100/60 border-white/5">
                    Dealer
                  </Badge>
                  <span>rajesh@rkdist.com / dealer123</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-blue-300/20 text-xs mt-6">
          &copy; {new Date().getFullYear()} Beraj Digital Inventory. All rights reserved.
        </p>
      </div>
    </div>
  );
}
